﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace BitAuto.ISDC.CC2012.Web.CRMStopCust
{
    public partial class AjaxList : BitAuto.ISDC.CC2012.Web.Base.PageBase
    {
        /// <summary>
        /// JSON字符串
        /// </summary>
        public string JsonStr
        {
            get
            {
                return HttpContext.Current.Request["JsonStr"] == null ? string.Empty :
                  HttpUtility.UrlDecode(HttpContext.Current.Request["JsonStr"].ToString());
            }

        }
        public int PageSize = 20;
        public int GroupLength = 8;
        public int RecordCount;
        private int userID = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                userID = BLL.Util.GetLoginUserID();
                BindData();
            }
        }

        //绑定数据
        public void BindData()
        {
            Entities.QueryStopCustApply query = new Entities.QueryStopCustApply();

            string errMsg = string.Empty;
            BLL.ConverToEntitie<Entities.QueryStopCustApply> conver = new BLL.ConverToEntitie<Entities.QueryStopCustApply>(query);
            errMsg = conver.Conver(JsonStr);

            if (errMsg != "")
            {
                return;
            }

            query.LoginID = userID;
            int RecordCount = 0;

            DataTable dt = BLL.StopCustApply.Instance.GetStopCustApply(query, " sca.ApplyTime desc ", BLL.PageCommon.Instance.PageIndex, PageSize, out RecordCount);
            repeaterTableList.DataSource = dt;
            repeaterTableList.DataBind();

            AjaxPager.PageSize = 20;
            AjaxPager.InitPager(RecordCount);
        }

        public string GetStatusName(string status, string taskStatus, string applytype)
        {
            string result = string.Empty;

            int _status;
            if (int.TryParse(status, out _status))
            {
                result = BLL.Util.GetEnumOptText(typeof(Entities.StopCustStopStatus), _status);

                if (_status == 2 && applytype == "2")
                {
                    result = "待启用";
                }
                else if (_status == 3 && applytype == "2")
                {
                    result = "已启用";
                }
                else if (_status == 5 || _status == 6)
                {
                    result = "已驳回";
                }
                else
                {
                    if (_status == 1 && taskStatus == "1")
                    {
                        result = "未分配";
                    }
                    else if (_status == 1 && taskStatus == "2")
                    {
                        result = "待处理";
                    }
                    else if (_status == 1 && taskStatus == "3")
                    {
                        result = "处理中";
                    }
                }
            }
            return result;
        }
        public string GetOperLink(string status, string taskid, string taskStatus, string assignUserID)
        {
            string result = string.Empty;

            int _status;
            int _taskStatus;
            if (int.TryParse(status, out _status) && int.TryParse(taskStatus, out _taskStatus))
            {
                if (_status != (int)Entities.StopCustStopStatus.Pending)
                {
                    result = "<a href='View.aspx?TaskID=" + taskid + "' target='_blank' >查看</a>";
                }
                else
                {
                    if (_taskStatus == (int)Entities.StopCustTaskStatus.NoAllocation)
                    {
                        result = "<a href='View.aspx?TaskID=" + taskid + "' target='_blank' >查看</a>";
                    }
                    else
                    {
                        if (int.Parse(assignUserID) == BLL.Util.GetLoginUserID())
                        {
                            result = "<a href='Edit.aspx?op=e&TaskID=" + taskid + "' target='_blank'>处理</a>";
                        }
                        else
                        {
                            result = "<a href='View.aspx?TaskID=" + taskid + "' target='_blank' >查看</a>";
                        }
                    }
                }
            }

            return result;
        }
    }
}