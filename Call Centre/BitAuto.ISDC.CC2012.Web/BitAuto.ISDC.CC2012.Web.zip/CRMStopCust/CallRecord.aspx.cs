﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.ISDC.CC2012.Entities;
using BitAuto.ISDC.CC2012.Web.CustInfo;

namespace BitAuto.ISDC.CC2012.Web.CRMStopCust
{
    public partial class CallRecord : BitAuto.ISDC.CC2012.Web.Base.PageBase
    {
        public string TaskID
        {
            get
            {
                return HttpContext.Current.Request["TaskID"] == null
                           ? ""
                           : HttpUtility.UrlDecode(HttpContext.Current.Request["TaskID"]);
            }
        }

        //public string DataSource = "";//数据来源，1-CRM库，2-CRM库及Excel新增
        public bool IsBind = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        Entities.OrderCRMStopCustTask task;
        string custId = string.Empty;

        private void BindData()
        {
            if (string.IsNullOrEmpty(TaskID)) { return; }
            else
            {
                task = BLL.OrderCRMStopCustTask.Instance.GetOrderCRMStopCustTask(long.Parse(TaskID));

                if (task == null)
                {
                    return;
                }

                //custId = task.RelationID;
                //DataSource = (task.Source == 1 ? "2" : "1");
                switch (task.TaskStatus)
                {
                    case 1://未分配
                    case 2://未处理
                    case 3://处理中
                    case 4://已提交
                        IsBind = true;
                        break;
                    default: break;
                }
                if (Request["Action"] != null)
                {
                    if (Request["Action"] != null && Request["Action"] == "view")
                    {
                        IsBind = false;
                    }
                }
            }
            QueryCallRecordInfo query = new QueryCallRecordInfo();
            query.TaskTypeID = (int)Entities.TaskTypeID.StopCustTask;

            query.CustID = BLL.StopCustApply.Instance.GetStopCustApply(int.Parse(task.RelationID.ToString())).CustID;
            query.TaskID = this.TaskID;

            int totalCount = 0;
            string tableEndName = "";//只查询现表数据
            DataTable table = BLL.CallRecordInfo.Instance.GetCallRecordsForRecord(query, 1, 100000, tableEndName, out totalCount);

            //设置数据源
            if (table != null && table.Rows.Count > 0)
            {
                repeater_Contact.DataSource = table;
            }
            //绑定列表数据
            repeater_Contact.DataBind();
            ////分页控件
            //this.AjaxPager_Contact.InitPager(totalCount);
        }
    }
}