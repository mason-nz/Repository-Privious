﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Data.SqlClient;

namespace BitAuto.ISDC.CC2012.Web.CRMStopCust
{
    public class OperCustRelationTask
    {
        public void CustLastOperTask(string custID, string taskID, int taskType, DateTime dtime)
        {
            if (custID == "" || custID == null)
            {
                return;
            }

            Entities.CustLastOperTask model = BLL.CustLastOperTask.Instance.GetCustLastOperTask(custID);

            if (model != null)
            {
                Entities.CustLastOperTask oldModel = BLL.CustLastOperTask.Instance.GetCustLastOperTask(custID);

                model.CustID = custID;
                model.TaskID = taskID;
                model.TaskType = taskType;
                model.LastOperTime = dtime;
                model.LastOperUserID = BLL.Util.GetLoginUserID();

                UpdateCustLastOperTask(oldModel, model);
            }
            else
            {
                model = new Entities.CustLastOperTask();

                model.CustID = custID;
                model.TaskID = taskID;
                model.TaskType = taskType;
                model.LastOperTime = model.CreateTime = dtime;
                model.LastOperUserID = model.CreateUserID = BLL.Util.GetLoginUserID();
                InsertCustLastOperTask(model);
            }
        }

        public void InsertCustLastOperTask(Entities.CustLastOperTask model)
        {
            BLL.CustLastOperTask.Instance.Insert(model);

            InsertLog(null, model);
        }

        public void InsertCustLastOperTask(SqlTransaction tran, Entities.CustLastOperTask model)
        {
            BLL.CustLastOperTask.Instance.Insert(tran, model);

            InsertLog(null, model);
        }

        public void UpdateCustLastOperTask(Entities.CustLastOperTask oldModel, Entities.CustLastOperTask model)
        {
            BLL.CustLastOperTask.Instance.Update(model);

            InsertLog(oldModel, model);
        }

        public void UpdateCustLastOperTask(SqlTransaction tran, Entities.CustLastOperTask oldModel, Entities.CustLastOperTask model)
        {
            BLL.CustLastOperTask.Instance.Update(tran, model);

            InsertLog(tran, oldModel, model);
        }

        public void InsertLog(Entities.CustLastOperTask oldModel, Entities.CustLastOperTask newModel)
        {
            string userLogStr = string.Empty;
            string logStr = string.Empty;

            Hashtable ht_FieldName = new Hashtable();

            ht_FieldName.Add("TaskType", "任务类型");

            BLL.GetLogDesc.ht_FieldName = ht_FieldName;

            Hashtable ht_FieldType = new Hashtable();
            Hashtable ht_Type = new Hashtable();
            ht_Type.Add("1", "客户核实");
            ht_Type.Add("2", "客户停用核实");

            ht_FieldType.Add("LastOperUserID", "UserID");
            ht_FieldType.Add("TaskType", ht_Type);
            ht_FieldType.Add("CreateUserID", "UserID");

            BLL.GetLogDesc.ht_FieldType = ht_FieldType;

            if (oldModel == null)//为空，则是新增
            {
                //插入日志
                BLL.GetLogDesc.getAddLogInfo(newModel, out userLogStr);

                logStr = "客户关联任务最后操作信息表新增：" + userLogStr;
            }
            else //不为空，则是编辑
            {
                //插入日志 
                BLL.GetLogDesc.getCompareLogInfo(oldModel, newModel, out userLogStr);

                logStr = "客户关联任务最后操作信息表编辑：" + userLogStr;
            }

            if (userLogStr != string.Empty)
            {
                BLL.Util.InsertUserLog(logStr);
            }

        }

        public void InsertLog(SqlTransaction tran, Entities.CustLastOperTask oldModel, Entities.CustLastOperTask newModel)
        {
            string userLogStr = string.Empty;
            string logStr = string.Empty;

            Hashtable ht_FieldName = new Hashtable();

            ht_FieldName.Add("TaskType", "任务类型");

            BLL.GetLogDesc.ht_FieldName = ht_FieldName;

            Hashtable ht_FieldType = new Hashtable();
            Hashtable ht_Type = new Hashtable();
            ht_Type.Add("1", "客户核实");
            ht_Type.Add("2", "客户停用核实");

            ht_FieldType.Add("LastOperUserID", "UserID");
            ht_FieldType.Add("TaskType", ht_Type);
            ht_FieldType.Add("CreateUserID", "UserID");

            BLL.GetLogDesc.ht_FieldType = ht_FieldType;

            if (oldModel == null)//为空，则是新增
            {
                //插入日志
                BLL.GetLogDesc.getAddLogInfo(newModel, out userLogStr);

                logStr = "客户关联任务最后操作信息表新增：" + userLogStr;
            }
            else //不为空，则是编辑
            {
                //插入日志 
                BLL.GetLogDesc.getCompareLogInfo(oldModel, newModel, out userLogStr);

                logStr = "客户关联任务最后操作信息表编辑：" + userLogStr;
            }

            if (userLogStr != string.Empty)
            {
                BLL.Util.InsertUserLog(tran, logStr);
            }

        }
    }
}