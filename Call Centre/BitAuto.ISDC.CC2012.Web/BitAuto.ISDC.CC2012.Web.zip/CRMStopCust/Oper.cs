﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using BitAuto.ISDC.CC2012.Web.WebServices;

namespace BitAuto.ISDC.CC2012.Web.CRMStopCust
{
    public class Oper
    {

        public void AssignTaskByUseid(string TaskIDS, string AssignUserID, out string msg)
        {
            msg = "result:'false'";
            string error = string.Empty;

            if (TaskIDS == string.Empty)
            {
                msg = "result:'false',error:'任务ID串不能为空'";
                return;
            }

            #region ID列表串

            string taskIDStr = "";

            string[] tidList = TaskIDS.Split(',');

            foreach (string item in tidList)
            {
                taskIDStr += "'" + item + "',";
            }
            if (taskIDStr != "")
            {
                taskIDStr = taskIDStr.Substring(0, taskIDStr.Length - 1);
            }
            else
            {
                error += "请选择任务";
                return;
            }

            #endregion

            #region 判断任务状态

            //判断任务状态
            DataTable taskDt = BLL.OrderCRMStopCustTask.Instance.GetListByTaskIDs(taskIDStr);

            if (taskDt != null)
            {
                foreach (DataRow dr in taskDt.Rows)
                {
                    //所能分配的任务为：1-未分配；未处理-2；处理中-3
                    if (dr["TaskStatus"].ToString() != "1" && dr["TaskStatus"].ToString() != "2" && dr["TaskStatus"].ToString() != "3")
                    {
                        error += "所选任务中，存在不允许分配的任务";
                        break;
                    }
                }
            }
            else
            {
                error += "没找到对应任务";
            }

            if (error != "")
            {
                msg = "result:'false',error:'" + error + "'";
                return;
            }
            #endregion
            DateTime dtime = DateTime.Now;
            foreach (string tid in tidList)
            {
                Entities.OrderCRMStopCustTask model =
                    BLL.OrderCRMStopCustTask.Instance.GetOrderCRMStopCustTask(int.Parse(tid));
                Entities.OrderCRMStopCustTask oldModel =
                    BLL.OrderCRMStopCustTask.Instance.GetOrderCRMStopCustTask(int.Parse(tid));


                model.TaskStatus = (int)Entities.StopCustTaskStatus.NoProcess;
                model.AssignUserID = int.Parse(AssignUserID);
                model.AssignTime = dtime;
                model.Status = 0;
                BLL.OrderCRMStopCustTask.Instance.Update(model);

                Log.InsertLogOrderCRMStopCustTask(oldModel, model, BLL.Util.GetLoginUserID());

                insertOperationLog(long.Parse(tid), (int)Entities.StopCustTaskOperStatus.Allocation, (int)Entities.StopCustTaskStatus.NoProcess);

                //更新客户关联任务最后操作信息CustLastOperTask表
                Entities.StopCustApply model_StopCustApply = BLL.StopCustApply.Instance.GetStopCustApply(int.Parse(model.RelationID.ToString()));
                if (model_StopCustApply != null)
                {
                    CRMStopCust.OperCustRelationTask oper = new CRMStopCust.OperCustRelationTask();
                    oper.CustLastOperTask(model_StopCustApply.CustID, tid, 2, dtime);
                }
            }

            msg = "result:'true'";
        }

        private void insertOperationLog(long tid, int operStatus, int taskStatus)
        {
            Entities.OrderCRMStopCustTaskOperationLog model_Log = new Entities.OrderCRMStopCustTaskOperationLog();
            model_Log.TaskID = tid;
            model_Log.OperationStatus = operStatus;
            model_Log.TaskStatus = taskStatus;
            model_Log.CreateTime = DateTime.Now;
            model_Log.CreateUserID = BLL.Util.GetLoginUserID();
            BLL.OrderCRMStopCustTaskOperationLog.Instance.Insert(model_Log);

            Log.InsertLogOrderCRMStopCustTaskOperationLog(null, model_Log, BLL.Util.GetLoginUserID());
        }

        public void RecedeTask(string TaskIDS, string AssignUserID, out string msg)
        {
            msg = "result:'false'";
            int userId = BLL.Util.GetLoginUserID();
            if (!BLL.Util.CheckRight(userId, "SYS024BUT130402"))  //增加“任务列表--客户核实”回收功能验证逻辑
            {
                msg = "result:'false',error:'没有回收权限'";
                return;
            }
            string error = string.Empty;

            if (TaskIDS == string.Empty)
            {
                msg = "result:'false',error:'任务ID串不能为空'";
                return;
            }

            #region ID列表串

            string taskIDStr = "";

            string[] tidList = TaskIDS.Split(',');

            foreach (string item in tidList)
            {
                taskIDStr += "'" + item + "',";
            }
            if (taskIDStr != "")
            {
                taskIDStr = taskIDStr.Substring(0, taskIDStr.Length - 1);
            }
            else
            {
                error += "请选择任务";
                return;
            }

            #endregion

            #region 判断任务状态

            //判断任务状态
            DataTable taskDt = BLL.OrderCRMStopCustTask.Instance.GetListByTaskIDs(taskIDStr);

            if (taskDt != null)
            {
                foreach (DataRow dr in taskDt.Rows)
                {
                    //所能回收的任务为： 未处理-2；处理中-3
                    if (dr["TaskStatus"].ToString() != "2" && dr["TaskStatus"].ToString() != "3")
                    {
                        error += "所选任务中，存在不允许回收的任务";
                        break;
                    }
                }
            }
            else
            {
                error += "没找到对应任务";
            }

            if (error != "")
            {
                msg = "result:'false',error:'" + error + "'";
                return;
            }
            #endregion
            DateTime dtime = DateTime.Now;
            foreach (string tid in tidList)
            {
                Entities.OrderCRMStopCustTask model =
                    BLL.OrderCRMStopCustTask.Instance.GetOrderCRMStopCustTask(int.Parse(tid));
                Entities.OrderCRMStopCustTask oldModel =
                    BLL.OrderCRMStopCustTask.Instance.GetOrderCRMStopCustTask(int.Parse(tid));

                model.TaskStatus = (int)Entities.StopCustTaskStatus.NoAllocation;
                model.AssignUserID = -2;
                model.AssignTime = dtime;
                model.Status = 0;
                BLL.OrderCRMStopCustTask.Instance.Update(model);

                Log.InsertLogOrderCRMStopCustTask(oldModel, model, BLL.Util.GetLoginUserID());

                insertOperationLog(long.Parse(tid), (int)Entities.StopCustTaskOperStatus.Recover, (int)model.TaskStatus);


                //更新客户关联任务最后操作信息CustLastOperTask表
                Entities.StopCustApply model_StopCustApply = BLL.StopCustApply.Instance.GetStopCustApply(int.Parse(model.RelationID.ToString()));
                if (model_StopCustApply != null)
                {
                    CRMStopCust.OperCustRelationTask oper = new CRMStopCust.OperCustRelationTask();
                    oper.CustLastOperTask(model_StopCustApply.CustID, tid, 2, dtime); 
                }
            }

            msg = "result:'true'";
        }

    }
}