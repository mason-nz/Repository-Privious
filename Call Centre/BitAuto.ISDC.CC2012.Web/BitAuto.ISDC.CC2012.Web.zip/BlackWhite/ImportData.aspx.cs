﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.BlackWhite
{
    public partial class ImportData : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}