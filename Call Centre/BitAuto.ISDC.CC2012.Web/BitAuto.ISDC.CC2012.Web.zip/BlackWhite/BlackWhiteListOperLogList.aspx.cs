﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BitAuto.ISDC.CC2012.Web.Base;
using System.Data;
using BitAuto.ISDC.CC2012.BLL;

namespace BitAuto.ISDC.CC2012.Web.BlackWhite
{
    public partial class BlackWhiteListOperLogList : PageBase
    {
        public string PhoneNumber
        {
            get { return Request["PhoneNumber"] == null ? string.Empty : HttpUtility.UrlDecode(Request["PhoneNumber"].ToString()); }
        }
        public string CustID
        {
            get { return Request["CustID"] == null ? string.Empty : HttpUtility.UrlDecode(Request["CustID"].ToString()); }
        }
        public int PageSize = BLL.PageCommon.Instance.PageSize = 10;
        public int GroupLength = 8;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindListData();
            }
        }
        private void BindListData()
        {
            Entities.QueryBlackWhiteListOperLog query = new Entities.QueryBlackWhiteListOperLog();
            if (!string.IsNullOrEmpty(PhoneNumber))
            {
                query.PhoneNum = PhoneNumber;
            }
            if (!string.IsNullOrEmpty(CustID))
            {
                query.CustID = CustID;
            }
            query.BWType = 0;
            int recordCount = 0;
            DataTable dt = BLL.BlackWhiteListOperLog.Instance.GetBlackWhiteListOperLog(query, "a.PhoneNum,a.OperTime desc", PageCommon.Instance.PageIndex, PageSize, out recordCount);
            repeaterTableList.DataSource = dt;
            repeaterTableList.DataBind();
            litPagerDown.Text = PageCommon.Instance.LinkStringByPost(BLL.Util.GetUrl(), GroupLength, recordCount, PageSize, PageCommon.Instance.PageIndex, 1);

        }
        /// <summary>
        /// 取操作类型
        /// </summary>
        /// <param name="operType"></param>
        /// <returns></returns>
        public string GetOperTypesName(string operType)
        {
            string operName = string.Empty;
            switch (operType)
            {
                case "3":
                    operName = "删除记录";
                    break;
                default:
                    operName = "保存记录";
                    break;
            }
            return operName;
        }
    }
}