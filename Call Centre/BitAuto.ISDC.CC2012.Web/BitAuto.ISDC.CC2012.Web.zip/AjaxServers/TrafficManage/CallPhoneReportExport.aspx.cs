﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.ISDC.CC2012.Entities;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.TrafficManage
{
    public partial class CallPhoneReportExport : PageBase
    {
        #region 参数

        private string IVRScore
        {
            get
            {
                return Request["IVRScore"] == null ? "" :
                HttpUtility.UrlDecode(Request["IVRScore"].ToString().Trim());
            }
        }

        private string IncomingSource
        {
            get
            {
                return Request["IncomingSource"] == null ? "" :
                HttpUtility.UrlDecode(Request["IncomingSource"].ToString().Trim());
            }
        }

        private string Name
        {
            get
            {
                return Request["Name"] == null ? "" :
                HttpUtility.UrlDecode(Request["Name"].ToString().Trim());
            }
        }

        private string ANI
        {
            get
            {
                return Request["ANI"] == null ? "" :
                HttpUtility.UrlDecode(Request["ANI"].ToString().Trim());
            }
        }

        private string Agent
        {
            get
            {
                return Request["Agent"] == null ? "" :
                HttpUtility.UrlDecode(Request["Agent"].ToString().Trim());
            }
        }

        private string TaskID
        {
            get
            {
                return Request["TaskID"] == null ? "" :
                HttpUtility.UrlDecode(Request["TaskID"].ToString().Trim());
            }
        }

        private string CallID
        {
            get
            {
                return Request["CallID"] == null ? "" :
                HttpUtility.UrlDecode(Request["CallID"].ToString().Trim());
            }
        }

        private string BeginTime
        {
            get
            {
                return Request["BeginTime"] == null ? "" :
                HttpUtility.UrlDecode(Request["BeginTime"].ToString().Trim());
            }
        }

        private string EndTime
        {
            get
            {
                return Request["EndTime"] == null ? "" :
                HttpUtility.UrlDecode(Request["EndTime"].ToString().Trim());
            }
        }

        private string AgentNum
        {
            get
            {
                return Request["AgentNum"] == null ? "" :
                HttpUtility.UrlDecode(Request["AgentNum"].ToString().Trim());
            }
        }
        private string PhoneNum
        {
            get
            {
                return Request["PhoneNum"] == null ? "" :
                HttpUtility.UrlDecode(Request["PhoneNum"].ToString().Trim());
            }
        }

        private string TaskCategory
        {
            get
            {
                return Request["TaskCategory"] == null ? "" :
                HttpUtility.UrlDecode(Request["TaskCategory"].ToString().Trim());
            }
        }

        public string Category
        {
            get
            {
                return Request["selCategory"] == null ? "" :
                HttpUtility.UrlDecode(Request["selCategory"].ToString().Trim());
            }
        }

        private string SpanTime1
        {
            get
            {
                return Request["SpanTime1"] == null ? "" :
                HttpUtility.UrlDecode(Request["SpanTime1"].ToString().Trim());
            }
        }

        private string SpanTime2
        {
            get
            {
                return Request["SpanTime2"] == null ? "" :
                HttpUtility.UrlDecode(Request["SpanTime2"].ToString().Trim());
            }
        }

        private string AgentGroup
        {
            get
            {
                return Request["AgentGroup"] == null ? "" :
                HttpUtility.UrlDecode(Request["AgentGroup"].ToString().Trim());
            }
        }

        /// <summary>
        /// 电话状态（1-呼入，2-呼出）
        /// </summary>
        private string CallStatus
        {
            get
            {
                return Request["CallStatus"] == null ? "" :
                HttpUtility.UrlDecode(Request["CallStatus"].ToString().Trim());
            }
        }

        /// <summary>
        /// 查询类型：1月，2周，3日
        /// </summary>
        private int RequestQueryType
        {
            get { return string.IsNullOrEmpty(HttpContext.Current.Request["QueryType"]) ? 1 : Convert.ToInt32(HttpUtility.UrlDecode(HttpContext.Current.Request["QueryType"])); }
        }
        private string RequestAgentNum
        {
            get { return string.IsNullOrEmpty(HttpContext.Current.Request["AgentNum"]) ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["AgentNum"].ToString()); }
        }
        private int RequestAgentUserID
        {
            get { return string.IsNullOrEmpty(HttpContext.Current.Request["AgentUserID"]) ? -2 : Convert.ToInt32(HttpUtility.UrlDecode(HttpContext.Current.Request["AgentUserID"])); }
        }
        #endregion
        private string RequestBrowser
        {
            get
            {

                return HttpContext.Current.Request["Browser"] == null ? String.Empty :
                  HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["Browser"].ToString());
            }
        }
        public int RecordCount;
        public int userID;
        protected void Page_Load(object sender, EventArgs e)
        {
            userID = BLL.Util.GetLoginUserID();
            if (BLL.Util.CheckRight(userID, "SYS024MOD400501"))
            {
                BindData();
            }
            else
            {
                Response.Write(BLL.Util.GetNotAccessMsgPage("您没有访问该页面的权限"));
                Response.End();
            }
            
        }

        private void BindData()
        {
            int _loginID = -2;
            string _ownGroup = string.Empty;
            string _oneSelf = string.Empty;

            _loginID = userID;
            #region 调整分组前数据权限
            /*
            //判断数据权限，数据权限如果为 2-全部，则查看所有数据
            Entities.UserDataRigth model_userDataRight = BLL.UserDataRigth.Instance.GetUserDataRigth(userID);
            if (model_userDataRight != null)
            {
                if (model_userDataRight.RightType != 2)//数据权限不为 2-全部
                {
                    _loginID = userID;
                    //判断分组权限，如果权限是2-本组，则能看到本组人创建的信息；如果权限是1-本人，则只能看本人创建的信息 
                    DataTable dt_userGroupDataRight = BLL.UserGroupDataRigth.Instance.GetUserGroupDataRigthByUserID(userID);
                    string ownGroup = string.Empty;//权限是本组的 组串
                    string oneSelf = string.Empty; //权限是本人的 组串
                    for (int i = 0; i < dt_userGroupDataRight.Rows.Count; i++)
                    {
                        if (dt_userGroupDataRight.Rows[i]["RightType"].ToString() == "2")
                        {
                            ownGroup += dt_userGroupDataRight.Rows[i]["BGID"].ToString() + ",";
                        }
                        if (dt_userGroupDataRight.Rows[i]["RightType"].ToString() == "1")
                        {
                            oneSelf += dt_userGroupDataRight.Rows[i]["BGID"].ToString() + ",";
                        }
                    }
                    _ownGroup = ownGroup.TrimEnd(',');
                    _oneSelf = oneSelf.TrimEnd(',');
                }
            }*/
            #endregion

            //默认显示上周一周话务数据
            //上周一时间=today-(6+today.dayofweek)
            string sBeginTime = "", sEndTime = "";
            if (string.IsNullOrEmpty(BeginTime) && string.IsNullOrEmpty(EndTime))
            {
                DateTime LastMonday = DateTime.Now.AddDays(-(6 + Convert.ToDouble(DateTime.Now.DayOfWeek)));
                DateTime LastSunday = LastMonday.AddDays(6);

                //sBeginTime = LastMonday.ToShortDateString() + " 00:00:00";
                //sEndTime = LastSunday.ToShortDateString() + " 23:59:59";
                sBeginTime = LastMonday.ToShortDateString();
                sEndTime = LastSunday.ToShortDateString();
            }
            else
            {
                //sBeginTime = BeginTime + " 00:00:00";
                //sEndTime = EndTime + " 23:59:59";
                sBeginTime = BeginTime;
                sEndTime = EndTime;
            }

            Entities.QueryCallRecordInfo query = BLL.CallRecordInfo.Instance.GetQueryModel(
                "", "", "", "", "", sBeginTime, sEndTime, "", "", "",
                "", "", AgentGroup, CallStatus, _loginID, _ownGroup, _oneSelf, "", "", "", "", ""
                );

            query.QueryType = RequestQueryType;
            query.CreateUserID = RequestAgentUserID;
            query.AgentNum = RequestAgentNum;
            string tableEndName = BLL.Util.CalcTableNameByMonth(3, CommonFunction.ObjectToDateTime(query.BeginTime)); 
            DataTable dt = BLL.CallRecordInfo.Instance.GetCallPhoneReport(query, "StatisticsTime DESC,AgentName  ", BLL.PageCommon.Instance.PageIndex, 9999999,tableEndName, out RecordCount);
            DataTable dt2 = BLL.CallRecordInfo.Instance.GetCallPhoneReport(query, tableEndName);
            object[] objArray = new object[dt.Columns.Count];
            objArray[0] = "合计共(" + RecordCount + ")项";
            objArray[1] = "--";
            objArray[2] = "--";
            objArray[3] = 0;
            for (int j = 0; j < dt2.Columns.Count; j++)
            {
                objArray[j + 4] = dt2.Rows[0][j];
            }
            dt.Rows.Add(objArray);
            ExportData(dt);
        }

        private void ExportData(DataTable dt)
        {
            if (dt != null)
            {
                for (int i = dt.Columns.Count - 1; i >= 0; i--)
                {
                    if (dt.Columns[i].ColumnName.ToUpper() != "STATISTICSTIME"
                        && dt.Columns[i].ColumnName.ToUpper() != "AGENTNAME"
                        && dt.Columns[i].ColumnName.ToUpper() != "AGENTNUM"
                        && dt.Columns[i].ColumnName.ToUpper() != "OUTCALLCOUNT"
                        && dt.Columns[i].ColumnName.ToUpper() != "TALKSCOUNT"
                        && dt.Columns[i].ColumnName.ToUpper() != "JTRATE"
                        && dt.Columns[i].ColumnName.ToUpper() != "TALKTIME"
                        && dt.Columns[i].ColumnName.ToUpper() != "RINGTIME"
                        && dt.Columns[i].ColumnName.ToUpper() != "AGRingTime".ToUpper()
                        && dt.Columns[i].ColumnName.ToUpper() != "AGTalkTime".ToUpper()
                        && dt.Columns[i].ColumnName.ToUpper() != "LoginOnTime".ToUpper()
                        && dt.Columns[i].ColumnName.ToUpper() != "WorkEfficiency".ToUpper()
                        )
                    {
                        dt.Columns.Remove(dt.Columns[i].ColumnName);
                    }
                    else
                    {
                        #region 修改列名

                        switch (dt.Columns[i].ColumnName)
                        {
                            case "StatisticsTime": dt.Columns[i].ColumnName = "日期"; break;
                            case "AgentName": dt.Columns[i].ColumnName = "客服"; break;
                            case "AgentNum": dt.Columns[i].ColumnName = "工号"; break;
                            case "OutCallCount": dt.Columns[i].ColumnName = "外呼电话总量"; break;
                            case "TalksCount": dt.Columns[i].ColumnName = "外呼接通量"; break;
                            case "JTRate": dt.Columns[i].ColumnName = "外呼接通率"; break;
                            case "TalkTime": dt.Columns[i].ColumnName = "总通话时长"; break;
                            case "RingTime": dt.Columns[i].ColumnName = "总振铃时长"; break;
                            case "LoginOnTime": dt.Columns[i].ColumnName = "总在线时长"; break;
                            case "WorkEfficiency": dt.Columns[i].ColumnName = "工时利用率"; break;
                            case "AGTalkTime": dt.Columns[i].ColumnName = "平均通话时长(秒)"; break;
                            case "AGRingTime": dt.Columns[i].ColumnName = "平均振铃时长(秒)"; break;


                        }

                        #endregion
                    }
                }
                //ExcelInOut.CreateEXCEL(dt, "呼出报表" + DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), RequestBrowser);
                BLL.Util.ExportToSCV("呼出报表" + DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), dt);
            }
        }
    }
}