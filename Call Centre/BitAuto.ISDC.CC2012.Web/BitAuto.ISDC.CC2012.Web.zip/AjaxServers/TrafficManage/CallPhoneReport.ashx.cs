﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.SessionState;
using BitAuto.ISDC.CC2012.Entities;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.TrafficManage
{
    /// <summary>
    /// CallPhoneReport 的摘要说明
    /// </summary>
    public class CallPhoneReport : IHttpHandler, IRequiresSessionState
    {
        #region 参数
        private string BeginTime
        {
            get
            {
                return HttpContext.Current.Request["BeginTime"] == null ? "" :
                HttpUtility.UrlDecode(HttpContext.Current.Request["BeginTime"].ToString().Trim());
            }
        }

        private string EndTime
        {
            get
            {
                return HttpContext.Current.Request["EndTime"] == null ? "" :
                HttpUtility.UrlDecode(HttpContext.Current.Request["EndTime"].ToString().Trim());
            }
        }

        private string AgentGroup
        {
            get
            {
                return HttpContext.Current.Request["AgentGroup"] == null ? "" :
                HttpUtility.UrlDecode(HttpContext.Current.Request["AgentGroup"].ToString().Trim());
            }
        }


        /// <summary>
        /// 电话状态（1-呼入，2-呼出）
        /// </summary>
        public string CallStatus
        {
            get
            {
                return HttpContext.Current.Request["CallStatus"] == null ? "" :
                HttpUtility.UrlDecode(HttpContext.Current.Request["CallStatus"].ToString().Trim());
            }
        }
        /// <summary>
        /// 查询类型：1月，2周，3日
        /// </summary>
        private int RequestQueryType
        {
            get { return string.IsNullOrEmpty(HttpContext.Current.Request["QueryType"]) ? 1 : Convert.ToInt32(HttpUtility.UrlDecode(HttpContext.Current.Request["QueryType"])); }
        }
        private string RequestAgentNum
        {
            get { return string.IsNullOrEmpty(HttpContext.Current.Request["AgentNum"]) ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["AgentNum"].ToString()); }
        }
        private int RequestAgentUserID
        {
            get { return string.IsNullOrEmpty(HttpContext.Current.Request["AgentUserID"]) ? -2 : Convert.ToInt32(HttpUtility.UrlDecode(HttpContext.Current.Request["AgentUserID"])); }
        }
        #endregion
        bool success = true;
        string result = "";
        public void ProcessRequest(HttpContext context)
        {
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();

            context.Response.ContentType = "text/plain";
            string message = "";
            if ((context.Request["Action"] + "").Trim() == "CallPhoneReportTotal")
            {
                //默认显示上周一周话务数据
                //上周一时间=today-(6+today.dayofweek)
                string sBeginTime = "", sEndTime = "";
                if (string.IsNullOrEmpty(BeginTime) && string.IsNullOrEmpty(EndTime))
                {
                    DateTime LastMonday = DateTime.Now.AddDays(-(6 + Convert.ToDouble(DateTime.Now.DayOfWeek)));
                    DateTime LastSunday = LastMonday.AddDays(6);

                    sBeginTime = LastMonday.ToShortDateString();
                    sEndTime = LastSunday.ToShortDateString();
                }
                else
                {
                    sBeginTime = BeginTime;
                    sEndTime = EndTime;
                }

                int _loginID = BLL.Util.GetLoginUserID();

                Entities.QueryCallRecordInfo query = BLL.CallRecordInfo.Instance.GetQueryModel(
                    "", "", "", "", "", sBeginTime, sEndTime, "", "", "",
                    "", "", AgentGroup, CallStatus, _loginID, "", "", "", "", "", "", ""
                    );

                query.QueryType = RequestQueryType;
                query.CreateUserID = RequestAgentUserID;
                query.AgentNum = RequestAgentNum;
                string tableEndName = BLL.Util.CalcTableNameByMonth(3, CommonFunction.ObjectToDateTime(query.BeginTime));
                DataTable dt = BLL.CallRecordInfo.Instance.GetCallPhoneReport(query, tableEndName);


                JsonData jsondata = new JsonData();
                if (string.IsNullOrEmpty(dt.Rows[0]["TalksCount"].ToString()))
                {
                    jsondata.AGRingTime = "0.00";
                    jsondata.AGTalkTime = "0.00";
                    jsondata.JTRate = "0.00%";
                    jsondata.LoginOnTime = "0";
                    jsondata.OutCallCount = 0;
                    jsondata.RingTime = "0";
                    jsondata.TalksCount = 0;
                    jsondata.TalkTime = "0";
                    jsondata.WorkEfficiency = "0.00%";
                }
                else
                {
                    jsondata.AGRingTime = dt.Rows[0]["AGRingTime"].ToString();
                    jsondata.AGTalkTime = dt.Rows[0]["AGTalkTime"].ToString();
                    jsondata.JTRate = dt.Rows[0]["JTRate"].ToString();
                    jsondata.LoginOnTime = dt.Rows[0]["LoginOnTime"].ToString();
                    jsondata.OutCallCount = Convert.ToInt32(dt.Rows[0]["OutCallCount"]);
                    jsondata.RingTime = dt.Rows[0]["RingTime"].ToString();
                    jsondata.TalksCount = Convert.ToInt32(dt.Rows[0]["TalksCount"]);
                    jsondata.TalkTime = dt.Rows[0]["TalkTime"].ToString();
                    jsondata.WorkEfficiency = dt.Rows[0]["WorkEfficiency"].ToString();
                }

                message = Newtonsoft.Json.JavaScriptConvert.SerializeObject(jsondata);
                context.Response.Write(message);
                context.Response.End();
            }
            else
            {
                success = false;
                message = "request error";
                BitAuto.ISDC.CC2012.BLL.AJAXHelper.WrapJsonResponse(success, result, message);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }

    public class JsonData
    {
        public int OutCallCount { get; set; }
        public int TalksCount { get; set; }
        public string JTRate { get; set; }
        public string TalkTime { get; set; }
        public string RingTime { get; set; }
        public string AGRingTime { get; set; }
        public string AGTalkTime { get; set; }
        public string LoginOnTime { get; set; }
        public string WorkEfficiency { get; set; }
    }
}