﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.ISDC.CC2012.Entities;
using System.Data.SqlClient;
using BitAuto.Utils.Data;
using BitAuto.ISDC.CC2012.Entities.CallReport;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CallReport
{
    public partial class InComingCallDetails : PageBase
    {
        #region
        public string AgentID  //即UserID
        {
            get { return BLL.Util.GetCurrentRequestStr("AgentID"); }
        }
        public string AgentNum
        {
            get { return BLL.Util.GetCurrentRequestStr("AgentNum"); }
        }
        public string StartTime
        {
            get { return BLL.Util.GetCurrentRequestStr("StartTime"); }
        }
        public string EndTime
        {
            get { return BLL.Util.GetCurrentRequestStr("EndTime"); } 
        }
        public string BusinessType
        {
            get { return BLL.Util.GetCurrentRequestStr("BusinessType");}
        }
        public string QueryArea
        {
            get { return BLL.Util.GetCurrentRequestStr("QueryArea"); }
        }
        public string QueryType
        {
            get { return BLL.Util.GetCurrentRequestStr("QueryType"); }
        }
        #endregion

        public int PageSize = BLL.PageCommon.Instance.PageSize = 20;
        public int RecordCount;
        public int userID = 0;
        public int GroupLength = 8;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                userID = BLL.Util.GetLoginUserID();
                BindInComingCallData();
            }
        }

        private void BindInComingCallData()
        {
            string newAgentIDS = "";
            #region   根据AgentNum找到对应的AgentIds

           
            if (string.IsNullOrEmpty(this.AgentID))
            {
                if (!string.IsNullOrEmpty(this.AgentNum))
                {
                    DataTable dtModel = BLL.EmployeeAgent.Instance.GetEmployeeAgentsByAgentNum(this.AgentNum);
                    string agentIDFromAgentNum = "";
                    for (int i = 0; i < dtModel.Rows.Count; i++)
                    {
                        agentIDFromAgentNum += "," + dtModel.Rows[i]["UserID"].ToString();
                    }

                    if (!string.IsNullOrEmpty(agentIDFromAgentNum))
                    {
                        agentIDFromAgentNum = agentIDFromAgentNum.Substring(1, agentIDFromAgentNum.Length - 1);
                    }

                    if (!string.IsNullOrEmpty(agentIDFromAgentNum))
                    {
                        newAgentIDS = agentIDFromAgentNum;
                    }
                    else
                    {
                        newAgentIDS = "-100";
                    }
                }
            }
            else
            {
                newAgentIDS = this.AgentID;
            }
 
            #endregion


            QueryInComingCallDetails query = new QueryInComingCallDetails();
            query.StartTime = this.StartTime;
            query.EndTime = this.EndTime;
            query.AgentID = newAgentIDS;
            query.BusinessType = this.BusinessType;
            query.QueryArea = this.QueryArea;
            query.QueryType = this.QueryType;
            query.LoginUserId = BLL.Util.GetLoginUserID();

            string tableEndName = BLL.Util.CalcTableNameByMonth(3, CommonFunction.ObjectToDateTime(query.StartTime));
            repeaterList.DataSource = BLL.CallRecord_ORIG.Instance.GetInComingCallData(query, PageSize, BLL.PageCommon.Instance.PageIndex,tableEndName, out RecordCount);
            repeaterList.DataBind();


            litPagerDown.Text = BLL.PageCommon.Instance.LinkStringByPost(BLL.Util.GetUrl(), GroupLength, RecordCount, PageSize, BLL.PageCommon.Instance.PageIndex, 1);
       
        }
           

        
    }
}