﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.Utils.Config;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.QualityStandard
{
    public partial class List : PageBase
    {
        public string YPFanXianHBuyCarURL = System.Configuration.ConfigurationManager.AppSettings["EPEmbedCCHBugCar_URL"].ToString();//惠买车URL
        public string EPEmbedCCHBuyCar_APPID = System.Configuration.ConfigurationManager.AppSettings["EPEmbedCCHBuyCar_APPID"];//易湃签入CC页面，惠买车APPID
        public string tableEndName = "";

        /// <summary>
        /// JSON字符串
        /// </summary>
        public string JsonStr
        {
            get
            {
                return HttpContext.Current.Request["JsonStr"] == null ? string.Empty :
                  HttpUtility.UrlDecode(HttpContext.Current.Request["JsonStr"].ToString());
            }

        }

        public int PageSize = 20;
        public int GroupLength = 8;
        public int RecordCount;
        private int userID = 0;

        bool right_view;            //查看权限 
        bool right_firstInstance; //初审
        bool right_reviewInstance;//复审
        bool right_score;            //评分

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                userID = BLL.Util.GetLoginUserID();
                right_view = BLL.Util.CheckRight(userID, "SYS024BUT600101");
                right_firstInstance = BLL.Util.CheckRight(userID, "SYS024BUT600102");
                right_reviewInstance = BLL.Util.CheckRight(userID, "SYS024BUT600103");
                right_score = BLL.Util.CheckRight(userID, "SYS024BUT600104");
                BindData();
            }
        }

        public string GetViewUrl(string BusinessID, string GetViewUrl, string Source, string callID, string BGID, string SCID)
        {
            string url = "#";

            if (GetViewUrl != string.Empty && GetViewUrl != null)
            {
                Int64 _callid;
                int _source;
                if (!Int64.TryParse(callID, out _callid) || !int.TryParse(Source, out _source))
                {
                    return url;
                }

                DataTable dt = null;
                switch (_source)
                {
                    //如果为1，表示是数据清洗且来源为Excel的，再根据CarType去查询
                    //如果为2，表示是数据清洗且来源为CRM的，再根据CarType去查询
                    case 1:
                    case 2:
                        dt = BLL.CallRecord_ORIG_Business.Instance.getListBySourceAndCallID(_source, _callid, tableEndName);
                        if (dt != null && dt.Rows.Count > 0)
                        {
                            url = string.Format(dt.Rows[0]["BusinessDetailURL"].ToString(), BusinessID);
                        }
                        break;
                    case 0:
                        //add by qizq 根据业务id，链接地址，分组分类，和创建人，来取最终链接地址，包括易湃业务 2014-4-22
                        url = BLL.CallRecord_ORIG_Business.Instance.GetViewUrl(BusinessID, GetViewUrl, BGID, SCID);
                        break;
                }
            }
            //如果是惠买车业务
            //if (BGID == EPHBuyCarBGID && SCID == EPHBuyCarSCID)
            if (BLL.Util.isHuiMaiCHE(BGID, SCID))
            {
                return "<a href=\"javascript:void(0)\" urlstr='" + url + "' onclick=\"GoToEpURL(this,'" + YPFanXianHBuyCarURL + "','" + EPEmbedCCHBuyCar_APPID + "')\" >" + BusinessID + "</a>";
            }
            else if (BLL.Util.isEasySetOff(BGID, SCID))
            {
                return "<a href=\"javascript:void(0)\" urlstr='" + url + "' onclick=\"var obj = new Object();obj.businessType = 'jingzhunguanggao';obj.GoToEPURL='" + url + "';OtherBusinessLogin(obj);\" >" + BusinessID + "</a>";
            }
            else if (BLL.Util.isCarFinancial(BGID, SCID))
            {
                return "<a  href=\"javascript:void(0)\" onclick=\"var obj = new Object();obj.businessType = 'yichechedai';obj.callbackurl='" + url + "';OtherBusinessLogin(obj);\">" + BusinessID + "</a>";
            }
            //不是惠车业务
            else
            {
                return "<a href='" + url + "' target=\"_blank\">" + BusinessID + "</a>";
            }
        }
        //绑定数据
        public void BindData()
        {
            Entities.QueryCallRecordInfo query = new Entities.QueryCallRecordInfo();

            string errMsg = string.Empty;
            BLL.ConverToEntitie<Entities.QueryCallRecordInfo> conver = new BLL.ConverToEntitie<Entities.QueryCallRecordInfo>(query);
            errMsg = conver.Conver(JsonStr);

            #region 从JSONSTR中解析出通话时间
            string begintime = "";
            string endtime = "";
            string[] array1 = JsonStr.Split('&');
            if (array1.Length >= 3)
            {
                begintime = array1[1].Split('=')[1];
                if (!string.IsNullOrEmpty(begintime))
                {
                    begintime = begintime.Insert(10, " ");
                    query.BeginTime = DateTime.Parse(begintime);
                }
                endtime = array1[2].Split('=')[1];
                if (!string.IsNullOrEmpty(endtime))
                {
                    endtime = endtime.Insert(10, " ");
                    query.EndTime = DateTime.Parse(endtime);
                }
            }
            #endregion

            if (errMsg != "")
            {
                return;
            }
            query.LoginID = userID;
            query.IsFilterNull = 1;
            int RecordCount = 0;

            tableEndName = BLL.Util.CalcTableNameByMonth(3, query.BeginTime.Value);
            DataTable dt = BLL.QS_Result.Instance.GetQS_ResultList(query, " cob.CreateTime desc ", BLL.PageCommon.Instance.PageIndex, PageSize, tableEndName, out RecordCount);

            repeaterTableList.DataSource = dt;
            repeaterTableList.DataBind();

            AjaxPager.PageSize = 20;
            AjaxPager.InitPager(RecordCount);
        }

        //绑定操作
        public string oper(string status, string rtid, string qs_rid, string callID, string CreaterID)
        {
            string operStr = string.Empty;
            int _status;
            int _rtid;
            int _userid;
            if (!int.TryParse(status, out _status) || !int.TryParse(rtid, out _rtid) || !int.TryParse(CreaterID, out _userid))
            {
                return operStr;
            }

            switch (_status)
            {
                case 0://如果没有评分表怎不显示后面的评分链接
                    if (string.IsNullOrEmpty(rtid) || _rtid == -1)
                    {
                        //operStr += score(0, qs_rid, "0");
                        return operStr;
                    }
                    else
                    {
                        operStr += score(_rtid, qs_rid, callID);
                    }
                    break;
                case (int)Entities.QSResultStatus.WaitScore:
                    operStr += score(_rtid, qs_rid, callID);
                    break;
                case (int)Entities.QSResultStatus.Submitted:
                    operStr += view(qs_rid, _userid);
                    break;
                case (int)Entities.QSResultStatus.TobeFirstInstance:
                    operStr += firstInstance(qs_rid);
                    break;
                case (int)Entities.QSResultStatus.TobeReviewInstance:
                    operStr += reviewInstance(qs_rid);
                    break;
                case (int)Entities.QSResultStatus.RatedScore:
                    //operStr += viewforend(qs_rid);
                    break;
                case (int)Entities.QSResultStatus.Claimed:
                    //operStr += viewforend(qs_rid);
                    break;
            }
            return operStr;
        }

        //真实的查看
        private string viewforend(string qs_rid)
        {
            if (right_view)
            {
                return "<a href=\"/QualityStandard/QualityResultManage/QualityResultView.aspx?QS_RID=" + qs_rid + "&tableEndName=" + tableEndName + "\" target='_blank'>查看</a>&nbsp;";
            }
            else
            {
                return "";
            }
        }

        //申诉的查看
        private string view(string qs_rid, int _userid)
        {
            if (right_view && userID == _userid)
            {
                return "<a href=\"/QualityStandard/Dispose.aspx?QS_RID=" + qs_rid + "&tableEndName=" + tableEndName + "\" target='_blank'>查看</a>&nbsp;";
            }
            else
            {
                return "";
            }
        }

        //初审
        private string firstInstance(string qs_rid)
        {
            if (right_firstInstance)
            {
                return "<a href=\"/QualityStandard/Dispose.aspx?QS_RID=" + qs_rid + "&tableEndName=" + tableEndName + "\" target='_blank'>初审</a>&nbsp;";
            }
            else
            {
                return "";
            }
        }

        //复审
        private string reviewInstance(string qs_rid)
        {
            if (right_reviewInstance)
            {
                return "<a href=\"/QualityStandard/Dispose.aspx?QS_RID=" + qs_rid + "&tableEndName=" + tableEndName + "\" target='_blank'>复审</a>&nbsp;";
            }
            else
            {
                return "";
            }
        }

        //评分
        private string score(int RTID, string RID, string CallID)
        {
            if (right_score)
            {
                return "<a onclick=\"javascript:clickScore('" + RTID + "','" + RID + "','" + CallID + "','" + tableEndName + "')\" href=\"javascript:void(0);\" >评分</a>&nbsp;";
            }
            else
            {
                return "";
            }
        }
    }
}

