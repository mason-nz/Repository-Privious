﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers
{
    public partial class CustBasicInfoPop : PageBase
    {

        private HttpRequest Request
        {
            get { return HttpContext.Current.Request; }
        }

        protected string CRMCustID
        {
            get
            {
                if (Request["CRMCustID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CRMCustID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        protected string CustName
        {
            get
            {
                if (Request["CustName"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CustName"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        protected string Tel
        {
            get
            {
                if (Request["Tel"] != null)
                {
                    return HttpUtility.UrlDecode(Request["Tel"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        protected string Sex
        {
            get
            {
                if (Request["Sex"] != null)
                {
                    return HttpUtility.UrlDecode(Request["Sex"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        protected string CustType  //3-经销商；4-个人；
        {
            get
            {
                if (Request["CustType"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CustType"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bindMember();
            }
        }

        protected void bindMember()
        {
            if (CustType != "3" || CRMCustID == string.Empty)
            {
                return;
            }

            DataTable dt = BitAuto.YanFa.Crm2009.BLL.CstMember.Instance.SelectByCustID(CRMCustID);
            popSelMemberName.DataSource = dt;
            popSelMemberName.DataTextField = "FullName";
            popSelMemberName.DataValueField = "MemberCode";
            popSelMemberName.DataBind();
        }
    }
}