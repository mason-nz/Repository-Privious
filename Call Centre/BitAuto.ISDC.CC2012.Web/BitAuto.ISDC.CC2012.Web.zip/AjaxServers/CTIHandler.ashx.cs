﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using BitAuto.ISDC.CC2012.BLL;
using System.Web.SessionState;
using System.Data;
using BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo;
using System.Threading;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers
{
    /// <summary>
    /// CTIHandler 的摘要说明
    /// </summary>
    public class CTIHandler : IHttpHandler, IRequiresSessionState
    {
        #region 属性定义
        public string RequestAction
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("Action").ToString();
            }
        }
        public string RequestTel
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("Tel").ToString().Trim();
            }
        }
        public string RequestSessionID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("SessionID").ToString().Trim();
            }
        }
        public string RequestExtensionNum
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("ExtensionNum").ToString().Trim();
            }
        }
        public string RequestPhoneNum
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("PhoneNum").ToString().Trim();
            }
        }
        public string RequestANI
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("ANI").ToString().Trim();
            }
        }
        public string RequestCallStatus
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CallStatus").ToString().Trim();
            }
        }
        public string RequestTaskTypeID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("TaskTypeID").ToString().Trim();
            }
        }
        public string RequestAudioURL
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("AudioURL").ToString().Trim();
            }
        }
        public string RequestAgentRingTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("AgentRingTime").ToString().Trim();
            }

        }
        public string RequestCustomerRingTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CustomerRingTime").ToString().Trim();
            }
        }
        public string RequestEstablishBeginTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishBeginTime").ToString().Trim();
            }
        }
        public string RequestEstablishEndTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishEndTime").ToString().Trim();
            }
        }
        public string RequestSkillGroup
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("SkillGroup").ToString().Trim();
            }
        }
        public string RequestCustID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CustID").ToString().Trim();
            }
        }
        public string RequestCustName
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CustName").ToString().Trim();
            }
        }
        public string RequestCallRecordID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CallRecordID").ToString().Trim();
            }
        }
        public string RequestAfterWorkTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("AfterWorkTime").ToString().Trim();
            }
        }
        public string RequestLogMsg
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("LogMsg").ToString().Trim();
            }
        }
        public string RequestEventName
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EventName").ToString().Trim();
            }
        }
        private string callID;
        /// <summary>
        /// CTI中通话ID
        /// </summary>
        public string CallID
        {
            get
            {
                if (callID == null)
                {
                    callID = BLL.Util.GetCurrentRequestStr("CallID").ToString().Trim();
                }
                return callID;
            }
        }
        /// <summary>
        /// 电话
        /// </summary>
        private string teldata;
        public string TelData
        {
            get
            {
                if (teldata == null)
                {
                    teldata = BLL.Util.GetCurrentRequestStr("TelData").ToString().Trim();
                }
                return teldata;
            }
        }
        #endregion

        public void ProcessRequest(HttpContext context)
        {
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();
            BLL.Loger.Log4Net.Info("[CTIHandler.ashx]Inbound ProcessRequest begin...PhoneNum:" + RequestPhoneNum + ",ANI:" + RequestANI + ",RequestAction:" + RequestAction);
            string msg = string.Empty;
            context.Response.ContentType = "text/plain";
            //获取客户ID
            if (RequestAction.ToLower() == "getcustid")
            {
                try
                {
                    msg = CTIHandlerHelper.GetCustIDByTel(RequestTel);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "insertcallrecord")
            {
                try
                {
                    InsertCallRecord(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "insertcallrecordorigbusiness")
            {
                Loger.Log4Net.Info("[AjaxServers\\CTIHandler.ashx]insertcallrecordorigbusiness begin...");
                try
                {
                    InsertCallRecord_ORIG_Business(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                    Loger.Log4Net.Info("[AjaxServers\\CTIHandler.ashx]insertcallrecordorigbusiness errorMessage...is:" + ex.Message);
                    Loger.Log4Net.Info("[AjaxServers\\CTIHandler.ashx]insertcallrecordorigbusiness errorSource...is:" + ex.Source);
                    Loger.Log4Net.Info("[AjaxServers\\CTIHandler.ashx]insertcallrecordorigbusiness errorStackTrace...is:" + ex.StackTrace);
                }
            }
            else if (RequestAction.ToLower() == "insertemptycusthistoryinfo")
            {
                try
                {
                    InsertEmptyCustHistoryInfo(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "updateemptycusthistoryinfocustid")
            {
                try
                {
                    UpdateCallRecordCustID(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "updatecallrecordlasttime")
            {
                try
                {
                    UpdateCallRecordLastTime(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "updateafterworkbegintime")
            {
                try
                {
                    UpdateCallRecordAfterWorkBeginTime(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "updateafterworktime")
            {
                try
                {
                    UpdateCallRecordAfterWorkTime(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "getareaid")
            {
                try
                {
                    GetAreaID(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "getcallrecordid")
            {
                try
                {
                    GetCallRecordIDBySessionID(out msg);
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
            }
            else if (RequestAction.ToLower() == "checkdata")
            {
                CheckData(out msg);
            }
            else if (RequestAction.ToLower() == "insertrecordeventlog")
            {
                //InsertRecordEventLog();
            }
            else if (RequestAction.ToLower() == "uccalloutlog")
            {
                int loginID = BLL.Util.GetLoginUserID();
                BLL.Loger.Log4Net.Info("[CTIHandler.ashx]UCCallOut...Start...UserID:" + loginID + ",phoneNum:" + RequestPhoneNum);
            }
            BLL.Loger.Log4Net.Info("[CTIHandler.ashx]Inbound ProcessRequest bye...PhoneNum:" + RequestPhoneNum + ",ANI:" + RequestANI);
            context.Response.Write(msg);
        }
        /// <summary>
        /// 验证是北京号码还是外地号码
        /// </summary>
        /// <param name="msg"></param>
        public void CheckData(out string msg)
        {
            msg = string.Empty;
            if (!string.IsNullOrEmpty(TelData))
            {
                bool flag = false;
                flag = PhoneNumDataDict.IsLocalityNumber(TelData);
                if (flag)
                {
                    msg = "true";
                }
                else
                {
                    msg = "false";
                }
            }
            else
            {
                msg = "error";
            }


        }

        //插入通话记录
        public void InsertCallRecord(out string msg)
        {
            msg = "";
            try
            {
                //西门子callid
                Int64 _callID = 0;
                Int64.TryParse(CallID, out _callID);

                Entities.CallRecordInfo oldmodel = BLL.CallRecordInfo.Instance.GetCallRecordInfoByCallID(_callID);
                if (oldmodel != null)
                {
                    //已存在不在插入
                    return;
                }

                BLL.Loger.Log4Net.Info("插入来电去电记录：" + _callID);

                Entities.CallRecordInfo callRecordInfo = new Entities.CallRecordInfo();
                callRecordInfo.AudioURL = RequestAudioURL;
                callRecordInfo.BeginTime = DateTime.Now;
                callRecordInfo.CallStatus = int.Parse(RequestCallStatus);
                callRecordInfo.CreateTime = DateTime.Now;
                callRecordInfo.CreateUserID = BLL.Util.GetLoginUserID();
                callRecordInfo.ExtensionNum = RequestExtensionNum;
                callRecordInfo.PhoneNum = RequestPhoneNum;
                callRecordInfo.ANI = RequestANI;
                callRecordInfo.SessionID = RequestSessionID;
                callRecordInfo.TallTime = 0;
                int taskTypeId = 0;
                if (int.TryParse(RequestTaskTypeID, out taskTypeId))
                {
                    callRecordInfo.TaskTypeID = taskTypeId;
                }
                int agentRingTime = 0;
                if (int.TryParse(RequestAgentRingTime, out agentRingTime))
                {
                    callRecordInfo.AgentRingTime = agentRingTime;
                }

                //客户振铃时长
                int CustomRingTime = 0;
                if (int.TryParse(RequestCustomerRingTime, out CustomRingTime))
                {
                    callRecordInfo.CustomRingTime = CustomRingTime;
                }

                DateTime beginTime = DateTime.Now;
                if (DateTime.TryParse(RequestEstablishBeginTime, out beginTime))
                {
                    callRecordInfo.BeginTime = beginTime;
                }
                //如果是呼入电话，计算通话时长，并记录结束时间
                if (callRecordInfo.CallStatus == 1)
                {
                    DateTime endTime = DateTime.Now;
                    if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
                    {
                        TimeSpan tsSpan = (TimeSpan)(endTime - beginTime);
                        callRecordInfo.TallTime = (int)tsSpan.TotalSeconds;
                    }
                    callRecordInfo.EndTime = endTime;
                }
                callRecordInfo.AfterWorkTime = 0;
                callRecordInfo.SkillGroup = RequestSkillGroup;
                if (!string.IsNullOrEmpty(RequestCustID))
                {
                    Entities.CustBasicInfo custInfo = BLL.CustBasicInfo.Instance.GetCustBasicInfo(RequestCustID);
                    if (custInfo != null)
                    {
                        callRecordInfo.CustID = custInfo.CustID;
                        callRecordInfo.CustName = custInfo.CustName;
                        callRecordInfo.Contact = custInfo.CustName;
                    }
                    BLL.CustBasicInfo.Instance.Update(custInfo);
                }

                callRecordInfo.BGID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfBGIDByUserID(Convert.ToInt32(callRecordInfo.CreateUserID));
                callRecordInfo.SCID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfSCIDByUserID(Convert.ToInt32(callRecordInfo.CreateUserID));
                callRecordInfo.CallID = _callID;

                msg = BLL.CallRecordInfo.Instance.Insert(callRecordInfo).ToString();

                if (callRecordInfo.CallStatus == 1)//如果是呼入电话则执行，防止外呼初始化插入后，重复记录。
                {
                    string msg2 = "";
                    InsertCallRecord_ORIG_Business(out msg2);
                }
            }
            catch (Exception ex)
            {
                BLL.Loger.Log4Net.Error("插入来电去电记录 异常", ex);
            }
        }

        //插入话务总表跟业务分组中间表记录
        public void InsertCallRecord_ORIG_Business(out string msg)
        {
            msg = "";

            Entities.CallRecord_ORIG_Business callrecordorgbusiness = new Entities.CallRecord_ORIG_Business();

            callrecordorgbusiness.CreateUserID = BLL.Util.GetLoginUserID();
            //增加业务组和分类，个人用户
            //callrecordorgbusiness.BGID = 9;
            //callrecordorgbusiness.SCID = 89;            

            callrecordorgbusiness.BGID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfBGIDByUserID(Convert.ToInt32(callrecordorgbusiness.CreateUserID));
            callrecordorgbusiness.SCID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfSCIDByUserID(Convert.ToInt32(callrecordorgbusiness.CreateUserID));

            //西门子callid
            Int64 _callID = 0;
            if (Int64.TryParse(CallID, out _callID))
            {
            }
            callrecordorgbusiness.CallID = _callID;
            callrecordorgbusiness.CreateTime = DateTime.Now;

            //查询现在表
            if (!BLL.CallRecord_ORIG_Business.Instance.IsExistsByCallID(_callID))
            {
                msg = BLL.CallRecord_ORIG_Business.Instance.Insert(callrecordorgbusiness).ToString();
            }
            else
            {
                msg = BLL.CallRecord_ORIG_Business.Instance.Update(callrecordorgbusiness).ToString();
            }
        }

        //插入空的历史记录，并且把此客户ID和录音流水号进行管理
        public void InsertEmptyCustHistoryInfo(out string msg)
        {
            msg = string.Empty;
            Entities.CustHistoryInfo historyInfo = new Entities.CustHistoryInfo();
            int recordType = 0;
            if (int.TryParse(RequestCallStatus, out recordType))
            {
                historyInfo.RecordType = recordType;
            }
            historyInfo.CustID = RequestCustID;
            historyInfo.CallRecordID = Int64.Parse(RequestCallRecordID);
            historyInfo.CreateTime = DateTime.Now;
            historyInfo.CreateUserID = BLL.Util.GetLoginUserID();
            if (BLL.CustHistoryInfo.Instance.Insert(historyInfo) > 0)
            {
                Entities.CallRecordInfo recordInfo = BLL.CallRecordInfo.Instance.GetCallRecordInfo(historyInfo.CallRecordID);
                recordInfo.CustID = RequestCustID;
                recordInfo.CustName = RequestCustName;
                recordInfo.Contact = RequestCustName;
                recordInfo.SessionID = RequestSessionID;
                recordInfo.AudioURL = RequestAudioURL;

                if (recordInfo.EndTime == Entities.Constants.Constant.DATE_INVALID_VALUE)
                {
                    DateTime endTime = DateTime.Now;
                    if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
                    {
                        TimeSpan tsSpan = (TimeSpan)(endTime - recordInfo.BeginTime);
                        recordInfo.TallTime = (int)tsSpan.TotalSeconds;
                    }
                    recordInfo.EndTime = endTime;
                }


                //把客户ID和流水号进行关联
                if (BLL.CallRecordInfo.Instance.Update(recordInfo) > 0)
                {
                    //如果是来电，修改来电次数
                    if (RequestCallStatus == "1")
                    {
                        Entities.CustBasicInfo custInfo = BLL.CustBasicInfo.Instance.GetCustBasicInfo(RequestCustID);
                        if (custInfo == null)
                        {
                            Loger.Log4Net.Info("[UCDemoHandler]InsertEmptyCustHistoryInfo:修改客户来电次数未找到客户CallID：" + CallID + ",主叫：" + RequestANI + ",被叫：" + RequestPhoneNum + ",分机:" + RequestExtensionNum);
                        }
                        else
                        {
                            custInfo.CallTime = custInfo.CallTime + 1;
                            BLL.CustBasicInfo.Instance.Update(custInfo);
                        }
                    }
                    msg = "success";
                }
            }
        }
        //更新录音结束时间
        public void UpdateCallRecordCustID(out string msg)
        {
            msg = string.Empty;
            Int64 callRecordID = 0;
            if (Int64.TryParse(RequestCallRecordID, out callRecordID))
            {
                Entities.CallRecordInfo callRecordInfo = BLL.CallRecordInfo.Instance.GetCallRecordInfo(callRecordID);
                if (callRecordInfo != null)
                {
                    callRecordInfo.CustID = RequestCustID;
                    if (BLL.CallRecordInfo.Instance.Update(callRecordInfo) > 0)
                    {
                        Entities.CustHistoryInfo historyInfo = BLL.CustHistoryInfo.Instance.GetCustHistoryInfoByCallRecordID(callRecordID);
                        if (historyInfo != null)
                        {
                            historyInfo.CustID = RequestCustID;
                            BLL.CustHistoryInfo.Instance.Update(historyInfo);
                        }
                        msg = "success";
                    }
                }
            }
        }
        //更新录音结束时间
        public void UpdateCallRecordLastTime(out string msg)
        {
            msg = string.Empty;
            if (!string.IsNullOrEmpty(RequestSessionID))
            {
                Entities.CallRecordInfo callRecordInfo = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(RequestSessionID);
                if (callRecordInfo.EndTime == Entities.Constants.Constant.DATE_INVALID_VALUE)
                {
                    DateTime endTime = DateTime.Now;
                    if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
                    {
                        TimeSpan tsSpan = (TimeSpan)(endTime - callRecordInfo.BeginTime);
                        callRecordInfo.TallTime = (int)tsSpan.TotalSeconds;
                    }
                    callRecordInfo.EndTime = endTime;

                    BLL.CallRecordInfo.Instance.Update(callRecordInfo);
                }
            }
        }

        //更新录音事后处理时间
        public void UpdateCallRecordAfterWorkTime(out string msg)
        {
            msg = string.Empty;
            if (!string.IsNullOrEmpty(RequestSessionID))
            {
                Entities.CallRecordInfo callRecordInfo = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(RequestSessionID);
                if (callRecordInfo.AfterWorkBeginTime != Entities.Constants.Constant.DATE_INVALID_VALUE && !string.IsNullOrEmpty(callRecordInfo.AfterWorkBeginTime.ToString()) && callRecordInfo.AfterWorkTime <= 0)
                {
                    TimeSpan ts = (TimeSpan)(DateTime.Now - callRecordInfo.AfterWorkBeginTime);
                    callRecordInfo.AfterWorkTime = (int)ts.TotalSeconds;
                }
                if (BLL.CallRecordInfo.Instance.Update(callRecordInfo) > 0)
                {
                    msg = "success";
                }
            }
        }

        //更新录音事后处理开始时间
        public void UpdateCallRecordAfterWorkBeginTime(out string msg)
        {
            msg = string.Empty;
            if (!string.IsNullOrEmpty(RequestSessionID))
            {
                Entities.CallRecordInfo callRecordInfo = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(RequestSessionID);

                //如果录音开始时间等于初始值，修改录音开始时间为当前时间
                if (callRecordInfo.AfterWorkBeginTime == Entities.Constants.Constant.DATE_INVALID_VALUE)
                {
                    callRecordInfo.AfterWorkBeginTime = DateTime.Now;
                }
                if (BLL.CallRecordInfo.Instance.Update(callRecordInfo) > 0)
                {
                    msg = "success";
                }
            }
        }

        //根据电话号码查询城市ID,如果没有找到返回0
        public void GetAreaID(out string msg)
        {
            msg = string.Empty;
            if (!string.IsNullOrEmpty(RequestPhoneNum))
            {
                int provinceId = -1;
                int cityId = -1;
                BLL.PhoneNumDataDict.GetAreaId(RequestPhoneNum, out provinceId, out cityId);
                msg = "{ProvinceID:'" + provinceId + "',CityID:'" + cityId + "'}";
            }
        }

        //
        public void GetCallRecordIDBySessionID(out string msg)
        {
            msg = string.Empty;
            if (!string.IsNullOrEmpty(RequestSessionID))
            {
                var entity = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(RequestSessionID);
                if (entity != null)
                {
                    msg = entity.RecID.ToString();
                }
            }
        }

        //记录录音时间日志
        public void InsertRecordEventLog()
        {
            Entities.CallEventActionLog logInfo = new Entities.CallEventActionLog();
            logInfo.EventName = RequestEventName;
            logInfo.SessionID = RequestSessionID;
            logInfo.Loginfo = RequestLogMsg;
            logInfo.UserID = BLL.Util.GetLoginUserID();
            logInfo.CreateTime = DateTime.Now;
            BLL.CallEventActionLog.Instance.Insert(logInfo);
        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }

    public class CTIHandlerHelper
    {
        public static string GetCustIDByTel(string tel)
        {
            string msg = "";
            BLL.Loger.Log4Net.Info("[CTIHandlerHelper] GetCustIDByTel=" + tel);
            msg = string.Empty;
            if (!string.IsNullOrEmpty(tel))
            {
                Entities.QueryCustBasicInfo query = new Entities.QueryCustBasicInfo();
                query.Tel = tel;
                int totalCount = 0;
                DataTable dt = BLL.CustBasicInfo.Instance.GetCustBasicInfo(query, null, null, null, "distinct cbi.*", "", 1, 100, "", out totalCount);
                if (totalCount == 1)
                {
                    msg = "{TotalCount:'" + totalCount + "',CustID:'" + dt.Rows[0]["CustID"] + "'}";
                }
                else if (totalCount > 1)
                {
                    msg = "{TotalCount:'" + totalCount + "',CustID:''}";
                }
                else
                {
                    BLL.Loger.Log4Net.Info("[CTIHandlerHelper]开始在CRM客户库查找!主叫号：" + tel);
                    //CRM找到后，不生成到个人用户库，将姓名、电话显示的选择列表，最后在新增个人用户界面保存(要修改的文件：EditCustBaseInfo.ascx,SelectSameTelCustListForClient.aspx)
                    //由于涉及修改文件过多，担心其它页面调用会出问题，不采用此方案                    
                    DataTable dt2 = BLL.CrmCustInfo.Instance.GetCC_CrmContactInfo(tel);
                    operPopCustBasicInfo cbi = new operPopCustBasicInfo();
                    totalCount = dt2.Rows.Count;
                    if (dt2.Rows.Count == 1)
                    {
                        foreach (DataRow row in dt2.Rows)
                        {
                            BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo.CustBasicInfo info = new CustBaseInfo.CustBasicInfo();
                            info.CustName = row["CustName"].ToString();
                            info.Sex = "1";//性别默认先生
                            info.Tel = tel;
                            info.CustCategoryID = "3";//3经销商,4个人
                            string[] array = getMemberInfo(row["CustID"].ToString());
                            info.MemberID = array[0];
                            info.MemberName = array[1];
                            info.OperID = BLL.Util.GetLoginUserID();
                            cbi.InsertCustInfo(info, out msg);

                            if (msg.Contains("true"))
                            {
                                msg = "{TotalCount:'1',CustID:'" + cbi.ccCustID + "'}";
                            }
                        }
                    }
                    else if (dt2.Rows.Count > 1)
                    {
                        //将用户名，电话拼接成JSON返回给
                        msg = "{TotalCount:'" + totalCount + "',CustType:'CRM'}";
                    }
                    BLL.Loger.Log4Net.Info("[CTIHandlerHelper] CRM客户查找个数..." + totalCount + " 主叫号：" + tel);
                }
            }
            BLL.Loger.Log4Net.Info("[CTIHandlerHelper] 查找结果：" + msg);
            return msg;
        }

        private static string[] getMemberInfo(string CRMCustID)
        {
            DataTable dt = BitAuto.YanFa.Crm2009.BLL.CstMember.Instance.SelectByCustID(CRMCustID);
            string[] array = new string[2];
            if (dt.Rows.Count > 0)
            {
                array[0] = dt.Rows[0]["MemberCode"].ToString();
                array[1] = dt.Rows[0]["FullName"].ToString();
            }
            return array;
        }
    }

    public class TelResult
    {
        public int TotalCount { get; set; }
        public string CustID { get; set; }
        public string CustType { get; set; }
    }
}