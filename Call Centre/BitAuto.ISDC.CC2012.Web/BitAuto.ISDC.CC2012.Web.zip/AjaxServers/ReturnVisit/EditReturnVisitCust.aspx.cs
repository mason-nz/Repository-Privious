﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data;
using BitAuto.ISDC.CC2012.Web.Base;
using BitAuto.ISDC.CC2012.BLL;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.ReturnVisit
{
    public partial class EditReturnVisitCust : PageBase
    {
        public string SessionID
        {
            get { return Request.QueryString["SessionID "] != null ? Request.QueryString["SessionID "].Trim() : string.Empty; }
        }
        public string CustID
        {
            get { return Request.QueryString["CustID"] != null ? Request.QueryString["CustID"].Trim() : string.Empty; }
            //get { return Request.QueryString["CustID"] == null ? Request.QueryString["CustID"].Trim() : string.Empty; }
        }
        public string MemberCode
        {
            get { return Request.QueryString["MemberCode"] != null ? Request.QueryString["MemberCode"].Trim() : string.Empty; }
        }
        public string RID
        {
            get { return Request.QueryString["RID"] != null ? Request.QueryString["RID"].Trim() : string.Empty; }
        }

        public string strFillPage = "";
        public string DictType = "101";
        public int PageSize = 10;
        protected void Page_Load(object sender, EventArgs e)
        {
            BitAuto.YanFa.Crm2009.Entities.CustInfo custInfo = BitAuto.YanFa.Crm2009.BLL.CustInfo.Instance.GetCustInfo(CustID);
            if (custInfo != null)
            {
                //如果客户类别是 个人、经纪公司、交易市场，则选中二手车,其他选择新车
                switch (custInfo.TypeID)
                {
                    case "20010":
                    case "20011":
                    case "20012": this.chkTypeSnd.Checked = true; break;
                    default: this.chkTypeNew.Checked = true; break;
                }


                BindText();
                litCustName.InnerText = custInfo.CustName;
            }
            if (!IsPostBack)
            {                        
                ArrayList array_str = BindText();

                if (!string.IsNullOrEmpty(CustID))
                {
                    BindRVType(array_str[3].ToString());
                    BindData(CustID);
                }
                else
                {
                    BindRVType("");
                }
                if (!string.IsNullOrEmpty(CustID) && !string.IsNullOrEmpty(RID))
                {
                    strFillPage = "fillpage();";                    
                }
                else
                {
                    string ContactInfoUserID = "0";
                    if (!string.IsNullOrEmpty(Request["ContactInfoUserID"]))
                    {
                        ContactInfoUserID = Request["ContactInfoUserID"];
                    }
                    strFillPage = "bindVisitType('" + DictType + "','','0','" + array_str[0] + "');showContactInfo('" + ContactInfoUserID + "','0','" + array_str[1] + "','" + array_str[2] + "');";
                }
            }
        }
       

        /// <summary>
        /// 绑定访问方式
        /// </summary>
        private void BindRVType(string rvType)
        {
            DataTable dt = null;
            dt = BLL.Util.GetEnumDataTable(typeof(Entities.EnumRVType));
            if (dt != null && dt.Rows.Count > 0)
            {
                ddlRVType.DataSource = dt;
                ddlRVType.DataTextField = "name";
                ddlRVType.DataValueField = "value";
                ddlRVType.DataBind();
            }
            ddlRVType.Items.Insert(0, new ListItem("请选择", "-1"));

            if (MemberCode == "001")//如果是添加回访记录
            {
                ddlRVType.Disabled = false;
                if (!string.IsNullOrEmpty(rvType))
                {
                    ddlRVType.SelectedIndex = Convert.ToInt32(rvType);
                }
            }
            else
            {
                ddlRVType.SelectedIndex = 2;
                ddlRVType.Disabled = true;
            }
        }

        private void BindData(string custID)
        {
            int i = -1;
            if (int.TryParse(custID, out i))
            {
                DataTable dt = null;
                int count;
                BitAuto.YanFa.Crm2009.Entities.QueryReturnVisit QueryReturnVisit = new BitAuto.YanFa.Crm2009.Entities.QueryReturnVisit();
                QueryReturnVisit.CustID = custID;
                dt = BitAuto.YanFa.Crm2009.BLL.ReturnVisit.Instance.GetReturnVisit(QueryReturnVisit, PageCommon.Instance.PageIndex, PageSize, out count);


                repeaterList.DataSource = dt;
                repeaterList.DataBind();

                //AjaxPager_Custs.PageSize = 10;
                //AjaxPager_Custs.InitPager(count);
                //AjaxPager_Custs.InitPager(count, "divReturnVisitCust", PageSize);
                //AjaxPager_Custs.InitPager(count, "divCooperationProjectList", PageSize, 1);
                int GroupLength = 8;
                litPagerDown.Text = PageCommon.Instance.LinkStringByPost(BLL.Util.GetUrl(), GroupLength, count, PageSize, PageCommon.Instance.PageIndex, 1);
            }
        }
        //如果之前在CC有保存的数据，则将数据拉到页面
        public ArrayList BindText()
        {
            ArrayList al_bind = new ArrayList();
            //string str_visit = "";
            //根据客户取回访信息CC
            DataTable dt_cc_returnVisit = BLL.ProjectTask_ReturnVisit.Instance.GetTable(CustID);
            if (dt_cc_returnVisit.Rows.Count > 0)
            {
                al_bind.Add(dt_cc_returnVisit.Rows[0]["VisitType"].ToString());
                txtRemark.InnerText = dt_cc_returnVisit.Rows[0]["Remark"].ToString();
                //没有回访发现
                //DataTable dt_cc_visitFound = BLL.CC_VisitFound.Instance.GetTable(dt_cc_returnVisit.Rows[0]["RecID"].ToString());
                ////分类 
                //for (int i = 0; i < dt_cc_visitFound.Rows.Count; i++)
                //{
                //    str_visit += dt_cc_visitFound.Rows[i]["FoundType"].ToString() + "," + dt_cc_visitFound.Rows[i]["FoundDescription"].ToString();
                //    str_visit += ";";
                //}
                al_bind.Add("");
                //会员名称
                if (dt_cc_returnVisit.Rows[0]["MemberID"] != DBNull.Value && dt_cc_returnVisit.Rows[0]["MemberID"].ToString() != "null")
                {
                    al_bind.Add(dt_cc_returnVisit.Rows[0]["MemberID"].ToString());
                }
                else
                {
                    al_bind.Add("");
                }

                //访问方式
                al_bind.Add(dt_cc_returnVisit.Rows[0]["RVType"].ToString());
                //客户类别
                int intVal = 0;
                if (dt_cc_returnVisit.Rows[0]["TypeID"] != null && dt_cc_returnVisit.Rows[0]["TypeID"].ToString() != "" && int.TryParse(dt_cc_returnVisit.Rows[0]["TypeID"].ToString(), out intVal))
                {
                    if (intVal > 0)
                    {
                        this.chkTypeNew.Checked = false;
                        this.chkTypeSnd.Checked = false;
                        this.chkTypeYiKa.Checked = false;


                        if ((intVal & (int)Entities.BusinessType.NewCar) == (int)Entities.BusinessType.NewCar)
                        {
                            this.chkTypeNew.Checked = true;
                        }
                        if ((intVal & (int)Entities.BusinessType.HandCar) == (int)Entities.BusinessType.HandCar)
                        {
                            this.chkTypeSnd.Checked = true;
                        }
                        if ((intVal & (int)Entities.BusinessType.YiKa) == (int)Entities.BusinessType.YiKa)
                        {
                            this.chkTypeYiKa.Checked = true;
                        }
                    }
                }

            }
            else
            {
                al_bind.Add("");
                al_bind.Add("");
                al_bind.Add("");
                al_bind.Add("");
            }
            return al_bind;
        }

        protected string getTypeStr(string type)
        {
            string RVType = "";
            switch (type)
            {
                case "1":
                    RVType = "短信联系";
                    break;
                case "2":
                    RVType = "电话联系";
                    break;
                case "3":
                    RVType = "发送传真";
                    break;
                case "4":
                    RVType = "电子邮件";
                    break;
                case "5":
                    RVType = "信件邮递";
                    break;
                case "6":
                    RVType = "一般会议";
                    break;
                case "7":
                    RVType = "上门拜访";
                    break;
                case "8":
                    RVType = "网络即时通信";
                    break;
            }
            return RVType;
        }

        protected string getVisitTypeStr(string type)
        {
            return BitAuto.YanFa.Crm2009.BLL.DictInfo.Instance.GetDictNameByDictID(type);
        }
    }
}