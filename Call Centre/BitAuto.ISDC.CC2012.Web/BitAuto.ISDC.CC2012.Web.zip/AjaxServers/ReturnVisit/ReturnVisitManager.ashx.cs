﻿using System;
using System.Data;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.SessionState;
using Newtonsoft.Json;
using BitAuto.ISDC.CC2012.WebService;
namespace BitAuto.ISDC.CC2012.Web.AjaxServers.ReturnVisit
{
    /// <summary>
    /// $codebehindclassname$ 的摘要说明
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class ReturnVisitManager : IHttpHandler, IRequiresSessionState
    {
        bool success = true;
        string result = "";
        string message = "";
        public HttpContext currentContext;

        #region 属性

        public string Requestrid
        {
            get { return currentContext.Request.Form["rid"] == null ? string.Empty : currentContext.Request.Form["rid"].Trim(); }
        }
        private string SessionID
        {
            get { return currentContext.Request.Form["SessionID"] == null ? string.Empty : currentContext.Request.Form["SessionID"].Trim(); }
        }

        /// <summary>
        /// 客户ID
        /// </summary>
        private string RequestCustID
        {
            get { return currentContext.Request.Form["CustID"] == null ? string.Empty : currentContext.Request.Form["CustID"].Trim(); }
        }
        private string RequestContactInfoUserID
        {
            get { return currentContext.Request.Form["ContactInfoUserID"] == null ? string.Empty : currentContext.Request.Form["ContactInfoUserID"].Trim(); }
        }
        /// <summary>
        ///  
        /// </summary>
        private string RequestBeginTime
        {
            get { return currentContext.Request.Form["BeginTime"] == null ? string.Empty : currentContext.Request.Form["BeginTime"].Trim(); }
        }
        /// <summary>
        ///  
        /// </summary>
        //private string RequestEndTime
        //{
        //    get { return 
        //        currentContext.Request.Form["EndTime"] == null ? string.Empty : currentContext.Request.Form["EndTime"].Trim();
        //    }
        //}
        /// <summary>
        ///  
        /// </summary>
        private string RequestRemark
        {
            get { return currentContext.Request.Form["Remark"] == null ? string.Empty : currentContext.Request.Form["Remark"].Trim(); }
        }
        ///// <summary>
        /////  
        ///// </summary>
        private string RequestRVType
        {
            get { return currentContext.Request.Form["RVType"] == null ? string.Empty : currentContext.Request.Form["RVType"].Trim(); }
        }
        /// <summary>
        /// 职务
        /// </summary>
        private string RequestTitle
        {
            get { return currentContext.Request.Form["Title"] == null ? string.Empty : currentContext.Request.Form["Title"].Trim(); }
        }
        ///// <summary>
        /////  
        ///// </summary>
        //private string RequestBeginTimeHour
        //{
        //    get { return currentContext.Request.Form["BeginTimeHour"] == null ? string.Empty : currentContext.Request.Form["BeginTimeHour"].Trim(); }
        //}
        ///// <summary>
        /////  
        ///// </summary>
        //private string RequestBeginTimeMinute
        //{
        //    get { return currentContext.Request.Form["BeginTimeMinute"] == null ? string.Empty : currentContext.Request.Form["BeginTimeMinute"].Trim(); }
        //}
        ///// <summary>
        ///// 
        ///// </summary>
        //private string RequestEndTimeHour
        //{
        //    get { return currentContext.Request.Form["EndTimeHour"] == null ? string.Empty : currentContext.Request.Form["EndTimeHour"].Trim(); }
        //}
        ///// <summary>
        /////  
        ///// </summary>
        //private string RequestEndTimeMinute
        //{
        //    get { return currentContext.Request.Form["EndTimeMinute"] == null ? string.Empty : currentContext.Request.Form["EndTimeMinute"].Trim(); }
        //}

        //private string RequestReturnVisitCost
        //{
        //    get { return currentContext.Request.Form["ReturnVisitCost"] == null ? string.Empty : currentContext.Request.Form["ReturnVisitCost"].Trim(); }
        //}

        private string RequestRVresult
        {
            get { return currentContext.Request.Form["RVresult"] == null ? string.Empty : currentContext.Request.Form["RVresult"].Trim(); }
        }

        private string RequestRVQuestionStatus
        {
            get { return currentContext.Request.Form["RVQuestionStatus"] == null ? string.Empty : currentContext.Request.Form["RVQuestionStatus"].Trim(); }
        }
        private string RequestRVQuestionRemark
        {
            get { return currentContext.Request.Form["RVQuestionRemark"] == null ? string.Empty : currentContext.Request.Form["RVQuestionRemark"].Trim(); }
        }
        public string MemberId
        {
            get { return currentContext.Request["MemberId"] == null ? string.Empty : currentContext.Request["MemberId"].Trim(); }
        }
        public string VisitType
        {
            get { return currentContext.Request["VisitType"] == null ? string.Empty : currentContext.Request["VisitType"].Trim(); }
        }
        public string VisitFound
        {
            get { return currentContext.Request["VisitFound"] == null ? string.Empty : currentContext.Request["VisitFound"].Trim(); }
        }
        public string TypeID
        {
            get { return currentContext.Request["TypeID"] == null ? string.Empty : currentContext.Request["TypeID"].Trim(); }
        }


        #endregion
        public void ProcessRequest(HttpContext context)
        {
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();
            context.Response.ContentType = "text/plain";
            currentContext = context;
            if ((context.Request["showContactInfo"] + "").Trim() == "yes")
            {
                StringBuilder sb = new StringBuilder();
                BitAuto.YanFa.Crm2009.Entities.QueryContactInfo QueryContactInfo = new BitAuto.YanFa.Crm2009.Entities.QueryContactInfo();
                QueryContactInfo.CustID = RequestCustID;
                int o;
                DataTable dt = BitAuto.YanFa.Crm2009.BLL.ContactInfo.Instance.GetContactInfo(QueryContactInfo, "", 1, 10000, out o);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        sb.Append("{'ID':'" + dr["ID"] + "','Name':'" + dr["CName"] + "'},");
                    }
                    message = sb.ToString().TrimEnd(",".ToCharArray());
                }
                else
                {
                    message = sb.ToString();
                }
                context.Response.Write("[" + message + "]");
                context.Response.End();
            }
            else if ((context.Request["showContactInfobycustid"] + "").Trim() == "yes")
            {
                StringBuilder sb = new StringBuilder();
                DataTable dt = BitAuto.YanFa.Crm2009.BLL.ContactInfo.Instance.GetContactInfoByCustID(RequestCustID);
                if (dt != null)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        string tel = "";
                        if (dr["Phone"] != DBNull.Value)
                        {
                            tel += dr["Phone"].ToString().Trim() + ",";
                        }
                        if (dr["OfficeTel"] != DBNull.Value)
                        {
                            tel += dr["OfficeTel"].ToString().Trim() + ",";
                        }
                        sb.Append("{'ID':'" + dr["ID"] + "','Name':'" + dr["CName"] + "','Tel':'" + tel.Trim(',') + "'},");
                    }
                    message = sb.ToString().TrimEnd(",".ToCharArray());
                }
                else
                {
                    message = sb.ToString();
                }
                context.Response.Write("[" + message + "]");
                context.Response.End();
            }

            //添加 
            if (context.Request["add"] != null && context.Request["add"] == "yes")
            {
                BitAuto.YanFa.Crm2009.Entities.ReturnVisit model = new BitAuto.YanFa.Crm2009.Entities.ReturnVisit();
                model.begintime = RequestBeginTime;
                model.CustID = RequestCustID;
                if (!string.IsNullOrEmpty(RequestContactInfoUserID))
                {
                    model.ContactInfoUserID = int.Parse(RequestContactInfoUserID);
                }

                model.createtime = DateTime.Now;
                model.CreateuserDepart = HttpContext.Current.Session["departid"].ToString();
                model.createUserID = Convert.ToInt32(HttpContext.Current.Session["userid"]);
                model.endtime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                model.Remark = RequestRemark;
                //model.RVType = 2;//电话联系
                model.RVType = Convert.ToInt32(RequestRVType);
                model.UserClass = 2;//客服
                model.status = 0;
                model.title = "";
                model.RVresult = RequestRVresult;
                //model.RVQuestionStatus = Convert.ToInt32(RequestRVQuestionStatus);
                model.RVQuestionRemark = RequestRVQuestionRemark;

                model.MemberId = MemberId;
                model.VisitType = VisitType;
                model.BusinessLine = int.Parse(TypeID);


                model.Rid = BitAuto.YanFa.Crm2009.BLL.ReturnVisit.Instance.InsertReturnVisit(model);

                if (model.Rid > 0)
                {
                    //如果流水号存在，绑定录音
                    if (!string.IsNullOrEmpty(SessionID))
                    {
                        Entities.CallRecordInfo call = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(SessionID);
                        if (call != null)
                        {
                            call.CustID = RequestCustID;
                            call.RVID = model.Rid;

                            BLL.CallRecordInfo.Instance.Update(call);

                            //调用webservice,保存callid,业务id，业务组，分类对应关系
                            string msg = string.Empty;
                            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID开始");
                            //int Result = CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID(call.CallID, call.RVID.ToString(), call.BGID, call.SCID, Convert.ToInt32(call.CreateUserID), ref msg);
                            int Result = BLL.CallRecord_ORIG_Business.Instance.UpdateBusinessDataByCallID(call.CallID, call.RVID.ToString(), call.BGID, call.SCID, Convert.ToInt32(call.CreateUserID), ref msg);
                            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID结束返回值Result=" + Result);


                        }
                    }

                    //把回访零时表中记录的录音流水拿出来，挂到这个从CRM库返回回访id下
                    DataTable dtSession = null;
                    dtSession = BLL.ProjectTask_ReturnVisit.Instance.GetReturnVisitCallReCord(model.CustID);
                    if (dtSession != null && dtSession.Rows.Count > 0)
                    {
                        for (int i = 0; i < dtSession.Rows.Count; i++)
                        {
                            Entities.CallRecordInfo call = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(dtSession.Rows[i]["SessionID"].ToString());
                            if (call != null)
                            {
                                call.CustID = RequestCustID;
                                call.RVID = model.Rid;

                                BLL.CallRecordInfo.Instance.Update(call);

                                //调用webservice,保存callid,业务id，业务组，分类对应关系
                                string msg = string.Empty;
                                BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID开始");
                                //int Result = CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID(call.CallID, call.RVID.ToString(), call.BGID, call.SCID, Convert.ToInt32(call.CreateUserID), ref msg);
                                int Result = BLL.CallRecord_ORIG_Business.Instance.UpdateBusinessDataByCallID(call.CallID, call.RVID.ToString(), call.BGID, call.SCID, Convert.ToInt32(call.CreateUserID), ref msg);
                                BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID结束返回值Result=" + Result);
                            }
                        }
                        //删除回访临时信息
                        BLL.ProjectTask_ReturnVisit.Instance.DeleteReturnVisitCallReCord(model.CustID);
                    }

                    #region 插入新的 访问发现记录
                    //if (!string.IsNullOrEmpty(VisitFound))
                    //{
                    //    string[] rcs = VisitFound.Split('﹋');
                    //    for (int i = 0; i < rcs.Length; i++)
                    //    {
                    //        if (rcs[i] != "")
                    //        {
                    //            string[] rc = rcs[i].Split('﹏');
                    //            if (rc[0] != "" && rc[1] != "")
                    //            {
                    //                Crm2009.Entities.VisitFound dstVF = new Crm2009.Entities.VisitFound();
                    //                dstVF.VisitId = model.Rid;
                    //                dstVF.FoundType = rc[0];
                    //                dstVF.FoundDescription = rc[1];
                    //                Crm2009.BLL.VisitFound.Instance.Add(dstVF);
                    //            }
                    //        }
                    //    }
                    //}
                    #endregion

                    //提交完如果之前有保存的记录，则将CC库中的记录状态改为-1
                    BLL.ProjectTask_ReturnVisit.Instance.updateStatus(RequestCustID);

                    message = "Result:'yes'";
                }
                else
                {
                    message = "Result:'no'";
                }
                context.Response.Write("{" + message + "}");
                context.Response.End();
            }
            //add lxw 2012.6.11 保存进CC库
            if (context.Request["save"] != null && context.Request["save"] == "yes")
            {
                //先删除之前保存的记录
                DataTable dt = BLL.ProjectTask_ReturnVisit.Instance.GetTable(RequestCustID);
                BLL.ProjectTask_ReturnVisit.Instance.Delete(RequestCustID);
                if (dt.Rows.Count > 0)
                {
                    //BLL.CC_VisitFound.Instance.Delete(dt.Rows[0]["RecID"].ToString());
                }
                //新增保存记录
                Entities.ProjectTask_ReturnVisit model = new Entities.ProjectTask_ReturnVisit();
                model.Begintime = RequestBeginTime;
                model.CRMCustID = RequestCustID;
                if (!string.IsNullOrEmpty(RequestContactInfoUserID))
                {
                    model.ContactInfoUserID = int.Parse(RequestContactInfoUserID);
                }

                model.Createtime = DateTime.Now;
                model.CreateuserDepart = HttpContext.Current.Session["departid"].ToString();
                model.CreateUserID = Convert.ToInt32(HttpContext.Current.Session["userid"]);
                model.Endtime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                model.Remark = RequestRemark;
                //model.RVType = 2;//电话联系
                model.RVType = Convert.ToInt32(RequestRVType);
                model.UserClass = 2;//客服
                model.Status = 0;
                model.Title = "";
                model.RVresult = RequestRVresult;
                //model.RVQuestionStatus = Convert.ToInt32(RequestRVQuestionStatus);
                model.RVQuestionRemark = RequestRVQuestionRemark;

                model.MemberId = MemberId;
                model.VisitType = VisitType;
                model.TypeID = TypeID;//所属业务

                model.RecID = BLL.ProjectTask_ReturnVisit.Instance.Insert(model);

                if (model.RecID > 0)
                {
                    //把录音流水号保存在零时记录表中
                    if (!string.IsNullOrEmpty(SessionID))
                    {
                        BLL.ProjectTask_ReturnVisit.Instance.InsertReturnVisitCallReCord(model.CRMCustID, SessionID);
                    }

                    ////Entities.CC_CallRecords call = BLL.CC_CallRecords.Instance.GetCC_CallRecords(SessionID);
                    ////if (call != null)
                    ////{
                    ////    call.CRMCustID = RequestCustID;
                    ////    if (call.BusinessNature == 2)
                    ////    {
                    ////        call.RelationID = model.Rid.ToString();
                    ////    }
                    ////    if (call.BusinessNature == 1)
                    ////    {
                    ////        call.RelationID = RequestCustID;
                    ////    }
                    ////    BLL.CC_CallRecords.Instance.Update(call);
                    ////}

                    //#region 插入新的 访问发现记录
                    //if (!string.IsNullOrEmpty(VisitFound))
                    //{
                    //    string[] rcs = VisitFound.Split('﹋');
                    //    for (int i = 0; i < rcs.Length; i++)
                    //    {
                    //        if (rcs[i] != "")
                    //        {
                    //            string[] rc = rcs[i].Split('﹏');
                    //            if (rc[0] != "0" || rc[1] != "") //只要有一个有值则插入
                    //            {
                    //                CC2011.Entities.CC_VisitFound dstVF = new CC2011.Entities.CC_VisitFound();
                    //                dstVF.VisitId = model.Rid;
                    //                dstVF.FoundType = rc[0];
                    //                dstVF.FoundDescription = rc[1];
                    //                dstVF.CreateTime = DateTime.Now;
                    //                dstVF.CreateUserID = BLL.Util.GetLoginUserID();
                    //                CC2011.BLL.CC_VisitFound.Instance.Add(dstVF);
                    //            }
                    //        }
                    //    }
                    //}
                    //#endregion


                    message = "Result:'yes'";
                }
                else
                {
                    message = "Result:'no'";
                }
                context.Response.Write("{" + message + "}");
                context.Response.End();
            }

            if (context.Request["show"] != null && context.Request["show"] == "yes")
            {
                BitAuto.YanFa.Crm2009.Entities.ReturnVisit model = BitAuto.YanFa.Crm2009.BLL.ReturnVisit.Instance.GetReturnVisit(int.Parse(Requestrid));
                if (model != null)
                {
                    result = JavaScriptConvert.SerializeObject(model);
                    message = "yes";
                }
                else
                {
                    success = false;
                    message = "no";
                }
                BitAuto.ISDC.CC2012.BLL.AJAXHelper.WrapJsonResponse(success, result, message);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}