﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.ISDC.CC2012.BLL;
using BitAuto.Utils.Config;
using BitAuto.ISDC.CC2012.Entities;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustCheck
{
    public partial class CustAssignUserList : PageBase
    {
        #region 属性
        public string TrueName
        {
            get
            {
                return string.IsNullOrEmpty(HttpContext.Current.Request["TrueName"]) == true ? "" : HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["TrueName"]);
            }
        }
        public string BGID
        {
            get
            {
                return string.IsNullOrEmpty(HttpContext.Current.Request["BGID"]) == true ? "" : HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["BGID"]);
            }
        }
        public string BGIDs
        {
            //get
            //{
            //    return string.IsNullOrEmpty(HttpContext.Current.Request["BGIDs"]) == true ? "" : HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["BGIDs"]);
            //}
            get;
            set;
        }
        #endregion
        public int GroupLength = 5;
        public int PageSize = 10;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                int userId = BLL.Util.GetLoginUserID();
                if (BLL.Util.CheckRight(userId, "SYS024BUT130401")  //添加 “任务列表--客户核实”分配功能验证逻辑
                    || BLL.Util.CheckRight(userId, "SYS024BUT140101") //添加 “任务列表--客户回访”分配功能验证逻辑
                    || BLL.Util.CheckRight(userId, "SYS024BUT150101"))   //添加 “任务列表--其它任务”分配功能验证逻辑
                {
                    ddlBussiGroupBind();
                    BindData();
                }
                else
                {
                    Response.Redirect(BLL.Util.GetNotAccessMsgPage("您没有访问该页面的权限"));
                    Response.End();
                }
            }
        }
        /// <summary>
        /// 绑定处理人
        /// </summary>
        private void ddlBussiGroupBind()
        {
            ////ddlBussiGroup.DataSource = BLL.BusinessGroup.Instance.GetAllBusinessGroup();
            ////ddlBussiGroup.DataTextField = "Name";
            ////ddlBussiGroup.DataValueField = "BGID";
            ////ddlBussiGroup.DataBind();
            ////ddlBussiGroup.Items.Insert(0, new ListItem("请选择", "-2"));

            //取当前人所对应的业务组
            //Entities.QueryUserGroupDataRigth QueryUserGroupDataRigth = new Entities.QueryUserGroupDataRigth();
            //QueryUserGroupDataRigth.UserID = BLL.Util.GetLoginUserID();
            //int totcount = 0;
            //DataTable dtUserGroupDataRigth = BLL.UserGroupDataRigth.Instance.GetUserGroupDataRigth(QueryUserGroupDataRigth, "", 1, 100000, out totcount);
            //string Rolename = string.Empty;
            //if (dtUserGroupDataRigth != null && dtUserGroupDataRigth.Rows.Count > 0)
            //{
            //    ddlBussiGroup.Value = dtUserGroupDataRigth.Rows[0]["bgid"].ToString();
            //}

            #region 2014-07-21 修改——毕帆
            int userid = BLL.Util.GetLoginUserID();
            //所属分组
            DataTable bgdt = BLL.EmployeeSuper.Instance.GetCurrentUserGroups(userid);

            //添加请选择
            DataRow dr = bgdt.NewRow();
            dr[0] = "-2";
            dr[1] = "请选择";
            bgdt.Rows.InsertAt(dr, 0);

            //绑定数据
            ddlBussiGroup.DataSource = bgdt;
            ddlBussiGroup.DataTextField = "Name";
            ddlBussiGroup.DataValueField = "BGID";
            ddlBussiGroup.DataBind();

            string str = "";
            foreach (DataRow row in bgdt.Rows)
            {
                if (row["BGID"].ToString() != "-2")
                {
                    str += row["BGID"].ToString() + ",";
                }
            }
            if (str.Length > 0)
            {
                BGIDs = str.TrimEnd(',');
            }
            else
            {
                BGIDs = "";
            }
            #endregion
        }
        private void BindData()
        {
            int RecordCount = 0;
            QueryEmployeeSuper query = new QueryEmployeeSuper();
            //分页参数赋值
            if (BGID != "")
            {
                query.BGID = int.Parse(BGID);
            }

            if (BGIDs != "")
            {
                query.BGIDs = BGIDs;
            }


            if (!string.IsNullOrEmpty(TrueName))
            {
                query.TrueName = TrueName;
            }
            //按条件找人：条件-部门，角色-
            DataTable dt = BLL.EmployeeSuper.Instance.GetEmployeeSuper(query, "", BLL.PageCommon.Instance.PageIndex, PageSize, out RecordCount);

            repterPersonlist.DataSource = dt;
            repterPersonlist.DataBind();

            litPagerDown.Text = BLL.PageCommon.Instance.LinkStringByPost(BLL.Util.GetUrl(), GroupLength, RecordCount, PageSize, BLL.PageCommon.Instance.PageIndex, 4);
        }
        public string getLoginUserID()
        {
            return BLL.Util.GetLoginUserID().ToString();
        }
    }
}