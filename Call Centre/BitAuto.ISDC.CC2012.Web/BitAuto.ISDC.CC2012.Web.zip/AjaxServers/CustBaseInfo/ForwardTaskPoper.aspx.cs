﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Web.UI.HtmlControls;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo
{
    public partial class ForwardTaskPoper : PageBase
    {
        public string CurrentType
        {
            get
            {
                if (HttpContext.Current.Request["CurrentType"] != null)
                {
                    return HttpUtility.UrlDecode(HttpContext.Current.Request["CurrentType"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                QuestionQualityBind();
                SolveInfoBind();
            }
        }
        private void QuestionQualityBind()
        {
            ddlQuestionQualityPop.DataSource = BLL.Util.GetEnumDataTable(typeof(Entities.QuestionNature));
            ddlQuestionQualityPop.DataTextField = "name";
            ddlQuestionQualityPop.DataValueField = "value";
            ddlQuestionQualityPop.DataBind();
            ddlQuestionQualityPop.Items.Insert(0, new ListItem("请选择", "0"));
        }

        private void SolveInfoBind()
        {
            if (!string.IsNullOrEmpty(CurrentType))
            {
                string firstCategoryName = string.Empty;
                string secondCategoryNames = string.Empty;
                string[] arry = CurrentType.Split(';');
                if (arry.Length > 1)
                {
                    firstCategoryName = arry[0];
                    if (arry[1].Length > 0)
                    {
                        secondCategoryNames = arry[1];
                    }
                }
                else
                {
                    firstCategoryName = CurrentType;
                }
                DataTable dt = BLL.TemplateCategory.Instance.GetTemplateCategoryByTemplateCategoryName(firstCategoryName, secondCategoryNames);
                rptSolveInfo.DataSource = dt;
                rptSolveInfo.DataBind();
            }
        }

        protected void rptSolveInfo_ItemDataBind(Object Sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                int tcId = int.Parse(DataBinder.Eval(e.Item.DataItem, "RecID").ToString().Trim());
                Entities.QueryTemplateInfo query = new Entities.QueryTemplateInfo();
                query.TCID = tcId;
                int totalCount = 0;
                DataTable dt = BLL.TemplateInfo.Instance.GetTemplateInfo(query, "", 1, 20, out totalCount);
                string str = "<select id='sltTemplate' onchange='TemplateChanged(this)'>";
                foreach (DataRow dr in dt.Rows)
                {
                    str += "<option value='" + dr["RecID"] + "'>" + dr["Title"] + "</option>";
                }
                str += "</select>";
                Literal lSelectTemplate = e.Item.FindControl("lblSelectTemplate") as Literal;
                lSelectTemplate.Text = str;
                if (dt.Rows.Count > 0)
                {
                    DataTable dtSolveUser = BLL.ConsultSolveUserMapping.Instance.GetConsultSolveUserByTemplateID(int.Parse(dt.Rows[0]["RecID"].ToString()));
                    Label lblSolveUserName = e.Item.FindControl("lblSolveUserName") as Label;
                    HtmlInputHidden hdnEid = e.Item.FindControl("hdnEID") as HtmlInputHidden;

                    for (int i = 0; i < dtSolveUser.Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                            lblSolveUserName.Text = dtSolveUser.Rows[i]["SolveUserEName"].ToString();
                            hdnEid.Value = dtSolveUser.Rows[0]["SolveUserEID"].ToString();
                        }
                        else
                        {
                            lblSolveUserName.Text += "," + dtSolveUser.Rows[i]["SolveUserEName"].ToString();
                            hdnEid.Value += "," + dtSolveUser.Rows[i]["SolveUserEID"].ToString();
                        }
                    }
                }
            }
        }
    }
}