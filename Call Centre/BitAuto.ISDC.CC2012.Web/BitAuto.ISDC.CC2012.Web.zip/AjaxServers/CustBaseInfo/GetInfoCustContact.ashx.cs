﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using BitAuto.ISDC.CC2012.Entities;
using System.Web.SessionState;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo
{
    /// <summary>
    /// GetInfoCustContact 的摘要说明
    /// </summary>
    public class GetInfoCustContact : IHttpHandler, IRequiresSessionState
    {
        /// <summary>
        /// 数据分类
        /// </summary>
        public string TypeName
        {
            get
            {
                if (HttpContext.Current.Request["t"] != null)
                {
                    return HttpContext.Current.Request["t"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// 显示类型
        /// </summary>
        public string ShowType
        {
            get
            {
                if (HttpContext.Current.Request["s"] != null)
                {
                    return HttpContext.Current.Request["s"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();

            string html = "";

            switch (TypeName)
            {

                //二手车下二级分类
                case "NewCarBuyTime": html = GetHtml(typeof(NewCarBuyTime)); break;

                //二手车下二级分类
                case "SecondCarType": html = GetHtml(typeof(SecondCarType)); break;

                //个人反馈下二级分类
                case "FeedBackTyle": html = GetHtml(typeof(FeedBackTyle)); break;

                //活动下的二级分类
                case "ActiveType": html = GetHtml(typeof(ActiveType)); break;

                //个人用车下二级分类
                case "PersonalCarType": html = GetHtml(typeof(PersonalCarType)); break;

                //经销商下的二级分类
                case "DealerType": html = GetHtml(typeof(DealerType)); break;

                //经销商反馈下的二级分类
                case "DealerTypeDCoop": html = GetHtml(typeof(DealerTypeDCoop)); break;

                //经销商反馈下的来电渠道
                case "TelSource": html = GetHtml(typeof(TelSource)); break;

                //经销商反馈下的问题内容
                case "CallRecordType": html = GetHtml(typeof(CallRecordType)); break;


            }

            context.Response.Write(html);
        }


        public string GetHtml(Type enumName)
        {
            string html = "";
            DataTable dt = null;


            dt = BLL.Util.GetDataFromEnum(enumName);
            foreach (DataRow dr in dt.Rows)
            {
                if (ShowType == "rdo")
                {
                    //html = html + "<input id='" + enumName.Name + "_" + dr["ID"].ToString() + "' value='" + dr["ID"].ToString() + "' type='radio'  name='" + enumName.Name + "'/><label  class='checkboxlabel'  for='" + enumName.Name + "_" + dr["ID"].ToString() + "'>" + dr["Name"].ToString() + "</label>";
                    html = html + "<input id='" + enumName.Name + "_" + dr["ID"].ToString() + "'  class='marginleft' value='" + dr["ID"].ToString() + "' type='radio' typeName='" + dr["Name"].ToString() + "'  name='" + enumName.Name + "'/>"
                        + "<label  style='float:none;'  for='" + enumName.Name + "_" + dr["ID"].ToString() + "'><em onclick=\"emChkIsChoose(this);\">"
                        + dr["Name"].ToString() + "</em></label>";
                }
                else if (ShowType == "cbx")
                {
                    //html = html + "<input id='" + enumName.Name + "_" + dr["ID"].ToString() + "' value='" + dr["ID"].ToString() + "'  type='checkbox' name='" + enumName.Name + "'><label class='checkboxlabel' for='" + enumName.Name + "_" + dr["ID"].ToString() + "'>" + dr["Name"].ToString() + "</label>";
                    html = html + "<input id='" + enumName.Name + "_" + dr["ID"].ToString() + "' class='marginleft' value='" + dr["ID"].ToString() + "'  type='checkbox'  typeName='" + dr["Name"].ToString() + "'  name='" + enumName.Name + "'>"
                         + "<label  style='float:none;'  for='" + enumName.Name + "_" + dr["ID"].ToString() + "'><em onclick=\"emChkIsChoose(this);\">"
                        + dr["Name"].ToString() + "</em></label>";
                }
                else if (ShowType == "ddl")
                {
                    html = html + "<option value='" + dr["ID"].ToString() + "'  typeName='" + dr["Name"].ToString() + "' >" + dr["Name"].ToString() + "</option>";
                }
            }
            return html;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}