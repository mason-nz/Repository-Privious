﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;

using System.Collections;
using System.Web.SessionState;
using BitAuto.ISDC.CC2012.Entities;
using System.Text.RegularExpressions;
using System.Configuration;
using BitAuto.ISDC.CC2012.WebService;
using System.Data;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo
{
    /// <summary>
    /// AddContactInfo 的摘要说明
    /// </summary>
    public class AddContactInfo : IHttpHandler, IRequiresSessionState
    {
        #region 参数

        /// <summary>
        /// 
        /// </summary>
        public string CustID
        {
            get
            {
                if (HttpContext.Current.Request["custID"] != null)
                {
                    return HttpContext.Current.Request["custID"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// 咨询类型Page名称
        /// </summary>
        public string TypeName
        {
            get
            {
                if (HttpContext.Current.Request["typeName"] != null)
                {
                    return HttpContext.Current.Request["typeName"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        ///  
        /// </summary>
        public string JsonStr
        {
            get
            {
                if (HttpContext.Current.Request["jsonstr"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["jsonstr"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// 录音ID
        /// </summary>
        public string CALLID
        {
            get
            {
                if (HttpContext.Current.Request["callId"] != null)
                {
                    return HttpContext.Current.Request["callId"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// 咨询类型ID
        /// </summary>
        public string ConsultID
        {
            get
            {
                if (HttpContext.Current.Request["ConsultID"] != null)
                {
                    return HttpContext.Current.Request["ConsultID"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        /// <summary>
        /// 咨询类型ID
        /// </summary>
        public string RecordType
        {
            get
            {
                if (HttpContext.Current.Request["RecordType"] != null)
                {
                    return HttpContext.Current.Request["RecordType"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        /// <summary>
        /// 客户姓名
        /// </summary>
        public string CustName
        {
            get
            {
                if (HttpContext.Current.Request["CustName"] != null)
                {
                    return HttpContext.Current.Request["CustName"].ToString();
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        //CityID: escape(CityID), Sex: escape(sex), CustTel: escape(custTels), Email: escape(email), Address: escape(address)

        /// <summary>
        /// 城市id
        /// </summary>
        public string CityID
        {
            get
            {
                if (HttpContext.Current.Request["CityID"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["CityID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        /// <summary>
        /// 电话
        /// </summary>
        public string CustTel
        {
            get
            {
                if (HttpContext.Current.Request["CustTel"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["CustTel"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        /// <summary>
        /// 性别
        /// </summary>
        public string Sex
        {
            get
            {
                if (HttpContext.Current.Request["Sex"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["Sex"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        /// <summary>
        /// 邮箱
        /// </summary>
        public string Email
        {
            get
            {
                if (HttpContext.Current.Request["Email"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["Email"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        /// <summary>
        /// 地址
        /// </summary>
        public string Address
        {
            get
            {
                if (HttpContext.Current.Request["Address"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["Address"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        public string WorkID
        {
            get
            {
                if (HttpContext.Current.Request["WorkID"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["WorkID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        public string CarID
        {
            get
            {
                if (HttpContext.Current.Request["CarID"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["CarID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        public string DealerCode
        {
            get
            {
                if (HttpContext.Current.Request["DealerCode"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["DealerCode"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        public string IsAceeptVisit
        {
            get
            {
                if (HttpContext.Current.Request["IsAceeptVisit"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["IsAceeptVisit"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public string From
        {
            get
            {
                if (HttpContext.Current.Request["From"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["From"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        public string FromRecID
        {
            get
            {
                if (HttpContext.Current.Request["FromRecID"] != null)
                {
                    return HttpContext.Current.Server.UrlDecode(HttpContext.Current.Request["FromRecID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        #endregion

        #region 处理请求
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();

            string msg = "";
            CheckParam(out msg);
            if (msg != "")
            {
                //验证未通过
                context.Response.Write(msg);
                return;
            }
            //try
            //{
            SaveInfo(out msg);
            //}
            //catch (Exception ex)
            //{
            //    msg = "添加历史记录失败！";
            //}

            if (msg == "")
            {
                msg = "succeed";
            }
            context.Response.Write(msg);
        }
        #endregion

        #region 验证
        private void CheckParam(out string msg)
        {
            msg = "";
            if (CustID == string.Empty)
            {
                msg = "客户不存在！";
            }
        }
        #endregion

        private void SaveInfo(out string msg)
        {
            msg = "";

            #region 把工单ID与历史记录关联
            Entities.CustHistoryInfo CustInfoModel = GetMode();
            CustInfoModel.TaskID = WorkID;
            BLL.Loger.Log4Net.Info("处理历史记录开始客户id为" + CustID + "工单ID为" + WorkID);

            int userid = BLL.Util.GetLoginUserID();


            #endregion

            #region 如果接收回访，并且是，购车线索，新车，调用yp接口 （作废）
            //if (!string.IsNullOrEmpty(IsAceeptVisit) && IsAceeptVisit == "1")
            //{
            //    BLL.Loger.Log4Net.Info("调用yp购车线索接口开始");
            //    //接口对象
            //    YpOrderService.OrderServiceSoapClient orderservice = new YpOrderService.OrderServiceSoapClient();
            //    //接口参数对象
            //    YpOrderService.CommonOrderEntity CommonOrderModel = new YpOrderService.CommonOrderEntity();
            //    BLL.Loger.Log4Net.Info("准备购车线索参数开始");
            //    //车款id
            //    CommonOrderModel.CarId = CarID;
            //    //城市id
            //    int cityid = 0;
            //    if (int.TryParse(CityID, out cityid))
            //    {
            //        CommonOrderModel.CityId = cityid;
            //    }
            //    //经销商id
            //    CommonOrderModel.DealerId = DealerCode;
            //    //邮箱
            //    CommonOrderModel.Email = Email;

            //    //订单类型
            //    CommonOrderModel.OrderTypeID = 1;
            //    //给手机或电话赋值
            //    if (!string.IsNullOrEmpty(CustTel))
            //    {
            //        for (int i = 0; i < CustTel.Split(',').Length; i++)
            //        {
            //            if (BLL.Util.IsHandset(CustTel.Split(',')[i]))
            //            {
            //                //手机
            //                CommonOrderModel.Mobile = CustTel.Split(',')[i];
            //            }
            //            else
            //            {
            //                //电话
            //                CommonOrderModel.Phone = CustTel.Split(',')[i];
            //            }
            //        }
            //    }
            //    //用户名
            //    CommonOrderModel.UserName = CustName;
            //    //性别
            //    if (!string.IsNullOrEmpty(Sex))
            //    {
            //        if (Sex == "2")
            //        {
            //            CommonOrderModel.UserGender = 0;
            //        }
            //        else
            //        {
            //            CommonOrderModel.UserGender = 1;
            //        }
            //    }
            //    else
            //    {
            //        CommonOrderModel.UserGender = -1;
            //    }

            //    //地址
            //    CommonOrderModel.UserAddress = Address;
            //    //下单地址
            //    CommonOrderModel.OrderWebSrc = "http://ncc.sys.bitauto.com/" + WorkID;
            //    //ip易派要就写死
            //    CommonOrderModel.UserIP = "211.151.69.10";
            //    //CommonOrderModel.UserIP = "127.0.0.1";
            //    //取0-9随机数
            //    //Random rn = new Random();
            //    //System.Text.StringBuilder sBuilder = new System.Text.StringBuilder();
            //    //for (int i = 0; i < 10; i++)
            //    //{
            //    //    sBuilder.Append(rn.Next(10).ToString());
            //    //}
            //    //CommonOrderModel.UserIP = sBuilder.ToString();
            //    //

            //    //接口票证
            //    YpOrderService.TokenHeader token = new YpOrderService.TokenHeader();
            //    token.TokenKey = "";
            //    if (ConfigurationManager.AppSettings["NewCarOrderKey"] != null)
            //    {
            //        token.TokenKey = ConfigurationManager.AppSettings["NewCarOrderKey"].ToString();
            //    }
            //    //orderservice.
            //    YpOrderService.CommonOrderServiceResult orderResult = orderservice.CreateNewCarOrder(token, CommonOrderModel);
            //    //创建成功
            //    Entities.UpdateOrderData updateorderdatamodel = new UpdateOrderData();
            //    //购车线索类型
            //    updateorderdatamodel.APIType = 2;
            //    //工单ＩＤ
            //    updateorderdatamodel.TaskID = WorkID;
            //    //工单对应客户ＩＤ
            //    updateorderdatamodel.CustID = CustID;
            //    updateorderdatamodel.ConsultType = (int)Entities.ConsultType.NewCar;
            //    updateorderdatamodel.CreateTime = System.DateTime.Now;
            //    updateorderdatamodel.CreateUserID = userid;
            //    //updateorderdatamodel.
            //    if (orderResult.ResultCode == 1)
            //    {
            //        updateorderdatamodel.UpdateType = 1;
            //        updateorderdatamodel.IsUpdate = 1;
            //    }
            //    //权限验证不通过
            //    else if (orderResult.ResultCode == -1)
            //    {
            //        updateorderdatamodel.UpdateType = -1;
            //        updateorderdatamodel.IsUpdate = -1;
            //        updateorderdatamodel.UpdateErrorMsg = orderResult.ResultInfo;
            //    }
            //    //必填项验证不通过
            //    else if (orderResult.ResultCode == -2)
            //    {
            //        updateorderdatamodel.UpdateType = -1;
            //        updateorderdatamodel.IsUpdate = -1;
            //        updateorderdatamodel.UpdateErrorMsg = orderResult.ResultInfo;
            //    }
            //    //程序异常
            //    else if (orderResult.ResultCode == -3)
            //    {
            //        updateorderdatamodel.UpdateType = -1;
            //        updateorderdatamodel.IsUpdate = -1;
            //        updateorderdatamodel.UpdateErrorMsg = "程序异常";
            //    }
            //    //插入日志
            //    BLL.UpdateOrderData.Instance.Insert(updateorderdatamodel);
            //    BLL.Loger.Log4Net.Info("调用yp线索接口结束，明细在月宾兄接口调用日志表中看");
            //}
            #endregion

            #region 更新历史记录
            if (CustInfoModel.CallRecordID > 0)
            {
                BLL.Loger.Log4Net.Info("更新CustHistoryInfo表开始，custid=" + CustID + "，工单id=" + WorkID + "，录音id=" + CALLID);
                BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
                BLL.Loger.Log4Net.Info("更新CustHistoryInfo表结束，custid=" + CustID + "，工单id=" + WorkID + "，录音id=" + CALLID);
            }
            else
            {
                BLL.Loger.Log4Net.Info("插入CustHistoryInfo表开始，custid=" + CustID + "，工单id=" + WorkID + "，录音id=" + CALLID);
                BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
                BLL.Loger.Log4Net.Info("插入CustHistoryInfo表结束，custid=" + CustID + "，工单id=" + WorkID + "，录音id=" + CALLID);
            }
            #endregion

            #region 更新录音信息，让他与工单联系起来
            BLL.Loger.Log4Net.Info("判断录音id是否大于0，custid=" + CustID + "，工单id=" + WorkID);
            if (CustInfoModel.CallRecordID > 0)
            {
                BLL.Loger.Log4Net.Info("录音id大于0，custid=" + CustID + "，工单id=" + WorkID);
                BLL.Loger.Log4Net.Info("根据录音id取callRecordinfo表，custid=" + CustID + "，工单id=" + WorkID);
                Entities.CallRecordInfo callRecordInfo = BLL.CallRecordInfo.Instance.GetCallRecordInfo(CustInfoModel.CallRecordID);
                //如果录音不为空，则修改录音记录的任务ID
                if (callRecordInfo != null)
                {
                    BLL.Loger.Log4Net.Info("根据录音id取callRecordinfo表成功并且录音实体不为空，custid=" + CustID + "，工单id=" + WorkID);
                    if (!string.IsNullOrEmpty(CustName))
                    {
                        callRecordInfo.CustName = CustName;
                        callRecordInfo.Contact = CustName;
                    }
                    callRecordInfo.TaskID = CustInfoModel.TaskID;
                    //添加或转发工单后要把工单的业务组，分类更新到录音上add by qizq 2013-8-30
                    //Modify by qizq  2013-10-11 工单录音分组分类采用当前人分组，和工单分类
                    callRecordInfo.BGID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfBGIDByUserID(userid);
                    callRecordInfo.SCID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfSCIDByUserID(userid);
                    //
                    BLL.CallRecordInfo.Instance.Update(callRecordInfo);
                    BLL.Loger.Log4Net.Info("更新录音实体成功，custid=" + CustID + "，工单id=" + WorkID + "，录音id" + CustInfoModel.CallRecordID);
                    string msgStr = string.Empty;
                    //根据接口，实现话务ID与业务ID及业务分组ID等对应
                    BLL.Loger.Log4Net.Info("【AddContackInfo.ashx】开始更新话务业务中间表，工单id=" + WorkID);
                    //int Result = CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID(callRecordInfo.CallID, CustInfoModel.TaskID, callRecordInfo.BGID, callRecordInfo.SCID, userid, ref msgStr);
                    int Result = BLL.CallRecord_ORIG_Business.Instance.UpdateBusinessDataByCallID(callRecordInfo.CallID, CustInfoModel.TaskID, callRecordInfo.BGID, callRecordInfo.SCID, userid, ref msgStr);
                    BLL.Loger.Log4Net.Info("【AddContackInfo.ashx】结束更新话务业务中间表，工单id=" + WorkID);
                }
            }
            #endregion

            #region 调用用户呼入行为收集接口
            ////客户存在
            //BLL.Loger.Log4Net.Info("准备调用用户呼入行为收集接口，客户" + CustID);
            //if (!string.IsNullOrEmpty(CustID))
            //{
            //    Entities.CustBasicInfo custbasicmodel = BLL.CustBasicInfo.Instance.GetCustBasicInfo(CustID);
            //    //如果客户类型是个人
            //    if (custbasicmodel != null)
            //    {
            //        #region 找到客户实体
            //        BLL.Loger.Log4Net.Info("找到客户实体，客户id" + CustID);
            //        if (custbasicmodel.CustCategoryID == 4)
            //        {
            //            #region 客户分类为个人
            //            BLL.Loger.Log4Net.Info("客户" + CustID + "类型为个人");

            //            #region 判断是否是手机
            //            string HandSet = string.Empty;
            //            DataTable custtelData = BLL.CustTel.Instance.GetCustTel(CustID);
            //            if (custtelData != null && custtelData.Rows.Count > 0)
            //            {
            //                for (int i = 0; i < custtelData.Rows.Count; i++)
            //                {
            //                    if (BLL.Util.IsHandset(custtelData.Rows[i]["Tel"].ToString()))
            //                    {
            //                        HandSet = custtelData.Rows[i]["Tel"].ToString();
            //                        break;
            //                    }
            //                }
            //            }
            //            #endregion

            //            if (!string.IsNullOrEmpty(HandSet))
            //            {
            //                #region 客户有手机
            //                BLL.Loger.Log4Net.Info("找到客户" + CustID + "手机" + HandSet);
            //                if (!string.IsNullOrEmpty(WorkID))
            //                {
            //                    Entities.WorkOrderInfo workordermodel = BLL.WorkOrderInfo.Instance.GetWorkOrderInfo(WorkID);
            //                    if (workordermodel != null)
            //                    {
            //                        BLL.Loger.Log4Net.Info("找客户的" + CustID + "工单" + WorkID);
            //                        //购车线索
            //                        if (workordermodel.CategoryID == 34 || workordermodel.CategoryID == 35 || workordermodel.CategoryID == 36 || workordermodel.CategoryID == 37 || workordermodel.CategoryID == 38)
            //                        {

            //                            #region 调用用户呼入行为收集接口
            //                            //取工单对应推荐活动guidstr
            //                            string Guidstr = BLL.WorkOrderActivity.Instance.GetGuidsByOrderID(WorkID);
            //                            //

            //                            BLL.Loger.Log4Net.Info("客户" + CustID + "的工单" + WorkID + "为购车线索");
            //                            BLL.Loger.Log4Net.Info("客户" + CustID + "下工单" + WorkID + "调用用户呼入行为收集接口开始");
            //                            string xmlstr = string.Empty;
            //                            try
            //                            {
            //                                BitAuto.ISDC.CC2012.WebService.BAA.UGCSyncServiceHelper service = new WebService.BAA.UGCSyncServiceHelper();
            //                                xmlstr = service.GetXMLContentByInBound(workordermodel, custbasicmodel, HandSet, Guidstr);
            //                                service.Send(xmlstr);
            //                            }
            //                            catch (Exception ex)
            //                            {
            //                                var args = new UnhandledExceptionEventArgs(ex, false);
            //                                Exception e = (Exception)args.ExceptionObject;
            //                                string errorMsg = e.Message;
            //                                string stackTrace = e.StackTrace;
            //                                string source = e.Source;

            //                                string mailBody = string.Format("错位信息：{0}<br/>错误Source：{1}<br/>错误StackTrace：{2}<br/>IsTerminating:{3}<br/>",
            //                                    errorMsg, source, stackTrace, args.IsTerminating);

            //                                BLL.Loger.Log4Net.Info("客户" + CustID + "下工单" + WorkID + "调用用户呼入行为收集接口失败，失败原因" + mailBody);
            //                            }
            //                            finally
            //                            {
            //                                Entities.UpdateOrderData updateDateMode = new Entities.UpdateOrderData();
            //                                updateDateMode.TaskID = WorkID;
            //                                //updateDateMode.YPOrderID = newModel.OrderID;
            //                                updateDateMode.UpdateType = 1;
            //                                updateDateMode.IsUpdate = 1; // 1 成功了，不用处理，-1 需要重新处理
            //                                updateDateMode.UpdateErrorMsg = xmlstr;
            //                                updateDateMode.CreateTime = DateTime.Now;
            //                                updateDateMode.CreateUserID = userid;
            //                                updateDateMode.APIType = 5;//5为用户呼入行为收集
            //                                updateDateMode.CustID = CustID;
            //                                BLL.UpdateOrderData.Instance.Insert(updateDateMode);
            //                                BLL.Loger.Log4Net.Info("客户" + CustID + "下工单" + WorkID + "调用用户呼入行为收集接口结束");
            //                            }
            //                            #endregion
            //                        }
            //                        else
            //                        {
            //                            BLL.Loger.Log4Net.Info("调用用户呼入行为收集接口结束，工单不是购车线索");
            //                        }
            //                    }
            //                    else
            //                    {
            //                        BLL.Loger.Log4Net.Info("调用用户呼入行为收集接口结束，工单实体不存在");
            //                    }

            //                }
            //                else
            //                {
            //                    BLL.Loger.Log4Net.Info("调用用户呼入行为收集接口结束，工单id为空");
            //                }
            //                #endregion
            //            }
            //            else
            //            {
            //                BLL.Loger.Log4Net.Info("调用用户呼入行为收集接口结束，客户没有手机");
            //            }
            //            #endregion
            //        }
            //        else
            //        {
            //            BLL.Loger.Log4Net.Info("调用用户呼入行为收集接口结束，客户分类不是个人");
            //        }
            //        #endregion
            //    }
            //    else
            //    {
            //        BLL.Loger.Log4Net.Info("准备调用用户呼入行为收集接口结束，客户实体不存在");
            //    }

            //}
            //else
            //{
            //    BLL.Loger.Log4Net.Info("准备调用用户呼入行为收集接口结束，客户id为空");
            //}
            #endregion

            #region 后续来源处理
            ProcessFromData();
            #endregion
        }
        /// 后续处理
        /// <summary>
        /// 后续处理
        /// </summary>
        private void ProcessFromData()
        {
            switch (From.ToLower())
            {
                case "miss":
                    ProcessMissCall();
                    break;
            }
        }
        /// 未接来电和未接留言处理
        /// <summary>
        /// 未接来电和未接留言处理
        /// </summary>
        private void ProcessMissCall()
        {
            int recid = CommonFunction.ObjectToInteger(FromRecID);

            CustomerVoiceMsgInfo info = BitAuto.ISDC.CC2012.BLL.CommonBll.Instance.GetComAdoInfo<CustomerVoiceMsgInfo>(recid);
            if (info != null)
            {
                info.CustID = CustID;
                info.OrderID = WorkID;

                BitAuto.ISDC.CC2012.BLL.CommonBll.Instance.UpdateComAdoInfo(info);
            }
        }

        #region 注掉以前9中联系记录
        //private void SaveType1(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;
        //    Entities.ConsultNewCar model = new Entities.ConsultNewCar();

        //    #region 给字段赋值

        //    model.CustID = CustID;

        //    if (list["CarBrandId"] != null)
        //    {
        //        if (int.TryParse(list["CarBrandId"].ToString(), out intVal))
        //        {
        //            model.CarBrandId = intVal;
        //        }
        //    }
        //    if (list["CarSerialId"] != null)
        //    {
        //        if (int.TryParse(list["CarSerialId"].ToString(), out intVal))
        //        {
        //            model.CarSerialId = intVal;
        //        }
        //    }
        //    if (list["CarID"] != null)
        //    {
        //        if (int.TryParse(list["CarID"].ToString(), out intVal))
        //        {
        //            model.CarID = intVal;
        //        }
        //    }
        //    if (list["CarName"] != null)
        //    {
        //        model.CarName = list["CarName"].ToString();
        //    }
        //    if (list["DealerName"] != null)
        //    {
        //        model.DealerName = list["DealerName"].ToString();
        //    }
        //    if (list["DealerCode"] != null)
        //    {
        //        model.DealerCode = list["DealerCode"].ToString();
        //    }

        //    if (list["BuyCarBudget"] != null)
        //    {
        //        model.BuyCarBudget = list["BuyCarBudget"].ToString();
        //    }
        //    if (list["Activity"] != null)
        //    {
        //        model.Activity = list["Activity"].ToString();
        //    }
        //    if (list["BuyCarTime"] != null)
        //    {
        //        if (int.TryParse(list["BuyCarTime"].ToString(), out intVal))
        //        {
        //            model.BuyCarTime = intVal;
        //        }
        //    }
        //    if (list["BuyOrDisplace"] != null)
        //    {
        //        if (int.TryParse(list["BuyOrDisplace"].ToString(), out intVal))
        //        {
        //            model.BuyOrDisplace = intVal;
        //        }
        //    }
        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }
        //    if (list["AcceptTel"] != null)
        //    {
        //        if (int.TryParse(list["AcceptTel"].ToString(), out intVal))
        //        {
        //            model.AcceptTel = intVal;
        //        }
        //    }
        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultNewCar.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultNewCarErr";
        //        }
        //        //add by qizq 2013-4-9为了调用yp 接口
        //        else
        //        {
        //            //如果经销商推荐成功,调用yp接口
        //            //if (!string.IsNullOrEmpty(model.DealerName))
        //            //接受推荐，调用yp商机
        //            if (model.AcceptTel == 1)
        //            {
        //                //接口对象
        //                YpOrderService.OrderServiceSoapClient orderservice = new YpOrderService.OrderServiceSoapClient();
        //                //接口参数对象
        //                YpOrderService.CommonOrderEntity CommonOrderModel = new YpOrderService.CommonOrderEntity();
        //                //车款id
        //                CommonOrderModel.CarId = model.CarID.ToString();
        //                //城市id
        //                int cityid = 0;
        //                if (int.TryParse(CityID, out cityid))
        //                {
        //                    CommonOrderModel.CityId = cityid;
        //                }
        //                //经销商id
        //                CommonOrderModel.DealerId = model.DealerCode;
        //                //邮箱
        //                CommonOrderModel.Email = Email;

        //                //订单类型
        //                CommonOrderModel.OrderTypeID = 1;
        //                //给手机或电话赋值
        //                if (!string.IsNullOrEmpty(CustTel))
        //                {
        //                    for (int i = 0; i < CustTel.Split(',').Length; i++)
        //                    {
        //                        if (BLL.Util.IsHandset(CustTel.Split(',')[i]))
        //                        {
        //                            //手机
        //                            CommonOrderModel.Mobile = CustTel.Split(',')[i];
        //                        }
        //                        else
        //                        {
        //                            //电话
        //                            CommonOrderModel.Phone = CustTel.Split(',')[i];
        //                        }
        //                    }
        //                }
        //                //用户名
        //                CommonOrderModel.UserName = CustName;
        //                //性别
        //                if (!string.IsNullOrEmpty(Sex))
        //                {
        //                    if (Sex == "2")
        //                    {
        //                        CommonOrderModel.UserGender = 0;
        //                    }
        //                    else
        //                    {
        //                        CommonOrderModel.UserGender = 1;
        //                    }
        //                }
        //                else
        //                {
        //                    CommonOrderModel.UserGender = -1;
        //                }

        //                //地址
        //                CommonOrderModel.UserAddress = Address;
        //                //下单地址
        //                CommonOrderModel.OrderWebSrc = "http://ncc.sys.bitauto.com/" + retVal;
        //                //ip易派要就写死
        //                CommonOrderModel.UserIP = "211.151.69.10";
        //                //取0-9随机数
        //                //Random rn = new Random();
        //                //System.Text.StringBuilder sBuilder = new System.Text.StringBuilder();
        //                //for (int i = 0; i < 10; i++)
        //                //{
        //                //    sBuilder.Append(rn.Next(10).ToString());
        //                //}
        //                //CommonOrderModel.UserIP = sBuilder.ToString();
        //                //

        //                //接口票证
        //                YpOrderService.TokenHeader token = new YpOrderService.TokenHeader();
        //                token.TokenKey = "";
        //                if (ConfigurationManager.AppSettings["NewCarOrderKey"] != null)
        //                {
        //                    token.TokenKey = ConfigurationManager.AppSettings["NewCarOrderKey"].ToString();
        //                }
        //                //orderservice.
        //                YpOrderService.CommonOrderServiceResult orderResult = orderservice.CreateNewCarOrder(token, CommonOrderModel);
        //                //创建成功
        //                Entities.UpdateOrderData updateorderdatamodel = new UpdateOrderData();
        //                updateorderdatamodel.APIType = 2;
        //                updateorderdatamodel.ConsultRecID = retVal;
        //                updateorderdatamodel.ConsultType = (int)Entities.ConsultType.NewCar;
        //                updateorderdatamodel.CreateTime = System.DateTime.Now;
        //                updateorderdatamodel.CreateUserID = BLL.Util.GetLoginUserID();
        //                //updateorderdatamodel.
        //                if (orderResult.ResultCode == 1)
        //                {
        //                    updateorderdatamodel.UpdateType = 1;
        //                    updateorderdatamodel.IsUpdate = 1;
        //                }
        //                //权限验证不通过
        //                else if (orderResult.ResultCode == -1)
        //                {
        //                    updateorderdatamodel.UpdateType = -1;
        //                    updateorderdatamodel.IsUpdate = -1;
        //                    updateorderdatamodel.UpdateErrorMsg = orderResult.ResultInfo;
        //                }
        //                //必填项验证不通过
        //                else if (orderResult.ResultCode == -2)
        //                {
        //                    updateorderdatamodel.UpdateType = -1;
        //                    updateorderdatamodel.IsUpdate = -1;
        //                    updateorderdatamodel.UpdateErrorMsg = orderResult.ResultInfo;
        //                }
        //                //程序异常
        //                else if (orderResult.ResultCode == -3)
        //                {
        //                    updateorderdatamodel.UpdateType = -1;
        //                    updateorderdatamodel.IsUpdate = -1;
        //                    updateorderdatamodel.UpdateErrorMsg = "程序异常";
        //                }
        //                //插入日志
        //                BLL.UpdateOrderData.Instance.Insert(updateorderdatamodel);
        //                //orderservice.CreateNewCarOrder(
        //            }


        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultNewCarErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）

        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;
        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了新车咨询联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型新车ID:【" + retVal + "】");
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultNewCar.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion
        //}

        //private void SaveType2(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultSecondCar model = new ConsultSecondCar();

        //    model.CustID = CustID;

        //    if (list["QuestionType"] != null)
        //    {
        //        if (int.TryParse(list["QuestionType"].ToString(), out intVal))
        //        {
        //            model.QuestionType = int.Parse(list["QuestionType"].ToString());
        //        }
        //    }

        //    if (list["CarBrandId"] != null)
        //    {
        //        if (int.TryParse(list["CarBrandId"].ToString(), out intVal))
        //        {
        //            model.CarBrandId = intVal;
        //        }
        //    }
        //    if (list["CarSerialId"] != null)
        //    {
        //        if (int.TryParse(list["CarSerialId"].ToString(), out intVal))
        //        {
        //            model.CarSerialId = intVal;
        //        }
        //    }
        //    if (list["CarName"] != null)
        //    {
        //        model.CarName = list["CarName"].ToString();
        //    }
        //    if (list["SaleCarBrandId"] != null)
        //    {
        //        if (int.TryParse(list["SaleCarBrandId"].ToString(), out intVal))
        //        {
        //            model.SaleCarBrandId = intVal;
        //        }
        //    }
        //    if (list["SaleCarSerialId"] != null)
        //    {
        //        if (int.TryParse(list["SaleCarSerialId"].ToString(), out intVal))
        //        {
        //            model.SaleCarSerialId = intVal;
        //        }
        //    }
        //    if (list["SaleCarName"] != null)
        //    {
        //        model.SaleCarName = list["SaleCarName"].ToString();
        //    }
        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultSecondCar.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultSecondCarErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultSecondCarErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）

        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了二手车咨询联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型二手车ID:【" + retVal + "】");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultSecondCar.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion
        //}

        //private void SaveType3(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultPFeedback model = new ConsultPFeedback();

        //    model.CustID = CustID;

        //    if (list["QuestionType"] != null)
        //    {
        //        model.QuestionType = HttpContext.Current.Server.UrlDecode(list["QuestionType"].ToString());
        //    }

        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultPFeedback.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultPFeedbackErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultPFeedbackErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）
        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了个人反馈咨询联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型个人反馈ID:【" + retVal + "】");
        //        }

        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultPFeedback.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion

        //}

        //private void SaveType4(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultActivity model = new ConsultActivity();

        //    model.CustID = CustID;

        //    if (list["QuestionType"] != null)
        //    {
        //        if (int.TryParse(list["QuestionType"].ToString(), out intVal))
        //        {
        //            model.QuestionType = int.Parse(list["QuestionType"].ToString());
        //        }
        //    }
        //    if (list["BrandName"] != null)
        //    {
        //        model.BrandName = list["BrandName"].ToString();
        //    }
        //    if (list["ShowActivity"] != null)
        //    {
        //        model.ShowActivity = list["ShowActivity"].ToString();
        //    }

        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultActivity.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultActivityErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultActivityErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）
        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了活动咨询联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型活动ID:【" + retVal + "】");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultActivity.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion

        //}

        //private void SaveType5(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{

        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultPUseCar model = new ConsultPUseCar();

        //    model.CustID = CustID;

        //    if (list["QuestionType"] != null)
        //    {
        //        model.QuestionType = list["QuestionType"].ToString();
        //    }

        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultPUseCar.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultPUseCarErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultPUseCarErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）
        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了个人用车咨询联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型个人用车ID:【" + retVal + "】");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultPUseCar.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion
        //}

        //private void SaveType6(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultPOther model = new ConsultPOther();

        //    model.CustID = CustID;

        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultPOther.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultPOtherErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultPOtherErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）
        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了个人其他咨询联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型个人其他ID:【" + retVal + "】");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultPOther.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion
        //}

        //private void SaveType7(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultDCoop model = new ConsultDCoop();

        //    model.CustID = CustID;

        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    if (list["Type"] != null)
        //    {
        //        if (int.TryParse(list["Type"].ToString(), out intVal))
        //        {
        //            model.Type = intVal;
        //        }
        //    }

        //    if (intVal == 3)
        //    {
        //        //其他
        //        model.QuestionType = 60009;
        //    }
        //    else
        //    {
        //        if (list["QuestionType"] != null)
        //        {
        //            if (int.TryParse(list["QuestionType"].ToString(), out intVal))
        //            {
        //                model.QuestionType = int.Parse(list["QuestionType"].ToString());
        //            }
        //        }
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultDCoop.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultDCoopErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultDCoopErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）
        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            string dCoopTypeName = (int)model.Type == 1 ? "经销商合作" : (int)model.Type == 2 ? "经销商反馈" : "经销商其他";
        //            BLL.Util.InsertUserLog("添加了" + dCoopTypeName + "咨询联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型" + dCoopTypeName + "ID:【" + retVal + "】");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultDCoop.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="list"></param>
        ///// <param name="CustInfoModel"></param>
        ///// <param name="msg"></param>
        //private void SaveType8(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultDFeedback model = new ConsultDFeedback();

        //    model.CustID = CustID;

        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    if (int.TryParse(list["QuestionType"].ToString(), out intVal))
        //    {
        //        model.QuestionType = int.Parse(list["QuestionType"].ToString());
        //    }

        //    if (int.TryParse(list["TelSource"].ToString(), out intVal))
        //    {
        //        model.TelSource = int.Parse(list["TelSource"].ToString());
        //    }

        //    if (list["CallRecordType"] != null && int.TryParse(list["CallRecordType"].ToString(), out intVal))
        //    {
        //        model.CallRecordType = int.Parse(list["CallRecordType"].ToString());
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultDFeedback.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultDFeedbackErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultDFeedbackErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）
        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了经销商反馈联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型个人其他ID:【" + retVal + "】");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultDFeedback.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion
        //}

        //private void SaveType9(Hashtable list, CustHistoryInfo CustInfoModel, out string msg)
        //{
        //    msg = "";
        //    int intVal = 0;

        //    #region 给字段赋值

        //    Entities.ConsultDOther model = new ConsultDOther();

        //    model.CustID = CustID;

        //    if (list["CallRecord"] != null)
        //    {
        //        model.CallRecord = HttpContext.Current.Server.UrlDecode(list["CallRecord"].ToString());
        //    }

        //    model.CreateTime = DateTime.Now;
        //    model.CreateUserID = BLL.Util.GetLoginUserID();

        //    #endregion

        //    #region 添加到数据库

        //    int retVal = 0;
        //    int retCustVal = 0;

        //    try
        //    {
        //        retVal = BLL.ConsultDOther.Instance.Insert(model);
        //        if (retVal == 0)
        //        {
        //            msg = "addConsultDOtherErr";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "addConsultDOtherErr";
        //    }

        //    try
        //    {
        //        //咨询类型（枚举）
        //        CustInfoModel.ConsultID = int.Parse(ConsultID);

        //        //咨询类型数据ID
        //        CustInfoModel.ConsultDataID = retVal;

        //        //如果录音ID大于零，表示之前插入过空的历史记录，需要对此空的历史记录进行修改
        //        if (CustInfoModel.CallRecordID > 0)
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Update(CustInfoModel);
        //        }
        //        else
        //        {
        //            retCustVal = BLL.CustHistoryInfo.Instance.Insert(CustInfoModel);
        //        }
        //        if (retCustVal == 0)
        //        {
        //            msg = "addCustInfoErr";
        //        }
        //        else
        //        {
        //            BLL.Util.InsertUserLog("添加了经销商其他联系信息(客户历史记录信息ID:【" + retCustVal + "】,咨询类型个人其他ID:【" + retVal + "】");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        //回滚
        //        BLL.ConsultDOther.Instance.Delete(retVal);

        //        msg = "addCustInfoErr";
        //    }

        //    #endregion
        //}
        #endregion

        #region 取得客户历史记录信息实体
        /// <summary>
        /// 取得客户历史记录信息实体
        /// </summary>
        /// <param name="DataID">咨询类型数据ID</param>
        /// <returns></returns>
        private Entities.CustHistoryInfo GetMode()
        {
            Entities.CustHistoryInfo model = new CustHistoryInfo();
            Int64 intVal = 0;
            if (Int64.TryParse(CALLID, out intVal) && intVal > 0)
            {
                Entities.CustHistoryInfo modelnew = BLL.CustHistoryInfo.Instance.GetCustHistoryInfoByCallRecordID(intVal);
                if (modelnew != null)
                {
                    model = modelnew;
                    model.CallRecordID = intVal;
                }
            }
            else
            {
                model.CreateTime = DateTime.Now;
            }
            int recordType = 0;
            if (int.TryParse(RecordType, out recordType))
            {
                model.RecordType = recordType;
            }
            model.CustID = CustID;
            //model.ConsultID = int.Parse(ConsultID.ToString());
            // model.ConsultDataID = int.Parse(DataID.ToString());
            //model.QuestionQuality = (int)QuestionNature.NatureCommon;//默认普通
            //model.ProcessStatus = (int)EnumTaskStatus.TaskStatusOver;
            model.CreateUserID = BLL.Util.GetLoginUserID();
            //add by qizq 2013-11-5在custhistoryinfo表里加了业务类型，1为工单，为了区分以后业务、
            model.BusinessType = 1;
            return model;
        }
        #endregion

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}