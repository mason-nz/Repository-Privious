﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using BitAuto.ISDC.CC2012.BLL;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo
{
    public class operPopCustBasicInfo
    {
        public string ccCustID = string.Empty;

        //保存CRM用户到个人用户库
        public void InsertCRMCustInfo(CustBasicInfo info, out string msg)
        {
            msg = string.Empty;

            try
            {
                if (info.CustName == string.Empty || info.Tel == string.Empty)
                {
                    msg = "'result':'false','errorMsg':'数据格式错误！'";
                    return;
                }


                #region 验证数据格式

                validateData(info.CustName, info.Sex, info.Tel, info.CustCategoryID, out msg);
                if (msg != "")
                {
                    msg = "'result':'false','errorMsg':'" + msg + "'";
                    return;
                }

                #endregion

                #region 插入个人信息表CustBasicInfo
                int _sex;
                int _category;
                if (!int.TryParse(info.Sex, out _sex) || !int.TryParse(info.CustCategoryID, out _category))
                {
                    msg = "'result':'false','errorMsg':'Sex:" + info.Sex + ",CustCategoryID:" + info.CustCategoryID + ",数据格式出现错误，无法操作！'";
                    return;
                }

                Entities.CustBasicInfo model = new Entities.CustBasicInfo();
                model.CustName = info.CustName;
                model.Sex = _sex;
                model.CustCategoryID = _category;//3-经销商；4-个人；
                int pID = 0, cID = 0;
                BLL.PhoneNumDataDict.GetAreaId(info.Tel, out pID, out cID);
                model.ProvinceID = pID == 0 ? -2 : pID;
                model.CityID = cID == 0 ? -2 : cID;
                model.CountyID = -1;
                model.AreaID = "";//新增 更新时 自动计算
                model.CallTime = 0;
                model.Status = 0;
                model.CreateUserID = model.ModifyUserID = info.OperID;
                model.CreateTime = model.ModifyTime = info.OperTime;

                ccCustID = BLL.CustBasicInfo.Instance.Insert(model);

                #endregion

                #region 插入电话信息CustTel

                Entities.CustTel model_Tel = new Entities.CustTel();
                model_Tel.CustID = ccCustID;
                model_Tel.CreateTime = info.OperTime;
                model_Tel.CreateUserID = info.OperID;
                model_Tel.Tel = info.Tel;
                BLL.CustTel.Instance.Insert(model_Tel);

                #endregion

                #region 如果客户分类为3-经销商，且经销商ID存在，则插入客户与经销商关联表

                if (info.CustCategoryID == "3" && !string.IsNullOrEmpty(info.MemberID) && !string.IsNullOrEmpty(info.MemberName))
                {
                    Entities.DealerInfo model_Dealer = new Entities.DealerInfo();
                    model_Dealer.CustID = ccCustID;
                    model_Dealer.MemberCode = info.MemberID;
                    model_Dealer.Name = info.MemberName;
                    model_Dealer.Status = 0;
                    model_Dealer.CreateTime = info.OperTime;
                    model_Dealer.CreateUserID = info.OperID;

                    BLL.DealerInfo.Instance.Insert(model_Dealer);
                }

                #endregion

                msg = "'result':'true','CustID':'" + ccCustID + "'";
                BLL.Util.InsertUserLog("个人用户弹出层【新增记录】【插入电话信息】成功【电话】" + info.Tel + "【姓名】" + info.CustName + "【客户分类】" + info.CustCategoryID + "【省份ID】" + pID + "【城市ID】" + cID + "【大区】" + model.AreaID + "【操作人】" + info.OperID + "【操作时间】" + info.OperTime);

            }
            catch (Exception ex)
            {
                BLL.Util.InsertUserLog("个人用户弹出层【新增记录】出错【电话】" + info.Tel + "【姓名】" + info.CustName + "错误信息：" + ex.Message);
                throw new Exception(ex.Message);
            }
        }

        //保存信息到个人用户库
        public void InsertCustInfo(CustBasicInfo info, out string msg)
        {
            msg = string.Empty;

            try
            {
                if (info.CustName == string.Empty || info.Tel == string.Empty)
                {
                    msg = "'result':'false','errorMsg':'数据格式错误！'";
                    return;
                }

                #region 验证姓名+电话在个人用户库中是否存在记录

                //string ccCustID = string.Empty;

                bool dataIsExists = BLL.CustBasicInfo.Instance.IsExistsByCustNameAndTel(info.CustName, info.Tel, out ccCustID);
                if (dataIsExists)
                {
                    msg = "'result':'true','CustID':'" + ccCustID + "'";
                    return;
                }

                #endregion

                #region 验证数据格式

                validateData(info.CustName, info.Sex, info.Tel, info.CustCategoryID, out msg);
                if (msg != "")
                {
                    msg = "'result':'false','errorMsg':'" + msg + "'";
                    return;
                }

                #endregion

                #region 插入个人信息表CustBasicInfo
                int _sex;
                int _category;
                if (!int.TryParse(info.Sex, out _sex) || !int.TryParse(info.CustCategoryID, out _category))
                {
                    msg = "'result':'false','errorMsg':'Sex:" + info.Sex + ",CustCategoryID:" + info.CustCategoryID + ",数据格式出现错误，无法操作！'";
                    return;
                }

                Entities.CustBasicInfo model = new Entities.CustBasicInfo();
                model.CustName = info.CustName;
                model.Sex = _sex;
                model.CustCategoryID = _category;//3-经销商；4-个人；
                int pID = 0, cID = 0;
                BLL.PhoneNumDataDict.GetAreaId(info.Tel, out pID, out cID);
                model.ProvinceID = pID == 0 ? -2 : pID;
                model.CityID = cID == 0 ? -2 : cID;
                model.CountyID = -1;
                model.AreaID = "";//新增 更新时 自动计算
                model.CallTime = 0;
                model.Status = 0;
                model.CreateUserID = model.ModifyUserID = info.OperID;
                model.CreateTime = model.ModifyTime = info.OperTime;

                ccCustID = BLL.CustBasicInfo.Instance.Insert(model);

                #endregion

                #region 插入电话信息CustTel

                Entities.CustTel model_Tel = new Entities.CustTel();
                model_Tel.CustID = ccCustID;
                model_Tel.CreateTime = info.OperTime;
                model_Tel.CreateUserID = info.OperID;
                model_Tel.Tel = info.Tel;
                BLL.CustTel.Instance.Insert(model_Tel);

                #endregion

                #region 如果客户分类为3-经销商，且经销商ID存在，则插入客户与经销商关联表

                if (info.CustCategoryID == "3" && !string.IsNullOrEmpty(info.MemberID) && !string.IsNullOrEmpty(info.MemberName))
                {
                    Entities.DealerInfo model_Dealer = new Entities.DealerInfo();
                    model_Dealer.CustID = ccCustID;
                    model_Dealer.MemberCode = info.MemberID;
                    model_Dealer.Name = info.MemberName;
                    model_Dealer.Status = 0;
                    model_Dealer.CreateTime = info.OperTime;
                    model_Dealer.CreateUserID = info.OperID;

                    BLL.DealerInfo.Instance.Insert(model_Dealer);
                }

                #endregion

                msg = "'result':'true','CustID':'" + ccCustID + "'";
                BLL.Util.InsertUserLog("个人用户弹出层【新增记录】【插入电话信息】成功【电话】" + info.Tel + "【姓名】" + info.CustName + "【客户分类】" + info.CustCategoryID + "【省份ID】" + pID + "【城市ID】" + cID + "【大区】" + model.AreaID + "【操作人】" + info.OperID + "【操作时间】" + info.OperTime);

            }
            catch (Exception ex)
            {
                BLL.Util.InsertUserLog("个人用户弹出层【新增记录】出错【电话】" + info.Tel + "【姓名】" + info.CustName + "错误信息：" + ex.Message);
                throw new Exception(ex.Message);
            }
        }


        //保存信息客户联系人职务，部门到CustContactInfo
        public void InsertCustInfo(CustBasicInfo info, Entities.CustContactInfo ccinfo,out string msg)
        {
            msg = string.Empty;

            try
            {
                if (info.CustName == string.Empty || info.Tel == string.Empty)
                {
                    msg = "'result':'false','errorMsg':'数据格式错误！'";
                    return;
                }

                #region 验证姓名+电话在个人用户库中是否存在记录

                bool dataIsExists = BLL.CustBasicInfo.Instance.IsExistsByCustNameAndTel(info.CustName, info.Tel, out ccCustID);
                if (dataIsExists)
                {
                    msg = "'result':'true','CustID':'" + ccCustID + "'";
                    return;
                }

                #endregion

                #region 验证数据格式

                validateData(info.CustName, info.Sex, info.Tel, info.CustCategoryID, out msg);
                if (msg != "")
                {
                    msg = "'result':'false','errorMsg':'" + msg + "'";
                    return;
                }

                #endregion

                #region 插入个人信息表CustBasicInfo
                int _sex;
                int _category;
                if (!int.TryParse(info.Sex, out _sex) || !int.TryParse(info.CustCategoryID, out _category))
                {
                    msg = "'result':'false','errorMsg':'Sex:" + info.Sex + ",CustCategoryID:" + info.CustCategoryID + ",数据格式出现错误，无法操作！'";
                    return;
                }

                Entities.CustBasicInfo model = new Entities.CustBasicInfo();
                model.CustName = info.CustName;
                model.Sex = _sex;
                model.CustCategoryID = _category;//3-经销商；4-个人；
                int pID = 0, cID = 0;
                BLL.PhoneNumDataDict.GetAreaId(info.Tel, out pID, out cID);
                model.ProvinceID = pID == 0 ? -2 : pID;
                model.CityID = cID == 0 ? -2 : cID;
                model.CountyID = -1;
                model.AreaID = "";//新增 更新时 自动计算
                model.CallTime = 0;
                model.Status = 0;
                model.CreateUserID = model.ModifyUserID = info.OperID;
                model.CreateTime = model.ModifyTime = info.OperTime;

                ccCustID = BLL.CustBasicInfo.Instance.Insert(model);

                #endregion

                #region 插入电话信息CustTel

                Entities.CustTel model_Tel = new Entities.CustTel();
                model_Tel.CustID = ccCustID;
                model_Tel.CreateTime = info.OperTime;
                model_Tel.CreateUserID = info.OperID;
                model_Tel.Tel = info.Tel;
                BLL.CustTel.Instance.Insert(model_Tel);

                #endregion

                #region 如果客户分类为3-经销商，且经销商ID存在，则插入客户与经销商关联表

                if (info.CustCategoryID == "3" && !string.IsNullOrEmpty(info.MemberID) && !string.IsNullOrEmpty(info.MemberName))
                {
                    Entities.DealerInfo model_Dealer = new Entities.DealerInfo();
                    model_Dealer.CustID = ccCustID;
                    model_Dealer.MemberCode = info.MemberID;
                    model_Dealer.Name = info.MemberName;
                    model_Dealer.Status = 0;
                    model_Dealer.CreateTime = info.OperTime;
                    model_Dealer.CreateUserID = info.OperID;

                    BLL.DealerInfo.Instance.Insert(model_Dealer);
                }

                #endregion

                #region 保存联系人联务、部门、CRM客户ID
                if (!string.IsNullOrEmpty(ccinfo.CRMCustID))
                {
                    ccinfo.CustID = ccCustID;
                    ccinfo.CreateTime = DateTime.Now;

                    BLL.CustContactInfo.Instance.Insert(ccinfo);
                }
                #endregion

                msg = "'result':'true','CustID':'" + ccCustID + "'";
                BLL.Util.InsertUserLog("个人用户弹出层【新增记录】【插入电话信息】成功【电话】" + info.Tel + "【姓名】" + info.CustName + "【客户分类】" + info.CustCategoryID + "【省份ID】" + pID + "【城市ID】" + cID + "【大区】" + model.AreaID + "【操作人】" + info.OperID + "【操作时间】" + info.OperTime);

            }
            catch (Exception ex)
            {
                BLL.Util.InsertUserLog("个人用户弹出层【新增记录】出错【电话】" + info.Tel + "【姓名】" + info.CustName + "错误信息：" + ex.Message);
                msg = "'result':'false','errorMsg':'" + ex.Message + "'";
            }
        }

        //保存CRM联系人用户职务、部门
        public void UpdateCustContactInfo(Entities.CustContactInfo ccinfo, out string msg)
        {
            msg = "";

            try
            {
                if (!string.IsNullOrEmpty(ccinfo.CRMCustID) && !string.IsNullOrEmpty(ccinfo.CustID))
                {
                    Entities.CustContactInfo model = BLL.CustContactInfo.Instance.GetCustContactInfoByCustID(ccinfo.CustID);

                    if (model != null)
                    {
                        BLL.Util.InsertUserLog("个人用户[CustID:" + ccinfo.CustID + "],职务由[" + model.Title + "]更新为[" + ccinfo.Title + "],部门由[" + model.DepartMent + "]更新为[" + ccinfo.DepartMent + "]");
                        model.CRMCustID = ccinfo.CRMCustID;
                        model.DepartMent = ccinfo.DepartMent;
                        model.Title = ccinfo.Title;

                        BLL.CustContactInfo.Instance.Update(model);
                        msg = "'result':'true','Msg':'个人用户职务、部门更新成功！CustID:" + ccinfo.CustID + "！'";
                    }
                    else
                    {
                        ccinfo.CreateUserID = BLL.Util.GetLoginUserID();
                        ccinfo.CreateTime = DateTime.Now;
                        BLL.CustContactInfo.Instance.Insert(ccinfo);
                        msg = "'result':'true','Msg':'个人用户职务、部门插入成功！CustID:" + ccinfo.CustID + "！'";
                    }
                }
                else
                {
                    msg = "'result':'false','errorMsg':'CRM客户号或个人用户ID为空！CustID:" + ccinfo.CustID + "！'";
                }
            }
            catch (Exception ex)
            {
                msg = "'result':'false','errorMsg':'个人用户职务、部门更新失败！CustID:" + ccinfo.CustID + "！'";
                BLL.Util.InsertUserLog("个人用户职务、部门更新失败CustID:" + ccinfo.CustID + ",错误信息：" + ex.Message);
            }
            
        }

        //验证数据格式
        private void validateData(string CustName, string Sex, string Tel, string CustCategoryID, out string errorMsg)
        {
            errorMsg = "";
            if (CustName == "")
            {
                errorMsg += "姓名不能为空！<br/>";
            }
            if (Sex == "")
            {
                errorMsg += "请选择性别！<br/>";
            }
            if (Tel == "")
            {
                errorMsg += "电话不能为空！<br/>";
            }
            if (CustCategoryID == "")
            {
                errorMsg += "客户分类不能为空！";
            }
        }

        //验证电话号码+姓名在个人用户库是否存在
        public void telIsExists(string CustName, string Tel, out string msg)
        {
            msg = string.Empty;
            if (Tel == string.Empty)
            {
                msg = "'result':'false'";//数据格式错误
                return;
            }
            string ccCustID = string.Empty;

            bool dataIsExists = BLL.CustBasicInfo.Instance.IsExistsByCustNameAndTel(CustName, Tel, out ccCustID);
            if (dataIsExists)
            {
                msg = "'result':'true','isExists':'yes','CustID':'" + ccCustID + "'";//存在
            }
            else
            {
                msg = "'result':'true','isExists':'no'";//不存在
            }

        }

        //操作（插入或更新）联系记录
        public void operCustHistoryInfo(ContactCustHistoryInfo contact, out string msg)
        {
            Loger.Log4Net.Info("[operPopCustBasicInfo.cs]操作业务记录表operCustHistoryInfo start TaskID：" + contact.TaskID + ",CallRecordID：" + contact.CallRecordID + ",CustID：" + contact.CustID);
            msg = "'result':'false'";
            //判断该TaskID是否有过记录，有记录更新，无记录就插入一条.
            int bType;
            if (contact.TaskID == string.Empty || !int.TryParse(contact.BusinessType, out bType) || contact.CallRecordID == string.Empty || contact.RecordType == string.Empty && contact.CustID == string.Empty)
            {
                return;
            }
            string logDesc = string.Empty;

            Entities.CustHistoryInfo model = BLL.CustHistoryInfo.Instance.GetCustHistoryInfo(contact.TaskID, contact.CustID, bType);
            if (model == null)
            {
                //model=null 表示不存在联系记录需要插入
                model = new Entities.CustHistoryInfo();
                model.TaskID = contact.TaskID;
                model.CallRecordID = long.Parse(contact.CallRecordID);
                model.CustID = contact.CustID;
                model.RecordType = int.Parse(contact.RecordType);
                model.BusinessType = bType;
                model.CreateTime = contact.OperTime;
                model.CreateUserID = contact.OperID;
                BLL.CustHistoryInfo.Instance.Insert(model);
                logDesc = "【CustHistoryInfo】表插入记录：【TaskID】" + contact.TaskID + "【CallRecordID】" + contact.CallRecordID + "【CustID】" + contact.CustID + "【RecordType】" + bType + "【CreateTime】" + contact.OperTime + "【CreateUserID】" + contact.OperID + "【RecordType】" + contact.RecordType;
            }
            else
            {
                //存在记录，则更新
                model.CallRecordID = long.Parse(contact.CallRecordID);
                model.RecordType = 2;
                BLL.CustHistoryInfo.Instance.Update(model);
                logDesc = "【CustHistoryInfo】表更新记录：【RecID】" + model.RecID + "【CallRecordID】" + contact.CallRecordID;
            }
            //BLL.Util.InsertUserLog(logDesc);
            msg = "'result':'true'";
            Loger.Log4Net.Info("[operPopCustBasicInfo.cs]操作业务记录表operCustHistoryInfo bye bye TaskID：" + contact.TaskID + ",CallRecordID：" + contact.CallRecordID + ",CustID：" + contact.CustID);
        }

        //操作（插入）个人用户电话
        public void operCustTel(string custid, string tel, out string msg)
        {
            msg = "'result':'false'";
            //判断该TaskID是否有过记录，有记录更新，无记录就插入一条.
            if (string.IsNullOrEmpty(custid) || string.IsNullOrEmpty(tel))
            {
                return;
            }
            string logDesc = string.Empty;

            Entities.CustTel model = BLL.CustTel.Instance.GetCustTel(custid, tel);
            if (model == null)
            {
                model = new Entities.CustTel();
                model.CustID = custid;
                model.Tel = tel;
                model.CreateTime = DateTime.Now;
                model.CreateUserID = BLL.Util.GetLoginUserID();
                BLL.CustTel.Instance.Insert(model);
                logDesc = "【CustTel】表插入记录：【CustID】" + custid + "【Tel】" + tel + "【CreateTime】" + model.CreateTime + "【CreateUserID】" + model.CreateUserID;
            }

            msg = "'result':'true'";
            BLL.Util.InsertUserLog(logDesc);

        }

        public void operCustTel(string custid, string custname, string orderid, string tel, out string msg)
        {
            msg = "'result':'false'";
            //判断该TaskID是否有过记录，有记录更新，无记录就插入一条.
            if (string.IsNullOrEmpty(custid) || string.IsNullOrEmpty(tel))
            {
                return;
            }
            string logDesc = string.Empty;

            Entities.CustTel model = BLL.CustTel.Instance.GetCustTel(custid, tel);
            if (model == null)
            {
                //新增电话时，根据姓名+电话判断是否有重复数据
                //有则发送报错邮件
                string existCustid = "";
                bool dataIsExists = BLL.CustBasicInfo.Instance.IsExistsByCustNameAndTel(custname, tel, out existCustid);
                if (dataIsExists)
                {
                    string mailBody = "工单" + orderid + ",外呼挂断保存业务记录出错:当前用户" + custid + "跟用户" + existCustid + "姓名" + custname + "+电话" + tel + "重复!";
                    SendErrorMail(mailBody, "工单" + orderid + "业务记录保存错误", out msg);
                }

                model = new Entities.CustTel();
                model.CustID = custid;
                model.Tel = tel;
                model.CreateTime = DateTime.Now;
                model.CreateUserID = BLL.Util.GetLoginUserID();
                BLL.CustTel.Instance.Insert(model);
                logDesc = "【CustTel】表插入记录：【CustID】" + custid + "【Tel】" + tel + "【CreateTime】" + model.CreateTime + "【CreateUserID】" + model.CreateUserID;

            }

            msg = "'result':'true'";
            BLL.Util.InsertUserLog(logDesc);

        }

        private void SendErrorMail(string mailBody, string subject, out string msg)
        {
            string userEmails = ConfigurationManager.AppSettings["ReceiveErrorEmail"];
            string[] userEmail = userEmails.Split(';');
            if (userEmail != null && userEmail.Length > 0)
            {
                BLL.EmailHelper.Instance.SendErrorMail(mailBody, subject, userEmail);
                msg = "'result':'true'";
            }
            else
            {
                msg = "'result':'false'";
            }
        }

    }
}