﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using System.Data;
using BitAuto.ISDC.CC2012.BLL;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo
{
    /// <summary>
    /// popCustBasicInfo 的摘要说明
    /// </summary>
    public class popCustBasicInfo : IHttpHandler, IRequiresSessionState
    {

        private HttpRequest Request
        {
            get { return HttpContext.Current.Request; }
        }

        private string Action
        {
            get
            {
                if (Request["Action"] != null)
                {
                    return HttpUtility.UrlDecode(Request["Action"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string CRMCustID
        {
            get
            {
                if (Request["CRMCustID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CRMCustID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        #region 个人用户信息

        private string CustName
        {
            get
            {
                if (Request["CustName"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CustName"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string OrderID
        {
            get
            {
                if (Request["OrderID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["OrderID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        private string Sex
        {
            get
            {
                if (Request["Sex"] != null)
                {
                    return HttpUtility.UrlDecode(Request["Sex"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string Tel
        {
            get
            {
                if (Request["Tel"] != null)
                {
                    return HttpUtility.UrlDecode(Request["Tel"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string CustCategoryID
        {
            get
            {
                if (Request["CustCategoryID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CustCategoryID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string MemberName
        {
            get
            {
                if (Request["MemberName"] != null)
                {
                    return HttpUtility.UrlDecode(Request["MemberName"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string MemberID
        {
            get
            {
                if (Request["MemberID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["MemberID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        #endregion
        #region 个人用户联系人表信息
        private string DepartMent
        {
            get
            {
                if (Request["DepartMent"] != null)
                {
                    return HttpUtility.UrlDecode(Request["DepartMent"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        private string Title
        {
            get
            {
                if (Request["Title"] != null)
                {
                    return HttpUtility.UrlDecode(Request["Title"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }
        #endregion
        #region 录音记录表信息

        private string isOperCustHistoryInfo  //1-插入或更新到录音记录表
        {
            get
            {
                if (Request["isOperCustHistoryInfo"] != null)
                {
                    return HttpUtility.UrlDecode(Request["isOperCustHistoryInfo"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string TaskID
        {
            get
            {
                if (Request["TaskID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["TaskID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string CallRecordID
        {
            get
            {
                if (Request["CallRecordID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CallRecordID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string RecordType   //记录类型（1-呼入，2-呼出）
        {
            get
            {
                if (Request["RecordType"] != null)
                {
                    return HttpUtility.UrlDecode(Request["RecordType"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string BusinessType   //业务类型：1工单，2团购订单，3客户核实，4其他任务
        {
            get
            {
                if (Request["BusinessType"] != null)
                {
                    return HttpUtility.UrlDecode(Request["BusinessType"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        private string CustID
        {
            get
            {
                if (Request["CustID"] != null)
                {
                    return HttpUtility.UrlDecode(Request["CustID"].ToString());
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        #endregion

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();

            operPopCustBasicInfo cbi = new operPopCustBasicInfo();

            string msg = string.Empty;
            switch (Action)
            {
                case "InsertBasicInfo2"://插入客户联系人职务、部门到表CustContactInfo
                    CustBasicInfo info2 = new CustBasicInfo();
                    info2.CustName = CustName;
                    info2.Sex = Sex;
                    info2.Tel = Tel;
                    info2.CustCategoryID = CustCategoryID;
                    if (!string.IsNullOrEmpty(CRMCustID))//如果是CRM客户ID
                    {
                        string[] array = getMemberInfo(CRMCustID);
                        if (array.Length > 0)
                        {
                            info2.MemberID = array[0];
                            info2.MemberName = array[1];
                        }
                    }
                    else
                    {
                        info2.MemberID = MemberID;
                        info2.MemberName = MemberName;
                    }
                    info2.OperID = BLL.Util.GetLoginUserID();

                    Entities.CustContactInfo ccinfo = new Entities.CustContactInfo();
                    ccinfo.CRMCustID = CRMCustID;
                    ccinfo.Title = Title;
                    ccinfo.DepartMent = DepartMent;
                    ccinfo.CreateUserID = info2.OperID;
                    cbi.InsertCustInfo(info2, ccinfo,out msg);
                    break;
                case "UpdateCustContactInfo"://如果联系人在个人用户中已存在，则需更新职务、部门                    
                    Entities.CustContactInfo ccinfo2 = new Entities.CustContactInfo();
                    ccinfo2.CustID = CustID;
                    ccinfo2.CRMCustID = CRMCustID;
                    ccinfo2.Title = Title;
                    ccinfo2.DepartMent = DepartMent;
                    cbi.UpdateCustContactInfo(ccinfo2, out msg);
                    break;
                case "InsertBasicInfo":
                    CustBasicInfo info = new CustBasicInfo();
                    info.CustName = CustName;
                    info.Sex = Sex;
                    info.Tel = Tel;
                    info.CustCategoryID = CustCategoryID;
                    if (!string.IsNullOrEmpty(CRMCustID))//如果是CRM客户ID
                    {
                        string[] array = getMemberInfo(CRMCustID);
                        if (array.Length > 0)
                        {
                            info.MemberID = array[0];
                            info.MemberName = array[1];
                        }
                    }
                    else
                    {
                        info.MemberID = MemberID;
                        info.MemberName = MemberName;
                    }
                    info.OperID = BLL.Util.GetLoginUserID();
                    cbi.InsertCustInfo(info, out msg);
                    break;
                case "telIsExists": cbi.telIsExists(CustName, Tel, out msg);
                    break;
                case "operCustHistoryInfo":
                    Loger.Log4Net.Info("[popCustBasicInfo.ashx]操作业务记录表TaskID：" + TaskID + ",CallRecordID：" + CallRecordID + ",CustID：" + CustID);
                    ContactCustHistoryInfo contact = new ContactCustHistoryInfo();
                    contact.TaskID = TaskID;
                    contact.BusinessType = BusinessType;
                    contact.CallRecordID = CallRecordID;
                    contact.RecordType = RecordType;
                    contact.CustID = CustID;
                    contact.OperID = BLL.Util.GetLoginUserID();
                    try
                    {
                        cbi.operCustHistoryInfo(contact, out msg);
                    }
                    catch (Exception ex)
                    {
                        Loger.Log4Net.Info("[popCustBasicInfo.ashx]操作业务记录表TaskID：" + contact.TaskID + ",CallRecordID：" + contact.CallRecordID + ",CustID：" + contact.CustID);
                        Loger.Log4Net.Info("[popCustBasicInfo.ashx]操作业务记录表ErrorMessage：" + ex.Message + ",errorStackTrace:" + ex.StackTrace);
                    }
                    
                    break;
                case "operCustTel":
                    cbi.operCustTel(CustID, Tel, out msg);
                    break;
                case "operCustTel2"://工单处理面外呼挂断保存电话操作
                    cbi.operCustTel(CustID,CustName,OrderID,Tel, out msg);
                    break;
            }

            context.Response.Write("{" + msg + "}");
        }

        protected string[] getMemberInfo(string CRMCustID)
        {
            DataTable dt = BitAuto.YanFa.Crm2009.BLL.CstMember.Instance.SelectByCustID(CRMCustID);
            string[] array = new string[2];
            if (dt.Rows.Count > 0)
            {
                //string[] array = new string[] { dt.Rows[0]["MemberCode"].ToString(), dt.Rows[0]["FullName"].ToString() };
                array[0] = dt.Rows[0]["MemberCode"].ToString();
                array[1] = dt.Rows[0]["FullName"].ToString();
            }

            return array;
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}