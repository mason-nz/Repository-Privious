﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo
{
    public class ContactCustHistoryInfo
    {
        private string taskID = string.Empty;

        public string TaskID
        {
            get { return taskID; }
            set { taskID = value; }
        }
        private string businessType = string.Empty;

        public string BusinessType
        {
            get { return businessType; }
            set { businessType = value; }
        }
        private string callRecordID = string.Empty;

        public string CallRecordID
        {
            get { return callRecordID; }
            set { callRecordID = value; }
        }
        private string recordType = string.Empty;

        public string RecordType
        {
            get { return recordType; }
            set { recordType = value; }
        }
        private string custID = string.Empty;

        public string CustID
        {
            get { return custID; }
            set { custID = value; }
        }
        private int operID = 0;

        public int OperID
        {
            get { return operID; }
            set { operID = value; }
        }

        private DateTime operTime = DateTime.Now;

        public DateTime OperTime
        {
            get { return operTime; }
            set { operTime = value; }
        }
    }
}