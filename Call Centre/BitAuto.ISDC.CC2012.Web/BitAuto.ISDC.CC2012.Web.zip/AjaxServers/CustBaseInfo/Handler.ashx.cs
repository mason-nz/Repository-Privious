﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.CustBaseInfo
{
    /// <summary>
    /// Handler 的摘要说明
    /// </summary>
    public class Handler : IHttpHandler, IRequiresSessionState
    {
 
        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();

            CustBaseInfoHelper helper = new CustBaseInfoHelper();
            string msg = string.Empty;
            switch (helper.Action.ToLower())
            {
                case "addcustbaseinfo":
                    helper.SubmitCheckInfo(false, out msg);
                    break;
                case "updatecustbaseinfo":
                    helper.SubmitCheckInfo(true, out msg);
                    break;
                case "getcurrenttype":
                    helper.GetCurrentType(out msg);
                    break;
                case "forwardtask":
                    try
                    {
                        helper.ForwardTask(out msg);
                    }
                    catch (Exception ex)
                    {
                        msg = ex.Message;
                    }
                    break;
                case "deletecustbaseinfo":
                    //增加“客户池--个人客户”删除功能验证逻辑
                    if (BLL.Util.CheckButtonRight("SYS024BUT2101"))
                    {
                        helper.DeleteCustBaseInfo(out msg);
                    }
                    else
                    {
                        msg = "您现在没有删除权限，请联系管理员";
                    }
                    break;
                case "gettemplatecategory":
                    helper.GetTemplateCategory(out msg);
                    break;
                case "gettemplateinfo":
                    helper.GetTemplateInfo(out msg);
                    break;
                case "gettemplateinfodetail":
                    helper.GetDetailTemplateInfo(out msg);
                    break;
                case "sendsms":
                    try
                    {
                        //modify by qizq 2013-8-13,发短信模式改成无主订单模式
                        //helper.SendSMS(out msg);
                        helper.SendSMSNew(out msg);
                        helper.SendSMSNew3(msg);

                    }
                    catch (Exception ex)
                    {
                        msg = ex.Message;
                    }
                    break;
                case "sendsms2":
                    try
                    {                        
                        helper.SendSMSNew2(out msg);
                    }
                    catch (Exception ex)
                    {
                        msg = ex.Message;
                    }
                    break;
                case "getsolveuserinfo":
                    helper.GetSolveUserInfo(out msg);
                    break;
                case "getdepartid"://获取大区ID
                    helper.GetAreaDistrictID(out msg);
                    break;
                case "getcustbasicinfo":
                    helper.GetCustBasicInfoByCustID(out msg);
                    break;
                case "updatesmssendhistory":
                    helper.UpdateSentSMSHistoryInfo();
                    break;
                //case "gentaochebzcurl"://生成二手车-安心购保障车项目链接URL
                //    helper.GetTaoCheBZCUrl(out msg);
                //    break;
            }
            context.Response.Write(msg);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}