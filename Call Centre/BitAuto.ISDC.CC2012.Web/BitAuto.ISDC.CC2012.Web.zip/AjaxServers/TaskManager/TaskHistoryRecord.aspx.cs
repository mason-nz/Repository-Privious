﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.ISDC.CC2012.Entities;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.TaskManager
{
    public partial class TaskHistoryRecord : BitAuto.ISDC.CC2012.Web.Base.PageBase
    {
        #region 属性
        private string RequestRecID
        {
            get { return HttpContext.Current.Request["RecID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["RecID"].ToString()); }
        }
        private string RequestCustID
        {
            get { return HttpContext.Current.Request["CustID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["CustID"].ToString()); }
        }
        #endregion

        public int PageSize = BLL.PageCommon.Instance.PageSize = 10;
        public int GroupLength = 8;
        public int RecordCount;
        //审批
        public bool canPend = false;
        //处理
        public bool canHandler = false;

        public string YPFanXianHBuyCarURL = System.Configuration.ConfigurationManager.AppSettings["EPEmbedCCHBugCar_URL"].ToString();//惠买车URL
        public string EPEmbedCCHBuyCar_APPID = System.Configuration.ConfigurationManager.AppSettings["EPEmbedCCHBuyCar_APPID"];//易湃签入CC页面，惠买车APPID
        private Random R = new Random();
        public string tableEndName = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                canPend = BLL.Util.CheckButtonRight("SYS024BUG100601");
                canHandler = BLL.Util.CheckButtonRight("SYS024BUG100602");

                BindData();
            }
        }

        private void BindData()
        {
            if (RequestCustID != "")
            {
                QueryCustHistoryInfo query = new QueryCustHistoryInfo();
                query.CustID = RequestCustID;
                tableEndName = "";//只查询现在表数据
                DataTable dt = BLL.CallRecord_ORIG.Instance.GetCustHistoryInfoForWork(query, "chi.CreateTime desc", BLL.PageCommon.Instance.PageIndex, PageSize, tableEndName, out RecordCount);
                repeaterTableList.DataSource = dt;
                repeaterTableList.DataBind();

                litPagerDown.Text = BLL.PageCommon.Instance.LinkStringByPost(BLL.Util.GetUrl(), GroupLength, RecordCount, PageSize, BLL.PageCommon.Instance.PageIndex, 1);
            }
        }

        /// <summary>
        /// 根据操作人ID得到权限系统中操作人名称
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        public string getEmployName(string eid)
        {
            string name = string.Empty;
            int id;
            if (int.TryParse(eid, out id))
            {
                name = BitAuto.YanFa.SysRightManager.Common.UserInfo.GerTrueName(id);
            }
            return name;
        }

        /// <summary>
        /// 根据咨询类型ID得到咨询类型名称
        /// </summary>
        /// <param name="consultID"></param>
        /// <returns></returns>
        public string getConsultTypeByConsultID(string consultID)
        {
            string consultType = string.Empty;
            int _consultID;
            if (int.TryParse(consultID, out _consultID))
            {
                consultType = getConsultNameAndQuestionTypeByConsultID(_consultID, "")[0];
            }
            return consultType;
        }

        //根据咨询类型ID和咨询类型数据ID得到问题类别名称
        public string getConsultTypeByConsultIDAndRecID(string consultID, string recID)
        {
            string questionType = string.Empty;
            int _consultID;
            if (int.TryParse(consultID, out _consultID))
            {
                questionType = getConsultNameAndQuestionTypeByConsultID(_consultID, recID)[1];
            }
            return questionType;
        }

        //根据咨询类型和咨询类型数据ID得到来电记录
        public string getCallRecordByConsultIDAndRecID(string consultID, string recID)
        {
            string callRecord = string.Empty;
            int _consultID;
            if (int.TryParse(consultID, out _consultID))
            {
                callRecord = getConsultNameAndQuestionTypeByConsultID(_consultID, recID)[2];
            }
            return callRecord;
        }

        //根据咨询类型ID得到名称和问题类别、来电记录的数组
        private string[] getConsultNameAndQuestionTypeByConsultID(int consultID, string recID)
        {
            string[] consultNameAndQuestionType = new string[3];
            switch (consultID)
            {
                case 60001: consultNameAndQuestionType[0] = "新车";
                    string callRecord = string.Empty;
                    if (recID != "")
                    {
                        ConsultNewCar model = new ConsultNewCar();
                        model = BLL.ConsultNewCar.Instance.GetConsultNewCar(int.Parse(recID));
                        if (model != null)
                        {
                            callRecord = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = "";
                    consultNameAndQuestionType[2] = callRecord;
                    break;
                case 60002: consultNameAndQuestionType[0] = "二手车";
                    string callRecord1 = string.Empty;
                    string type1 = string.Empty;
                    if (recID != "")
                    {
                        ConsultSecondCar model = new ConsultSecondCar();
                        model = BLL.ConsultSecondCar.Instance.GetConsultSecondCar(int.Parse(recID));
                        if (model != null)
                        {
                            switch (model.QuestionType)
                            {
                                case 70001: type1 = "买车";
                                    break;
                                case 70002: type1 = "卖车";
                                    break;
                                case 70003: type1 = "删除";
                                    break;
                            }
                            callRecord1 = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = type1;
                    consultNameAndQuestionType[2] = callRecord1;
                    break;
                case 60003: consultNameAndQuestionType[0] = "个人反馈";
                    string callRecord2 = string.Empty;
                    string type2 = string.Empty;
                    if (recID != "")
                    {
                        ConsultPFeedback model = new ConsultPFeedback();
                        model = BLL.ConsultPFeedback.Instance.GetConsultPFeedback(int.Parse(recID));
                        if (model != null)
                        {
                            string[] array_Type = model.QuestionType.Split(',');
                            for (int i = 0; i < array_Type.Length; i++)
                            {
                                switch (array_Type[i])
                                {
                                    case "80001": type2 += "论坛,";
                                        break;
                                    case "80002": type2 += "编辑,";
                                        break;
                                    case "80003": type2 += "经销商,";
                                        break;
                                    case "80004": type2 += "产品,";
                                        break;
                                    case "80005": type2 += "活动,";
                                        break;
                                    case "80006": type2 += "呼叫中心,";
                                        break;
                                }
                            }
                            callRecord2 = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = type2.TrimEnd(',');
                    consultNameAndQuestionType[2] = callRecord2;
                    break;
                case 60004: consultNameAndQuestionType[0] = "活动";
                    string callRecord3 = string.Empty;
                    string type3 = string.Empty;
                    if (recID != "")
                    {
                        ConsultActivity model = new ConsultActivity();
                        model = BLL.ConsultActivity.Instance.GetConsultActivity(int.Parse(recID));
                        if (model != null)
                        {
                            switch (model.QuestionType)
                            {
                                case 1: type3 = "活动前";
                                    break;
                                case 2: type3 = "活动后";
                                    break;
                            }
                            callRecord3 = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = type3;
                    consultNameAndQuestionType[2] = callRecord3;
                    break;
                case 60005: consultNameAndQuestionType[0] = "个人用车";
                    string callRecord4 = string.Empty;
                    string type4 = string.Empty;
                    if (recID != "")
                    {
                        ConsultPUseCar model = new ConsultPUseCar();
                        model = BLL.ConsultPUseCar.Instance.GetConsultPUseCar(int.Parse(recID));
                        if (model != null)
                        {
                            string[] array_Type = model.QuestionType.Split(',');

                            for (int i = 0; i < array_Type.Length; i++)
                            {
                                switch (array_Type[i])
                                {
                                    case "90001": type4 += "信贷,";
                                        break;
                                    case "90002": type4 += "保险,";
                                        break;
                                    case "90003": type4 += "养护维修,";
                                        break;
                                    case "90004": type4 += "自驾游,";
                                        break;
                                    case "90005": type4 += "其他,";
                                        break;
                                }
                            }
                            callRecord4 = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = type4.TrimEnd(',');
                    consultNameAndQuestionType[2] = callRecord4;
                    break;
                case 60006: consultNameAndQuestionType[0] = "个人其他";
                    string callRecord0 = string.Empty;
                    if (recID != "")
                    {
                        ConsultPOther model = new ConsultPOther();
                        model = BLL.ConsultPOther.Instance.GetConsultPOther(int.Parse(recID));
                        if (model != null)
                        {
                            callRecord0 = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = "";
                    consultNameAndQuestionType[2] = callRecord0;
                    break;
                case 60007: consultNameAndQuestionType[0] = "经销商合作";
                    consultNameAndQuestionType[1] = getDCoopQuestionType(recID)[0];
                    consultNameAndQuestionType[2] = getDCoopQuestionType(recID)[1];
                    break;
                case 60008: consultNameAndQuestionType[0] = "经销商反馈";
                    consultNameAndQuestionType[1] = getDFeedbackQuestionType(recID)[0];
                    consultNameAndQuestionType[2] = getDFeedbackQuestionType(recID)[1];
                    break;
                case 60009: consultNameAndQuestionType[0] = "经销商其他";
                    consultNameAndQuestionType[1] = getDOtherQuestionType(recID)[0];
                    consultNameAndQuestionType[2] = getDOtherQuestionType(recID)[1];
                    break;
                case 60010: consultNameAndQuestionType[0] = "无主订单-新车";
                    string callRecord10 = string.Empty;
                    if (recID != "")
                    {
                        ConsultOrderNewCar model = new ConsultOrderNewCar();
                        model = BLL.ConsultOrderNewCar.Instance.GetConsultOrderNewCar(int.Parse(recID));
                        if (model != null)
                        {
                            callRecord10 = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = "";
                    consultNameAndQuestionType[2] = callRecord10;
                    break;
                case 60011: consultNameAndQuestionType[0] = "无主订单-置换";
                    string callRecord11 = string.Empty;
                    if (recID != "")
                    {
                        ConsultOrderRelpaceCar model = new ConsultOrderRelpaceCar();
                        model = BLL.ConsultOrderRelpaceCar.Instance.GetConsultOrderRelpaceCar(int.Parse(recID));
                        if (model != null)
                        {
                            callRecord11 = model.CallRecord;
                        }
                    }
                    consultNameAndQuestionType[1] = "";
                    consultNameAndQuestionType[2] = callRecord11;
                    break;
            }
            return consultNameAndQuestionType;
        }

        //根据任务状态ID获取任务状态名称
        public string getStatusByID(string statusID)
        {
            string status = string.Empty;
            int _status;
            if (int.TryParse(statusID, out _status))
            {
                switch (_status)
                {
                    case 150001: status = "待处理";
                        break;
                    case 150002: status = "处理中";
                        break;
                    case 150003: status = "已处理";
                        break;
                }
            }
            return status;
        }

        //根据经销商表主键获取类型名称 和 来电记录
        private string[] getDCoopQuestionType(string recID)
        {
            string[] questionType = new string[2];
            int _recID;
            if (int.TryParse(recID, out _recID))
            {
                ConsultDCoop model = new ConsultDCoop();
                model = BLL.ConsultDCoop.Instance.GetConsultDCoop(_recID);
                if (model != null)
                {
                    string type = string.Empty;
                    switch (model.QuestionType)
                    {
                        case 100001: type = "新车";
                            break;
                        case 100002: type = "二手车";
                            break;
                        case 100003: type = "汽车用品周边";
                            break;

                        case 100006: type = "DSA";
                            break;
                    }
                    questionType[0] = type;
                    questionType[1] = model.CallRecord;
                }
            }
            return questionType;
        }


        //根据经销商表主键获取类型名称 和 来电记录
        private string[] getDFeedbackQuestionType(string recID)
        {
            string[] questionType = new string[2];
            int _recID;
            if (int.TryParse(recID, out _recID))
            {
                ConsultDFeedback model = new ConsultDFeedback();
                model = BLL.ConsultDFeedback.Instance.GetConsultDFeedback(_recID);
                if (model != null)
                {
                    string type = string.Empty;
                    switch (model.QuestionType)
                    {
                        case 100004: type = "咨询";
                            break;
                        case 100005: type = "投诉";
                            break;
                    }
                    questionType[0] = type;
                    questionType[1] = model.CallRecord;
                }
            }
            return questionType;
        }

        //根据经销商表主键获取类型名称 和 来电记录
        private string[] getDOtherQuestionType(string recID)
        {
            string[] questionType = new string[2];
            int _recID;
            if (int.TryParse(recID, out _recID))
            {
                ConsultDOther model = new ConsultDOther();
                model = BLL.ConsultDOther.Instance.GetConsultDOther(_recID);
                if (model != null)
                {
                    questionType[0] = "";
                    questionType[1] = model.CallRecord;
                }
            }
            return questionType;
        }
        //操作    consultID：咨询类型
        public string getOperator(string status, string callRecordID, string taskID, string ReceiverID, string CustID, string BussinessType, string BGID, string SCID)
        {
            string operStr = string.Empty;
            Int64 _callRecordID;
            if (Int64.TryParse(callRecordID, out _callRecordID))
            {
                //获取现表中的数据
                CallRecordInfo model = BLL.CallRecordInfo.Instance.GetCallRecordInfo(_callRecordID);
                if (model != null)
                {
                    operStr += "<a href='javascript:void(0);' onclick='javascript:ADTTool.PlayRecord(\"" + model.AudioURL + "\");' title='播放录音' ><img src='../../Images/callTel.png' /></a>";
                }
            }
            if (BussinessType == "1")
            {
                int _status;
                if (int.TryParse(status, out _status))
                {
                    //取查看页面

                    string viewpage = "<a target='_blank' href='/WorkOrder/WorkOrderView.aspx?OrderID=" + taskID + "' class='linkBlue'>查看</a>";
                    switch (_status)
                    {
                        //审批
                        case (Int32)Entities.WorkOrderStatus.Pending:
                            //具有审核功能权限
                            if (canPend)
                            {
                                operStr += "<a target='_blank' href='/WorkOrder/CCProcess.aspx?OrderID=" + taskID + "' class='linkBlue'>审核</a>";
                            }
                            else
                            {
                                operStr += viewpage;
                            }
                            break;
                        //处理
                        case (Int32)Entities.WorkOrderStatus.Untreated:
                        case (Int32)Entities.WorkOrderStatus.Processing:
                            //具有处理功能权限
                            if (canHandler)
                            {
                                operStr += "<a target='_blank' href='/WorkOrder/CCProcess.aspx?OrderID=" + taskID + "' class='linkBlue'>处理</a>";
                            }
                            else if (ReceiverID == BLL.Util.GetLoginUserID().ToString())
                            {
                                operStr += "<a target='_blank' href='/WorkOrder/CCProcess.aspx?OrderID=" + taskID + "' class='linkBlue'>处理</a>";
                            }
                            else
                            {
                                operStr += viewpage;
                            }
                            break;
                        case (Int32)Entities.WorkOrderStatus.Closed:
                        case (Int32)Entities.WorkOrderStatus.Completed:
                        case (Int32)Entities.WorkOrderStatus.Processed:
                            operStr += viewpage;
                            break;
                    }
                }
            }
            else if (BussinessType == "2")
            {
                operStr += "<a target='_blank' href='/GroupOrder/GroupOrderView.aspx?TaskID=" + taskID + "' class='linkBlue'>查看</a>";
            }
            else if (BussinessType == "3")
            {
                operStr += "<a target='_blank' href='/CRMStopCust/Edit.aspx?TaskID=" + taskID + "' class='linkBlue'>查看</a>";
            }
            else if (BussinessType == "4")
            {
                operStr += "<a target='_blank' href='/OtherTask/OtherTaskDealView.aspx?OtherTaskID=" + taskID + "' class='linkBlue'>查看</a>";
            }

            else
            {
                string url = "";
                url = BLL.CallRecord_ORIG_Business.Instance.GetTaskUrl(BGID, SCID, "", "");
                //如果是惠买车业务
                if (BLL.Util.isHuiMaiCHE(BGID, SCID))
                {
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a href=\"javascript:void(0)\" urlstr='" + url + "' onclick=\"GoToEpURL(this,'" + YPFanXianHBuyCarURL + "','" + EPEmbedCCHBuyCar_APPID + "')\" > 查看</a>";
                    }
                }
                else if (BLL.Util.isEasySetOff(BGID, SCID))
                {
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a href=\"javascript:void(0)\" urlstr='" + url + "' onclick=\"var obj = new Object();obj.businessType = 'jingzhunguanggao';obj.GoToEPURL='" + url + "';OtherBusinessLogin(obj);\" >查看</a>";
                    }
                }
                else if (BLL.Util.isCarFinancial(BGID, SCID))
                {
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a  href=\"javascript:void(0)\" onclick=\"var obj = new Object();obj.businessType = 'yichechedai';obj.callbackurl='" + url + "';OtherBusinessLogin(obj);\">查看</a>";
                    }
                }
                else
                {
                    url = BLL.CallRecord_ORIG_Business.Instance.GetTaskUrl(BGID, SCID, "", "");
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a target='_blank' href='" + url + "' class='linkBlue'>查看</a>";
                    }
                }
            }
            return operStr;
        }
        /// <summary>
        /// 取工单状态
        /// </summary>
        /// <param name="workorderstatus"></param>
        /// <returns></returns>
        public string GetStatusText(string workorderstatus, string stopstatus, string bussinessType, string ApplyType)
        {
            if (bussinessType == "1")
            {
                if (!string.IsNullOrEmpty(workorderstatus))
                {
                    //return BitAuto.ISDC.CC2012.BLL.Util.GetEnumOptText(typeof(BitAuto.ISDC.CC2012.Entities.WorkOrderStatus), Convert.ToInt32(Eval("WorkOrderStatus").ToString()));
                    return BitAuto.ISDC.CC2012.BLL.Util.GetEnumOptText(typeof(BitAuto.ISDC.CC2012.Entities.WorkOrderStatus), Convert.ToInt32(workorderstatus));
                }
                else
                {
                    return "";
                }
            }
            else if (bussinessType == "2")
            {
                if (!string.IsNullOrEmpty(workorderstatus))
                {
                    //return BitAuto.ISDC.CC2012.BLL.Util.GetEnumOptText(typeof(BitAuto.ISDC.CC2012.Entities.GroupTaskStatus), Convert.ToInt32(Eval("WorkOrderStatus").ToString()));
                    return BitAuto.ISDC.CC2012.BLL.Util.GetEnumOptText(typeof(BitAuto.ISDC.CC2012.Entities.GroupTaskStatus), Convert.ToInt32(workorderstatus));
                }
                else
                {
                    return "";
                }
            }
            else if (bussinessType == "3")//客户核实
            {
                if (!string.IsNullOrEmpty(workorderstatus) && !string.IsNullOrEmpty(stopstatus) && !string.IsNullOrEmpty(ApplyType))
                {
                    return GetStatusNameForCRMStop(stopstatus, workorderstatus, ApplyType);
                }
                else
                {
                    return "";
                }
            }
            else if (bussinessType == "4")
            {
                if (!string.IsNullOrEmpty(workorderstatus))
                {
                    //return BitAuto.ISDC.CC2012.BLL.Util.GetEnumOptText(typeof(BitAuto.ISDC.CC2012.Entities.OtheTaskStatus), Convert.ToInt32(Eval("WorkOrderStatus").ToString()));
                    return BitAuto.ISDC.CC2012.BLL.Util.GetEnumOptText(typeof(BitAuto.ISDC.CC2012.Entities.OtheTaskStatus), Convert.ToInt32(workorderstatus));
                }
                else
                {
                    return "";
                }
            }
            else if (bussinessType == "5")
            {
                return "";
            }
            else
            {
                return "已处理";
            }
        }

        #region 取客户核实任务状态描述
        public string GetStatusNameForCRMStop(string stopstatus, string taskStatus, string ApplyType)
        {
            string result = string.Empty;

            int _status;
            if (int.TryParse(stopstatus, out _status))
            {
                result = BLL.Util.GetEnumOptText(typeof(Entities.StopCustStopStatus), _status);


                if (_status == 2 && ApplyType == "2")
                {
                    result = "待启用";
                }
                else if (_status == 3 && ApplyType == "2")
                {
                    result = "已启用";
                }
                else if (_status == 5 || _status == 6)
                {
                    result = "已驳回";
                }
                else
                {

                    if (_status == 1 && taskStatus == "1")
                    {
                        result = "未分配";
                    }
                    else if (_status == 1 && taskStatus == "2")
                    {
                        result = "待处理";
                    }
                    else if (_status == 1 && taskStatus == "3")
                    {
                        result = "处理中";
                    }
                }
            }

            return result;
        }
        #endregion

        public string GetCategoryFullName(string CategoryID, string bussinessType, string BGID, string SCID)
        {
            //工单分类
            if (bussinessType == "1")
            {
                return BitAuto.ISDC.CC2012.BLL.WorkOrderCategory.Instance.GetCategoryFullName(Eval("CategoryID").ToString());
            }
            //团购订单
            else if (bussinessType == "2")
            {
                return "团购订单";
            }
            //客户核实
            else if (bussinessType == "3")
            {
                return "客户核实";
            }
            //其他任务
            else if (bussinessType == "4")
            {
                return "其他任务";
            }
            else
            {
                int _scid;
                int.TryParse(SCID, out _scid);
                Entities.SurveyCategory model = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSurveyCategory(_scid);
                if (model != null)
                {
                    return model.Name;
                }
                else
                {
                    return "";
                }
            }
        }

        #region 取外呼失败最后通话时间
        public string GetBeginTime(string TaskID, string CustID)
        {
            //当录音ID CallRecordID=-2，根据个人用户电话、任务ID去话务总表找最近一条外呼记录
            tableEndName = "";//只查询现在表数据
            return BLL.CallRecord_ORIG.Instance.GetBeginTime(TaskID, CustID, tableEndName);
        }
        #endregion

        public string GetRecordType(string recordtype)
        {
            string retval = "";
            switch (recordtype)
            {
                case "1":
                    retval = "呼入";
                    break;
                case "2":
                    retval = "呼出";
                    break;
                case "3":
                    retval = "IM";
                    break;
                default:
                    break;
            }

            return retval;
        }
    }
}