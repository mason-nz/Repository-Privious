﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.ISDC.CC2012.Entities;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.TaskManager
{
    public partial class CallRecordORIG : PageBase
    {
        #region 属性
        private string RequestCustID
        {
            get { return HttpContext.Current.Request["CustID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["CustID"].ToString()); }
        }
        #endregion

        public int PageSize = BLL.PageCommon.Instance.PageSize = 10;
        public int GroupLength = 8;
        public int RecordCount;

        public string YPFanXianHBuyCarURL = System.Configuration.ConfigurationManager.AppSettings["EPEmbedCCHBugCar_URL"].ToString();//惠买车URL
        public string EPEmbedCCHBuyCar_APPID = System.Configuration.ConfigurationManager.AppSettings["EPEmbedCCHBuyCar_APPID"];//易湃签入CC页面，惠买车APPID
        private Random R = new Random();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //判断登录
                BindData();
            }
        }

        private void BindData()
        {
            if (RequestCustID != "")
            {
                string where = " AND chi.CustID='" + RequestCustID + "' ";

                string tableEndName = "";//只查询现在表数据
                DataTable dt = BLL.CallRecord_ORIG.Instance.GetCallRecordORIGForWork(where, "(CASE WHEN cri.EstablishedTime IS NULL THEN cri.CreateTime ELSE cr.BeginTime END) DESC",
                    BLL.PageCommon.Instance.PageIndex, PageSize, tableEndName, out RecordCount);
                repeaterTableList.DataSource = dt;
                repeaterTableList.DataBind();

                litPagerDown.Text = BLL.PageCommon.Instance.LinkStringByPost(BLL.Util.GetUrl(), GroupLength, RecordCount, PageSize, BLL.PageCommon.Instance.PageIndex, 2);
            }
        }

        /// <summary>
        /// 根据操作人ID得到权限系统中操作人名称
        /// </summary>
        /// <param name="eid"></param>
        /// <returns></returns>
        public string getEmployName(string eid)
        {
            string name = string.Empty;
            int id;
            if (int.TryParse(eid, out id))
            {
                name = BitAuto.YanFa.SysRightManager.Common.UserInfo.GerTrueName(id);
            }
            return name;
        }

        public string getOperator(string callRecordID, string taskID, string BussinessType, string BGID, string SCID)
        {
            string operStr = string.Empty;
            Int64 _callRecordID;
            if (Int64.TryParse(callRecordID, out _callRecordID))
            {
                //只获取现表数据
                CallRecordInfo model = BLL.CallRecordInfo.Instance.GetCallRecordInfo(_callRecordID);
                if (model != null)
                {
                    operStr += "<a href='javascript:void(0);' onclick='javascript:ADTTool.PlayRecord(\"" + model.AudioURL + "\");' title='播放录音' ><img src='../../Images/callTel.png' /></a>";
                }
            }
            if (BussinessType == "1")
            {
                operStr += "<a target='_blank' href='/WorkOrder/WorkOrderView.aspx?OrderID=" + taskID + "' class='linkBlue'>查看</a>";
            }
            else if (BussinessType == "2")
            {
                operStr += "<a target='_blank' href='/GroupOrder/GroupOrderView.aspx?TaskID=" + taskID + "' class='linkBlue'>查看</a>";
            }
            else if (BussinessType == "3")
            {
                operStr += "<a target='_blank' href='/CRMStopCust/Edit.aspx?TaskID=" + taskID + "' class='linkBlue'>查看</a>";
            }
            else if (BussinessType == "4")
            {
                operStr += "<a target='_blank' href='/OtherTask/OtherTaskDealView.aspx?OtherTaskID=" + taskID + "' class='linkBlue'>查看</a>";
            }
            //add by qizq 2014-5-5 惠买车业务
            else
            {
                string url = "";
                url = BLL.CallRecord_ORIG_Business.Instance.GetTaskUrl(BGID, SCID, "", "");
                //如果是惠买车业务
                if (BLL.Util.isHuiMaiCHE(BGID, SCID))
                {
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a href=\"javascript:void(0)\" urlstr='" + url + "' onclick=\"GoToEpURL(this,'" + YPFanXianHBuyCarURL + "','" + EPEmbedCCHBuyCar_APPID + "')\" > 查看</a>";
                    }
                }
                else if (BLL.Util.isEasySetOff(BGID, SCID))
                {
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a href=\"javascript:void(0)\" urlstr='" + url + "' onclick=\"var obj = new Object();obj.businessType = 'jingzhunguanggao';obj.GoToEPURL='" + url + "';OtherBusinessLogin(obj);\" >查看</a>";
                    }
                }
                else if (BLL.Util.isCarFinancial(BGID, SCID))
                {
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a  href=\"javascript:void(0)\" onclick=\"var obj = new Object();obj.businessType = 'yichechedai';obj.callbackurl='" + url + "';OtherBusinessLogin(obj);\">查看</a>";
                    }
                }
                else
                {
                    url = BLL.CallRecord_ORIG_Business.Instance.GetTaskUrl(BGID, SCID, "", "");
                    if (!string.IsNullOrEmpty(url))
                    {
                        url += "&r={1}";
                        url = String.Format(url, taskID, R.Next(100000));
                        operStr += "<a target='_blank' href='" + url + "' class='linkBlue'>查看</a>";
                    }
                }


            }
            return operStr;
        }
    }
}