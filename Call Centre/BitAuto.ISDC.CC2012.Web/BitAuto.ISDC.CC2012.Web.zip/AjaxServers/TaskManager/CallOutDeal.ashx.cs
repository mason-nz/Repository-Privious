﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using BitAuto.ISDC.CC2012.BLL;
using BitAuto.ISDC.CC2012.WebService;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.TaskManager
{
    /// <summary>
    /// CallOutDeal 的摘要说明
    /// </summary>
    public class CallOutDeal : IHttpHandler, IRequiresSessionState
    {
        #region Query Properties
        public HttpRequest Request
        {
            get { return HttpContext.Current.Request; }
        }
        /// <summary>
        /// 操作类型
        /// </summary>
        public string Action { get { return (Request["Action"] + "").Trim().ToLower(); } }

        private string userChoice;
        /// <summary>
        /// 电话呼入来源
        /// </summary>
        public string UserChoice
        {
            get
            {
                if (userChoice == null)
                {
                    userChoice = HttpUtility.UrlDecode((Request["UserChoice"] + "").Trim());
                }
                return userChoice;
            }
        }

        private string callID;
        /// <summary>
        /// CTI中通话ID
        /// </summary>
        public string CallID
        {
            get
            {
                if (callID == null)
                {
                    callID = HttpUtility.UrlDecode((Request["CallID"] + "").Trim());
                }
                return callID;
            }
        }

        private string recordID;
        /// <summary>
        /// 通话流水号
        /// </summary>
        public string RecordID
        {
            get
            {
                if (recordID == null)
                {
                    recordID = HttpUtility.UrlDecode((Request["RecordID"] + "").Trim());
                }
                return recordID;
            }
        }

        private string recordIDURL;
        /// <summary>
        /// 通话URL地址
        /// </summary>
        public string RecordIDURL
        {
            get
            {
                if (recordIDURL == null)
                {
                    recordIDURL = HttpUtility.UrlDecode((Request["RecordIDURL"] + "").Trim());
                }
                return recordIDURL;
            }
        }

        private string agentState;
        /// <summary>
        /// 坐席当前状态（枚举名称:就绪3、置忙4、事后处理5）
        /// </summary>
        public string AgentState
        {
            get
            {
                if (agentState == null)
                {
                    agentState = HttpUtility.UrlDecode((Request["AgentState"] + "").Trim());
                }
                return agentState;
            }
        }

        private string agentAuxState;
        /// <summary>
        /// 坐席置忙状态原因（int类型）
        /// </summary>
        public string AgentAuxState
        {
            get
            {
                if (agentAuxState == null)
                {
                    agentAuxState = HttpUtility.UrlDecode((Request["AgentAuxState"] + "").Trim());
                }
                return agentAuxState;
            }
        }

        private string calledNum;
        /// <summary>
        /// 当前被叫号码
        /// </summary>
        public string CalledNum
        {
            get
            {
                if (calledNum == null)
                {
                    calledNum = HttpUtility.UrlDecode((Request["CalledNum"] + "").Trim());
                }
                return calledNum;
            }
        }

        private string callerNum;
        /// <summary>
        /// 当前主叫号码
        /// </summary>
        public string CallerNum
        {
            get
            {
                if (callerNum == null)
                {
                    callerNum = HttpUtility.UrlDecode((Request["CallerNum"] + "").Trim());
                }
                return callerNum;
            }
        }

        private string mediaType;
        /// <summary>
        /// 业务性质(枚举名称)
        /// </summary>
        public string MediaType
        {
            get
            {
                if (mediaType == null)
                {
                    mediaType = HttpUtility.UrlDecode((Request["MediaType"] + "").Trim());
                }
                return mediaType;
            }
        }

        private string userEvent;
        /// <summary>
        /// 当前CTI事件名称
        /// </summary>
        public string UserEvent
        {
            get
            {
                if (userEvent == null)
                {
                    userEvent = HttpUtility.UrlDecode((Request["UserEvent"] + "").Trim());
                }
                return userEvent;
            }
        }

        private string userName;
        /// <summary>
        /// 工号码
        /// </summary>
        public string UserName
        {
            get
            {
                if (userName == null)
                {
                    userName = HttpUtility.UrlDecode((Request["UserName"] + "").Trim());
                }
                return userName;
            }
        }
        private string custID;
        /// <summary>
        /// 客户ID
        /// </summary>
        public string CustID
        {
            get
            {
                if (custID == null)
                {
                    custID = HttpUtility.UrlDecode((Request["CustID"] + "").Trim());
                }
                return custID;
            }
        }
        private string custname;
        /// <summary>
        /// 客户名称
        /// </summary>
        public string CustName
        {
            get
            {
                if (custname == null)
                {
                    custname = HttpUtility.UrlDecode((Request["CustName"] + "").Trim());
                }
                return custname;
            }
        }
        private string contact;
        /// <summary>
        /// 联系人
        /// </summary>
        public string Contact
        {
            get
            {
                if (contact == null)
                {
                    contact = HttpUtility.UrlDecode((Request["Contact"] + "").Trim());
                }
                return contact;
            }
        }
        private string taskid;
        /// <summary>
        /// 任务ID
        /// </summary>
        public string TaskID
        {
            get
            {
                if (taskid == null)
                {
                    taskid = HttpUtility.UrlDecode((Request["TaskID"] + "").Trim());
                }
                return taskid;
            }
        }
        private string callrecordID;
        public string CallRecordID
        {
            get
            {
                if (callrecordID == null)
                {
                    callrecordID = HttpUtility.UrlDecode((Request["CallRecordID"] + "").Trim());
                }
                return callrecordID;
            }
        }
        //是否提交过
        private string issub;
        public string IsSub
        {
            get
            {
                if (issub == null)
                {
                    issub = HttpUtility.UrlDecode((Request["IsSub"] + "").Trim());
                }
                return issub;
            }
        }
        //NetworkRTimeSpan: escape($('#hidTimeSpan').val()),
        //       EstablishTimeSpan: escape(timespan)

        //电话播出到坐席接起的时间
        private string networkrtimespan;
        public string NetworkRTimeSpan
        {
            get
            {
                if (networkrtimespan == null)
                {
                    networkrtimespan = HttpUtility.UrlDecode((Request["NetworkRTimeSpan"] + "").Trim());
                }
                return networkrtimespan;
            }
        }
        //客户响铃时长
        private string establishtimespan;
        public string EstablishTimeSpan
        {
            get
            {
                if (establishtimespan == null)
                {
                    establishtimespan = HttpUtility.UrlDecode((Request["EstablishTimeSpan"] + "").Trim());
                }
                return establishtimespan;
            }
        }
        /// <summary>
        /// 接通开始时间
        /// </summary>
        public string RequestEstablishBeginTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishBeginTime").ToString().Trim();
            }
        }
        /// <summary>
        /// 接通结束时间
        /// </summary>
        public string RequestEstablishEndTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishEndTime").ToString().Trim();
            }
        }
        #endregion

        public void ProcessRequest(HttpContext context)
        {
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();
            string msg = string.Empty;
            context.Response.ContentType = "text/plain";
            try
            {
                switch (Action)
                {
                    case "insertcallrecordorigbusiness"://呼出初始化，插入中间表表记录
                        Loger.Log4Net.Info("[AjaxServers\\TaskManager\\CallOutDeal.ashx]insertcallrecordorigbusiness begin...");
                        try
                        {
                            InsertCallRecord_ORIG_Business(out msg);
                        }
                        catch (Exception ex)
                        {
                            msg = ex.Message;
                            Loger.Log4Net.Info("[AjaxServers\\TaskManager\\CallOutDeal.ashx]insertcallrecordorigbusiness errorMessage...is:" + ex.Message);
                            Loger.Log4Net.Info("[AjaxServers\\TaskManager\\CallOutDeal.ashx]insertcallrecordorigbusiness errorSource...is:" + ex.Source);
                            Loger.Log4Net.Info("[AjaxServers\\TaskManager\\CallOutDeal.ashx]insertcallrecordorigbusiness errorStackTrace...is:" + ex.StackTrace);
                        }
                        break;
                    case "established"://呼出接通
                        Established(out msg);
                        break;
                    case "released"://挂断
                        Released(out msg);
                        break;
                    case "ringing"://振铃
                        break;

                    default:
                        msg = "{'success':'no','recordid':'请求参数错误！'}";
                        break;
                }
            }
            catch (Exception ex)
            {
                msg = ex.Message;
            }
            context.Response.Write(msg);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }




        /// <summary>
        /// 电话呼出挂断
        /// </summary>
        /// <param name="msg"></param>
        private void Released(out string msg)
        {
            msg = string.Empty;
            string HistoryLogID = "";
            int RecID = 0;
            //录音表主键格式正确
            //modify by qizq 2014-6-11 修改挂断时通过 CallID,不通过录音的SessionID
            //if (!string.IsNullOrEmpty(RecordID))
            long _callid;
            if (!string.IsNullOrEmpty(CallID) && long.TryParse(CallID, out _callid))
            {
                //取本地录音记录
                Entities.CallRecordInfo model = BLL.CallRecordInfo.Instance.GetCallRecordInfoByCallID(_callid);
                //Entities.CallRecordInfo model = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(RecordID);
                if (model != null && model.RecID > 0)
                {
                    //给录音结束时间付值
                    //model.EndTime = System.DateTime.Now;
                    //System.DateTime begintime = new DateTime();
                    ////如果录音开始时间为合法时间
                    //if (model.BeginTime != null && model.BeginTime != BitAuto.ISDC.CC2012.Entities.Constants.Constant.DATE_INVALID_VALUE)
                    //{
                    //    if (DateTime.TryParse(model.BeginTime.ToString(), out begintime))
                    //    {
                    //        //取录音结束时间与开始时间直接的通话时长描述
                    //        TimeSpan s = System.DateTime.Now - begintime;
                    //        model.TallTime = Convert.ToInt32(s.TotalSeconds);
                    //    }
                    //}

                    DateTime endTime = DateTime.Now;
                    model.TallTime = 0;
                    if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
                    {
                        if (model.BeginTime != null && model.BeginTime != BitAuto.ISDC.CC2012.Entities.Constants.Constant.DATE_INVALID_VALUE)
                        {
                            TimeSpan tsSpan = (TimeSpan)(endTime - model.BeginTime);
                            model.TallTime = (int)tsSpan.TotalSeconds;
                        }
                    }
                    model.EndTime = endTime;
                    //add by qizq 2014-6-11更新录音sessionId和录音地址
                    model.SessionID = RecordID;
                    model.AudioURL = RecordIDURL;

                    int result = 0;
                    result = BLL.CallRecordInfo.Instance.Update(model);
                    //更新录音结束时间成功
                    if (result > 0)
                    {
                        //调用接口更新宇高数据

                        //CustHistoryLog 作废 2016-3-1 强斐
                        //没有提交过，插入CustHistoryLog
                        //if (IsSub != "1")
                        //{
                        //    Entities.CustHistoryLog logmodel = new Entities.CustHistoryLog();
                        //    logmodel.TaskID = TaskID;
                        //    logmodel.Action = (int)Entities.Action.ActionCallOut;
                        //    logmodel.CallRecordID = model.RecID;
                        //    logmodel.SolveTime = System.DateTime.Now;
                        //    logmodel.SolveUserID = BLL.Util.GetLoginUserID();
                        //    logmodel.SolveUserEID = BLL.Util.GetHrEIDByLimitEID(BLL.Util.GetLoginUserID());
                        //    HistoryLogID = BLL.CustHistoryLog.Instance.Insert(logmodel).ToString();
                        //}
                    }
                }
            }
            //返回处理记录主键
            msg = "{'success':'yes','recordid':'" + HistoryLogID + "'}";
        }
        //插入话务总表跟业务分组中间表记录
        public void InsertCallRecord_ORIG_Business(out string msg)
        {
            msg = string.Empty;
            Entities.CallRecord_ORIG_Business callrecordorgbusiness = new Entities.CallRecord_ORIG_Business();

            callrecordorgbusiness.CreateUserID = BLL.Util.GetLoginUserID();

            //增加业务组和分类，个人用户

            callrecordorgbusiness.BGID = 9;
            callrecordorgbusiness.SCID = 89;

            //西门子callid
            Int64 _callID = 0;
            if (Int64.TryParse(CallID, out _callID))
            {
            }
            callrecordorgbusiness.CallID = _callID;
            callrecordorgbusiness.CreateTime = DateTime.Now;

            int RecID;
            //查询现在表
            if (!BLL.CallRecord_ORIG_Business.Instance.IsExistsByCallID(_callID))
            {
                RecID = BLL.CallRecord_ORIG_Business.Instance.Insert(callrecordorgbusiness);
            }
            else
            {
                RecID = BLL.CallRecord_ORIG_Business.Instance.Update(callrecordorgbusiness);
            }
            msg = "{'success':'yes','recordid':'" + RecID + "'}";
        }

        /// <summary>
        /// 电话呼出接通
        /// </summary>
        /// <param name="msg"></param>
        private void Established(out string msg)
        {
            msg = string.Empty;
            Entities.CallRecordInfo model = new Entities.CallRecordInfo();
            //通话流水号
            model.SessionID = RecordID;
            //坐席分机号
            model.ExtensionNum = UserName;

            //对方号码
            model.PhoneNum = CallerNum;
            //呼出号码
            model.ANI = CalledNum;

            //呼出
            model.CallStatus = 2;
            //录音开始时间
            model.BeginTime = System.DateTime.Now;

            DateTime beginTime = DateTime.Now;
            if (DateTime.TryParse(RequestEstablishBeginTime, out beginTime))
            {

            }
            model.BeginTime = beginTime;
            //录音地址
            model.AudioURL = RecordIDURL;
            //客户ID
            model.CustID = CustID;
            //客户名称
            model.CustName = CustName;
            model.CreateTime = System.DateTime.Now;
            model.CreateUserID = BLL.Util.GetLoginUserID();
            //联系人
            model.Contact = Contact;
            //任务ID
            model.TaskID = TaskID;

            model.TallTime = 0;

            //任务分类id
            model.TaskTypeID = (int)Entities.TaskTypeID.TaskProcess;
            //坐席振铃时长
            int AgentRingTime = 0;
            if (int.TryParse(NetworkRTimeSpan, out AgentRingTime))
            {
                model.AgentRingTime = AgentRingTime;
            }
            //客户振铃时长
            int CustomRingTime = 0;
            if (int.TryParse(EstablishTimeSpan, out CustomRingTime))
            {
                model.CustomRingTime = CustomRingTime;
            }


            //增加业务组和分类，个人用户

            model.BGID = 9;
            model.SCID = 89;

            //西门子callid
            Int64 _callID = 0;
            if (Int64.TryParse(CallID, out _callID))
            {
            }
            model.CallID = _callID;


            int RecID = BLL.CallRecordInfo.Instance.Insert(model);

            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID开始");

            //调用webservice,保存callid,业务id，业务组，分类对应关系
            //int Result = CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID(model.CallID, model.TaskID, model.BGID, model.SCID, Convert.ToInt32(model.CreateUserID), ref msg);
            int Result = BLL.CallRecord_ORIG_Business.Instance.UpdateBusinessDataByCallID(model.CallID, model.TaskID, model.BGID, model.SCID, Convert.ToInt32(model.CreateUserID), ref msg);
            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID结束返回值Result=" + Result);
            msg = "{'success':'yes','recordid':'" + RecID + "'}";
        }
    }
}