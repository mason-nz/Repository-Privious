﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.TaskManager
{
    public partial class OrderInfoListForHB : BitAuto.ISDC.CC2012.Web.Base.PageBase
    {
        public string Tel
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("tel");
            }
        }

        public string keyID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("keyid");
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}