﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using System.Data;
using BitAuto.Utils.Config;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.RecordMonitor
{
    /// <summary>
    /// SecondCarRecordBindManager 的摘要说明
    /// </summary>
    public class RecordBindManager : IHttpHandler, IRequiresSessionState
    {

        bool success = true;
        string result = "";
        string message = "";
        public HttpContext currentContext;

        #region 属性
        //add by qizhiqiang 会员类型 2012-4-20 车易通为1，车商通为2
        private string RequestMemberType
        {
            get { return BLL.Util.GetCurrentRequestFormStr("MemberType"); }
        }
        //

        private string RequestAction
        {
            get { return BLL.Util.GetCurrentRequestFormStr("Action"); }
        }
        private string RequestCustID
        {
            get { return BLL.Util.GetCurrentRequestFormStr("CustID"); }
        }
        private string RequestCC_CustID
        {
            get { return BLL.Util.GetCurrentRequestFormStr("CC_CustID"); }
        }
        private string RequestMemberID
        {
            get { return BLL.Util.GetCurrentRequestFormStr("MemberID"); }
        }
        private string RequestCC_MemberID
        {
            get { return BLL.Util.GetCurrentRequestFormStr("CC_MemberID"); }
        }
        private int RequestCRID
        {
            get { return BLL.Util.GetCurrentRequestFormInt("CRID"); }
        }
        private string RequestTID
        {
            get { return BLL.Util.GetCurrentRequestFormStr("TID"); }
        }
        /// <summary>
        /// 数据来源，1-Excel新增，2-CRM库
        /// </summary>
        private int RequestDataSource
        {
            get { return BLL.Util.GetCurrentRequestFormInt("DataSource"); }
        }
        /// <summary>
        /// 查询客户名称
        /// </summary>
        private string RequestCustName
        {
            get { return BLL.Util.GetCurrentRequestFormStr("CustName"); }
        }
        /// <summary>
        /// 录音SessionID唯一标识
        /// </summary>
        private string RequestSessionID
        {
            get { return BLL.Util.GetCurrentRequestFormStr("SessionID"); }
        }
        /// <summary>
        /// CTI中通话ID
        /// </summary>
        public string CallID
        {
            get { return BLL.Util.GetCurrentRequestFormStr("CallID"); }

        }
        /// <summary>
        /// 通话URL地址
        /// </summary>
        public string RecordIDURL
        {
            get { return BLL.Util.GetCurrentRequestFormStr("RecordIDURL"); }
        }
        /// <summary>
        /// 接通结束时间
        /// </summary>
        public string RequestEstablishEndTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishEndTime").ToString().Trim();
            }
        }
        #endregion

        public void ProcessRequest(HttpContext context)
        {
            context.Response.ContentType = "text/plain";
            //context.Response.Write("Hello World");
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();
            string msg = string.Empty;

            if (RequestAction.ToLower() == "bindrecord")//会员绑定录音
            {
                BindRecord(out msg);
            }
            else if (RequestAction.ToLower() == "searchcust")//查询客户下会员信息
            {
                SearchCust(RequestCustName, RequestDataSource, RequestTID, out msg);
            }
            else if (RequestAction.ToLower() == "autobindrecord")//录音自动绑定会员
            {
                AutoBindRecord(RequestSessionID, RequestDataSource, RequestTID, out msg);
            }
            else if (RequestAction.ToLower() == "returnvistbindcord")
            {
                ReturnVistBindCord(RequestSessionID);
            }

            context.Response.Write("{" + msg + "}");
            context.Response.End();
        }
        /// <summary>
        /// 回访录音更新信息
        /// </summary>
        /// <param name="sessionID"></param>
        public void ReturnVistBindCord(string sessionID)
        {
            long _callid;
            long.TryParse(CallID, out _callid);
            Entities.CallRecordInfo record = BLL.CallRecordInfo.Instance.GetCallRecordInfoByCallID(_callid);
            //Entities.CallRecordInfo record = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(sessionID);
            if (record == null)
            {
            }
            else
            {

                ////给录音结束时间付值
                //record.EndTime = System.DateTime.Now;
                //System.DateTime begintime = new DateTime();
                ////如果录音开始时间为合法时间
                //if (record.BeginTime != null && record.BeginTime != BitAuto.ISDC.CC2012.Entities.Constants.Constant.DATE_INVALID_VALUE)
                //{
                //    if (DateTime.TryParse(record.BeginTime.ToString(), out begintime))
                //    {
                //        //取录音结束时间与开始时间直接的通话时长描述
                //        TimeSpan s = System.DateTime.Now - begintime;
                //        record.TallTime = Convert.ToInt32(s.TotalSeconds);
                //    }
                //}
                DateTime endTime = DateTime.Now;
                record.TallTime = 0;
                if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
                {
                    if (record.BeginTime != null && record.BeginTime != BitAuto.ISDC.CC2012.Entities.Constants.Constant.DATE_INVALID_VALUE)
                    {
                        TimeSpan tsSpan = (TimeSpan)(endTime - record.BeginTime);
                        record.TallTime = (int)tsSpan.TotalSeconds;
                    }
                }
                record.EndTime = endTime;
                //回访标识
                record.TaskTypeID = 4;
                //先更新下结束时间
                record.SessionID = sessionID;
                record.AudioURL = RecordIDURL;


                BLL.CallRecordInfo.Instance.Update(record);
            }
        }

        //录音自动绑定会员
        private void AutoBindRecord(string sessionID, int dataSource, string tid, out string msg)
        {
            msg = "AutoBindRecord:'no'";
            Entities.CallRecordInfo record = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(sessionID);
            if (record == null)
            {
                msg = "AutoBindRecord:'NotExistRecord'";
            }
            else
            {

                DateTime endTime = DateTime.Now;
                record.TallTime = 0;
                if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
                {
                    if (record.BeginTime != null && record.BeginTime != BitAuto.ISDC.CC2012.Entities.Constants.Constant.DATE_INVALID_VALUE)
                    {
                        TimeSpan tsSpan = (TimeSpan)(endTime - record.BeginTime);
                        record.TallTime = (int)tsSpan.TotalSeconds;
                    }
                }
                record.EndTime = endTime;
                //先更新下结束时间
                BLL.CallRecordInfo.Instance.Update(record);


                List<Entities.ProjectTask_DMSMember> dmsList = BLL.ProjectTask_DMSMember.Instance.GetProjectTask_DMSMemberByTID(tid);
                List<Entities.ProjectTask_CSTMember> dmsListcst = BLL.ProjectTask_CSTMember.Instance.GetProjectTask_CSTMemberByTID(tid);
                if (dmsList != null)
                {
                    if (dmsList.Count == 1 && (dmsListcst == null || (dmsListcst != null && dmsListcst.Count == 0)))//一个任务下，只有一个会员信息
                    {

                        record.CCCustID = null;
                        record.CustID = null;
                        record.DMSMemberID = null;
                        record.CCMemberID = null;
                        record.CC_CSTMemberID = null;
                        record.CSTMemberID = null;

                        Entities.ProjectTaskInfo taskModel = BLL.ProjectTaskInfo.Instance.GetProjectTaskInfo(tid);
                        if (taskModel != null)
                        {
                            string content = string.Empty;
                            if (dataSource == 1)//Excel新增
                            {
                                record.CCCustID = taskModel.RelationID;
                                record.CCMemberID = dmsList[0].MemberID.ToString();
                                record.CustID = null;
                                record.DMSMemberID = null;
                                content = string.Format("绑定录音ID:{2}与客户ID:{0}下,CC系统会员ID:{1}的记录成功。", record.CCCustID, record.CCMemberID, record.RecID);
                            }
                            else if (dataSource == 2)//CRM系统
                            {
                                record.CCCustID = null;
                                if (string.IsNullOrEmpty(dmsList[0].OriginalDMSMemberID))
                                {
                                    record.CCMemberID = dmsList[0].MemberID.ToString();
                                }
                                else
                                {
                                    record.CCMemberID = null;
                                    record.DMSMemberID = dmsList[0].OriginalDMSMemberID;
                                }
                                record.CustID = taskModel.RelationID;
                                content = string.Format("绑定录音ID:{2}与客户ID:{0}下,CRM系统会员ID:{1},的记录成功。", record.CustID, record.DMSMemberID, record.RecID);
                            }
                            if (BLL.CallRecordInfo.Instance.Update(record) > 0)
                            {
                                BitAuto.YanFa.SysRightManager.Common.LogInfo.Instance.InsertLog(ConfigurationUtil.GetAppSettingValue("BindRecordLogModuleID"), (int)BitAuto.YanFa.SysRightManager.Common.LogInfo.ActionType.Update, content);
                                msg = "AutoBindRecord:'yes'";
                                return;
                            }
                        }
                    }
                    else
                    {
                        msg = "AutoBindRecord:'ExistMoreMember'";
                    }
                }



                if (dmsListcst != null)
                {
                    if (dmsListcst.Count == 1 && (dmsList == null || (dmsList != null && dmsList.Count == 0)))//一个任务下，只有一个会员信息
                    {
                        record.CCCustID = null;
                        record.CustID = null;
                        record.DMSMemberID = null;
                        record.CCMemberID = null;
                        record.CC_CSTMemberID = null;
                        record.CSTMemberID = null;
                        Entities.ProjectTaskInfo taskModel = BLL.ProjectTaskInfo.Instance.GetProjectTaskInfo(tid);
                        if (taskModel != null)
                        {
                            string content = string.Empty;
                            if (dataSource == 1)//Excel新增
                            {
                                record.CCCustID = taskModel.RelationID;
                                record.CC_CSTMemberID = dmsListcst[0].ID.ToString();
                                record.CustID = null;
                                record.CSTMemberID = null;
                                content = string.Format("绑定录音ID:{2}与客户ID:{0}下,CC系统车商通会员ID:{1}的记录成功。", record.CCCustID, record.CC_CSTMemberID, record.RecID);
                            }
                            else if (dataSource == 2)//CRM系统
                            {
                                record.CCCustID = null;
                                if (string.IsNullOrEmpty(dmsListcst[0].OriginalCSTRecID))
                                {
                                    record.CC_CSTMemberID = dmsListcst[0].ID.ToString();
                                }
                                else
                                {
                                    record.CC_CSTMemberID = null;
                                    record.CSTMemberID = dmsListcst[0].OriginalCSTRecID;
                                }
                                record.CustID = taskModel.RelationID;
                                content = string.Format("绑定录音ID:{2}与客户ID:{0}下,CRM系统车商通会员ID:{1},的记录成功。", record.CustID, record.CSTMemberID, record.RecID);
                            }
                            if (BLL.CallRecordInfo.Instance.Update(record) > 0)
                            {
                                BitAuto.YanFa.SysRightManager.Common.LogInfo.Instance.InsertLog(ConfigurationUtil.GetAppSettingValue("BindRecordLogModuleID"), (int)BitAuto.YanFa.SysRightManager.Common.LogInfo.ActionType.Update, content);
                                msg = "AutoBindRecord:'yes'";
                            }
                        }
                    }
                    else
                    {
                        msg = "AutoBindRecord:'ExistMoreMember'";
                    }
                }
            }
        }

        private void SearchCust(string custName, int dataSource, string tid, out string msg)
        {
            msg = "Search:'no'";
            if (dataSource == 1)//Excel新增
            {
                msg = GenMemberInfo(custName, msg);
                if (msg != "Search:'NotExistMember'")
                {

                }
                else if (msg == "Search:'no'" || msg == "Search:'NotExistByCustName'")
                {
                    //DataTable dtCust = BLL.CC_ExcelInfo.Instance.GetCC_ExcelInfoByCustName(custName);
                    DataTable dtCust = BLL.ProjectTask_Cust.Instance.GetProjectTask_CustByExcelCustName(custName);
                    if (dtCust == null || dtCust.Rows.Count <= 0)
                    {
                        msg = "Search:'NotExistByCustName'";
                    }
                    else if (dtCust != null && dtCust.Rows.Count > 1)
                    {
                        msg = "Search:'ExistMoreCust'";
                    }
                    else
                    {
                        List<Entities.ProjectTask_DMSMember> memberlist = BLL.ProjectTask_DMSMember.Instance.GetProjectTask_DMSMemberByTID(dtCust.Rows[0]["PTID"].ToString());

                        List<Entities.ProjectTask_CSTMember> cstmemberlist = BLL.ProjectTask_CSTMember.Instance.GetProjectTask_CSTMemberByTID(dtCust.Rows[0]["PTID"].ToString());

                        if ((memberlist != null && memberlist.Count > 0) || (cstmemberlist != null && cstmemberlist.Count > 0))
                        {
                            Entities.ProjectTaskInfo task = BLL.ProjectTaskInfo.Instance.GetProjectTaskInfo(dtCust.Rows[0]["PTID"].ToString());
                            msg = "Search:'yes',DataSource:'1',CustID:'" + (task != null ? task.RelationID : "") + "'";
                            msg += ",member:[";
                            string temp = string.Empty;
                            for (int i = 0; i < memberlist.Count; i++)
                            {
                                if (i == 0)
                                {
                                }
                                string membercode = string.Empty;
                                if (!string.IsNullOrEmpty(memberlist[i].OriginalDMSMemberID))
                                {
                                    BitAuto.YanFa.Crm2009.Entities.DMSMember memberModel = BitAuto.YanFa.Crm2009.BLL.DMSMember.Instance.GetDMSMember(new Guid(memberlist[i].OriginalDMSMemberID));
                                    if (memberModel != null)
                                    {
                                        membercode = memberModel.MemberCode;
                                    }
                                }
                                temp += "{id:'" + (string.IsNullOrEmpty(memberlist[i].OriginalDMSMemberID) ? memberlist[i].MemberID.ToString() : memberlist[i].OriginalDMSMemberID)
                                        + "|" + membercode + "|1" + "',name:'" + BLL.Util.EscapeString(memberlist[i].Name) + "'},";

                            }
                            for (int i = 0; i < cstmemberlist.Count; i++)
                            {
                                if (i == 0)
                                {
                                }
                                string membercode = string.Empty;
                                if (!string.IsNullOrEmpty(cstmemberlist[i].OriginalCSTRecID) && cstmemberlist[i].OriginalCSTRecID.Length > 0)
                                {
                                    BitAuto.YanFa.Crm2009.Entities.CstMember cstmemberModel = BitAuto.YanFa.Crm2009.BLL.CstMember.Instance.GetCstMemberModel(cstmemberlist[i].OriginalCSTRecID);
                                    if (cstmemberModel != null)
                                    {
                                        if (cstmemberModel.CstMemberID.ToString() != "0" && cstmemberModel.CstMemberID.ToString() != "-2")
                                        {
                                            membercode = cstmemberModel.CstMemberID.ToString();
                                        }
                                    }
                                }
                                temp += "{id:'" + (string.IsNullOrEmpty(cstmemberlist[i].OriginalCSTRecID) ? cstmemberlist[i].ID.ToString() : cstmemberlist[i].OriginalCSTRecID)
                                        + "|" + membercode + "|2" + "',name:'" + BLL.Util.EscapeString(cstmemberlist[i].FullName) + "'},";
                            }

                            msg += temp;
                            msg = (msg.TrimEnd(',') + "]");

                        }
                        else
                        {
                            msg = "Search:'NotExistMember'";
                        }
                    }
                }
            }
            else if (dataSource == 2)//CRM系统
            {
                msg = GenMemberInfo(custName, msg);
            }
        }

        private static string GenMemberInfo(string custName, string msg)
        {
            BitAuto.YanFa.Crm2009.Entities.QueryCustInfo queryCust = new BitAuto.YanFa.Crm2009.Entities.QueryCustInfo();
            queryCust.ExistCustName = custName;
            //queryCust.Status = 0;
            int custCount = 0;
            DataTable dt = BitAuto.YanFa.Crm2009.BLL.CustInfo.Instance.GetCustInfo(queryCust, string.Empty, 1, 1, out custCount);
            if (custCount == 0)
            {
                msg = "Search:'NotExistByCustName'";
            }
            else
            {
                string custid = dt.Rows[0]["CustID"].ToString();
                List<BitAuto.YanFa.Crm2009.Entities.DMSMember> memberlist = BitAuto.YanFa.Crm2009.BLL.DMSMember.Instance.GetDMSMember(custid);
                DataTable dtt = null;
                dtt = BLL.CRMCSTMember.Instance.SelectByCustID(custid);
                if ((memberlist != null && memberlist.Count > 0) || (dtt != null && dtt.Rows.Count > 0))
                {
                    msg = "Search:'yes',DataSource:'2',CustID:'" + custid + "'";
                    msg += ",member:[";
                    string temp = string.Empty;
                    for (int i = 0; i < memberlist.Count; i++)
                    {
                        if (i == 0)
                        {

                        }
                        temp += "{id:'" + memberlist[i].ID + "|" + memberlist[i].MemberCode + "|1" + "',name:'" + BLL.Util.EscapeString(memberlist[i].Name) + "'},";
                    }
                    for (int i = 0; i < dtt.Rows.Count; i++)
                    {
                        if (i == 0)
                        {
                        }
                        string membercode = string.Empty;
                        if (dtt.Rows[i]["cstmemberid"].ToString() != "0" && dtt.Rows[i]["cstmemberid"].ToString() != "-2")
                        {
                            membercode = dtt.Rows[i]["cstmemberid"].ToString();
                        }
                        temp += "{id:'" + dtt.Rows[i]["cstRecid"].ToString() + "|" + membercode + "|2" + "',name:'" + BLL.Util.EscapeString(dtt.Rows[i]["FULLName"].ToString()) + "'},";
                    }
                    temp = (temp.TrimEnd(',') + "]");
                    msg += temp;
                }
                else
                {
                    msg = "Search:'NotExistMember'";
                }
            }
            return msg;
        }

        private void BindRecord(out string msg)
        {
            msg = "Bind:'no'";
            Entities.CallRecordInfo model = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(RequestSessionID);
            if (model != null)
            {

                string content = string.Empty;
                if (!string.IsNullOrEmpty(RequestMemberType) && RequestMemberType == "1")
                {
                    string custid = string.Empty;
                    string memberid = string.Empty;
                    string oldcustid = (model.CCCustID != null && model.CCCustID.Length > 0 ? model.CCCustID.ToString() : model.CustID);
                    //string oldmemberid = (model.CCMemberID != null && model.CCMemberID.Value > 0 ? model.CCMemberID.Value.ToString() : model.DMSMemberID);

                    string oldmemberid = string.Empty;
                    if (model.CCMemberID != null && model.CCMemberID.ToString().Length > 0)
                    {
                        oldmemberid = model.CCMemberID.ToString();
                    }
                    else if (model.DMSMemberID != null && model.DMSMemberID.Length > 0)
                    {
                        oldmemberid = model.DMSMemberID.ToString();
                    }
                    else if (model.CC_CSTMemberID != null && model.CC_CSTMemberID.Length > 0)
                    {
                        oldmemberid = model.CC_CSTMemberID.ToString();
                    }
                    else if (model.CSTMemberID != null && model.CSTMemberID.Length > 0)
                    {
                        oldmemberid = model.CSTMemberID.ToString();
                    }

                    model.CustID = null;
                    model.CCCustID = null;
                    model.DMSMemberID = null;
                    model.CCMemberID = null;
                    model.CSTMemberID = null;
                    model.CC_CSTMemberID = null;

                    if (string.IsNullOrEmpty(RequestCC_CustID))
                    {
                        model.CustID = RequestCustID;
                        custid = model.CustID;
                    }
                    else
                    {
                        model.CCCustID = RequestCC_CustID;
                        custid = model.CCCustID.ToString();
                    }

                    if (string.IsNullOrEmpty(RequestCC_MemberID))
                    {
                        model.DMSMemberID = RequestMemberID;
                        memberid = model.DMSMemberID;
                    }
                    else
                    {
                        model.CCMemberID = RequestCC_MemberID;
                        memberid = RequestCC_MemberID;
                    }
                    content = string.Format("绑定录音ID:{2}由原先客户ID:{3}下,会员ID:{4},改为客户ID:{0}下,会员ID:{1},的记录成功。",
                              custid, memberid, model.RecID, oldcustid, oldmemberid);

                }
                else if (!string.IsNullOrEmpty(RequestMemberType) && RequestMemberType == "2")
                {
                    string custid = string.Empty;
                    string cstmemberid = string.Empty;
                    string oldcustid = (model.CCCustID != null && model.CCCustID.Length > 0 ? model.CCCustID.ToString() : model.CustID);

                    string oldcstmemberid = string.Empty;
                    if (model.CC_CSTMemberID != null && model.CC_CSTMemberID.Length > 0)
                    {
                        oldcstmemberid = model.CC_CSTMemberID.ToString();
                    }
                    else if (model.CSTMemberID != null && model.CSTMemberID.Length > 0)
                    {
                        oldcstmemberid = model.CSTMemberID.ToString();
                    }
                    else if (model.CCMemberID != null && model.CCMemberID.ToString().Length > 0)
                    {
                        oldcstmemberid = model.CCMemberID.ToString();
                    }
                    else if (model.DMSMemberID != null && model.DMSMemberID.Length > 0)
                    {
                        oldcstmemberid = model.DMSMemberID.ToString();
                    }


                    model.CustID = null;
                    model.CCCustID = null;
                    model.CSTMemberID = null;
                    model.CC_CSTMemberID = null;
                    model.CCMemberID = null;
                    model.DMSMemberID = null;

                    if (string.IsNullOrEmpty(RequestCC_CustID))
                    {
                        model.CustID = RequestCustID;
                        custid = model.CustID;
                    }
                    else
                    {
                        model.CCCustID = RequestCC_CustID;
                        custid = model.CCCustID.ToString();
                    }

                    if (string.IsNullOrEmpty(RequestCC_MemberID))
                    {
                        model.CSTMemberID = RequestMemberID;
                        cstmemberid = model.CSTMemberID;
                    }
                    else
                    {
                        model.CC_CSTMemberID = RequestCC_MemberID;
                        cstmemberid = RequestCC_MemberID;
                    }
                    content = string.Format("绑定录音ID:{2}由原先客户ID:{3}下,会员ID:{4},改为客户ID:{0}下,会员ID:{1},的记录成功。",
                              custid, cstmemberid, model.RecID, oldcustid, oldcstmemberid);

                }
                if (BLL.CallRecordInfo.Instance.Update(model) > 0)
                {
                    BitAuto.YanFa.SysRightManager.Common.LogInfo.Instance.InsertLog(ConfigurationUtil.GetAppSettingValue("BindRecordLogModuleID"), (int)BitAuto.YanFa.SysRightManager.Common.LogInfo.ActionType.Update, content);
                    msg = "Bind:'yes'";
                }

            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}