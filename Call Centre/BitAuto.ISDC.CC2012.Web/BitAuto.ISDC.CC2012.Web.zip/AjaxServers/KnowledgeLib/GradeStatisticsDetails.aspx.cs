﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.Utils;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.KnowledgeLib
{
    public partial class GradeStatisticsDetails : PageBase
    {
        public string BusinessType
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("BusinessType").ToString();
            }
        }
        public string StartTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("StartTime").ToString();
            }
        }
        public string EndTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EndTime").ToString();
            }
        }

        public int PageSize = 20;
        public int GroupLength = 8;
        public int RecordCount;
        private int userID = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                 int userID = BLL.Util.GetLoginUserID();
                 if (!BLL.Util.CheckRight(userID, "SYS024MOD6305"))//"质检统计管理—部门成绩明细"功能验证逻辑
                 {
                     Response.Write(BLL.Util.GetNotAccessMsgPage("您没有访问该页面的权限"));
                     Response.End();
                 }
                 else
                 {
                     BindData();
                 }
            }
        }
        //绑定数据
        public void BindData()
        {
            string strWhereOut = "";
            string strWhereIn = "";
            DateTime dateTimeS;
            DateTime dateTimeE;
            if (!string.IsNullOrEmpty(BusinessType) && BusinessType != "-1")
            {
                strWhereOut += " AND cri.BGID in (" + BLL.Util.SqlFilterByInCondition(BusinessType) + ")";
            }
            if (!string.IsNullOrEmpty(StartTime) && DateTime.TryParse(StartTime, out dateTimeS))
            {
                strWhereOut += " AND cor.CreateTime >='" + StartTime + " 00:00:00'";
                strWhereIn = " AND qsr.CreateTime>='" + StartTime + " 00:00:00'";
            }
            if (!string.IsNullOrEmpty(EndTime) && DateTime.TryParse(EndTime, out dateTimeE))
            {
                strWhereOut += " AND cor.CreateTime <='" + EndTime + " 23:59:59'";
                strWhereIn = " AND qsr.CreateTime<='" + EndTime + " 23:59:59'";
            }

            int RecordCount = 0;
            string tableEndName = "_QS";//查询质检话务冗余表
            DataTable dt = BLL.QS_Result.Instance.GetQS_ResultGradeStatistics(strWhereOut, strWhereIn, "a.t_Talk DESC", BLL.PageCommon.Instance.PageIndex, PageSize, tableEndName, out RecordCount);
            repeaterList.DataSource = dt;
            repeaterList.DataBind();

            AjaxPager.PageSize = 20;
            AjaxPager.InitPager(RecordCount);
        }
    }
}