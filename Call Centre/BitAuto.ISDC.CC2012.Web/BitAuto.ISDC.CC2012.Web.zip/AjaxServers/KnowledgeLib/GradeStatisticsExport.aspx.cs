﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BitAuto.Utils;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.KnowledgeLib
{
    public partial class GradeStatisticsExport : PageBase
    {
        public string BusinessType
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("ep_BusinessType").ToString();
            }
        }
        public string StartTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("ep_StartTime").ToString();
            }
        }
        public string EndTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("ep_EndTime").ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                int userID = BLL.Util.GetLoginUserID();
                if (!BLL.Util.CheckRight(userID, "SYS024MOD6315"))//"质检统计管理—部门成绩明细—导出"功能验证逻辑
                 {
                     Response.Write(BLL.Util.GetNotAccessMsgPage("您没有访问该页面的权限"));
                     Response.End();
                 } 
                string strWhereOut = "";
                string strWhereIn = "";
                DateTime dateTimeS;
                DateTime dateTimeE;
                if (!string.IsNullOrEmpty(BusinessType) && BusinessType != "-1")
                {
                    strWhereOut += " AND cri.BGID in (" + BLL.Util.SqlFilterByInCondition(BusinessType) + ")";
                }
                if (!string.IsNullOrEmpty(StartTime) && DateTime.TryParse(StartTime, out dateTimeS))
                {
                    strWhereOut += " AND cor.CreateTime >='" + StartTime + " 00:00:00'";
                    strWhereIn = " AND qsr.CreateTime>='" + StartTime + " 00:00:00'";
                }
                if (!string.IsNullOrEmpty(EndTime) && DateTime.TryParse(EndTime, out dateTimeE))
                {
                    strWhereOut += " AND cor.CreateTime <='" + EndTime + " 23:59:59'";
                    strWhereIn = " AND qsr.CreateTime<='" + EndTime + " 23:59:59'";
                }

                int RecordCount = 0;
                string tableEndName = "_QS";//查询质检话务冗余表
                DataTable dt = BLL.QS_Result.Instance.GetQS_ResultGradeStatistics(strWhereOut, strWhereIn, "a.t_Talk DESC", BLL.PageCommon.Instance.PageIndex, 100000, tableEndName, out RecordCount);

                if (dt != null)
                {
                    dt.Columns.Remove("RowNumber");
                    dt.Columns.Remove("BGID");

                    dt.Columns["Name"].ColumnName = "所属分组";
                    dt.Columns["t_Talk"].ColumnName = "总通话量";
                    dt.Columns["t_QS"].ColumnName = "抽检量";
                    dt.Columns["p_Qs"].ColumnName = "抽检比率";
                    dt.Columns["t_Qualified"].ColumnName = "合格量";
                    dt.Columns["p_Qualified"].ColumnName = "合格率";

                    BLL.Util.ExportToSCV("抽查频次统计" + DateTime.Now.ToString("yyyy-MM-dd-hh-mm-ss"), dt);
                }
            }
        }
    }
}