﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using System.Configuration;
using System.Text;
using System.Data;
using BitAuto.ISDC.CC2012.WebService;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers.LeadsTask
{
    /// <summary>
    /// LeadsTaskDeal 的摘要说明
    /// </summary>
    public class LeadsTaskDeal : IHttpHandler, IRequiresSessionState
    {
        #region 参数

        /// <summary>
        /// 项目ID
        /// </summary>
        private string RequestProjectID
        {
            get { return HttpContext.Current.Request["ProjectID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["ProjectID"].ToString()); }
        }
        /// <summary>
        /// 任务ID
        /// </summary>
        private string RequestTaskID
        {
            get { return HttpContext.Current.Request["TaskID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["TaskID"].ToString()); }
        }
        /// <summary>
        /// 失败原因
        /// </summary>
        private string RequestIsSuccess
        {
            get { return HttpContext.Current.Request["IsSuccess"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["IsSuccess"].ToString()); }
        }
        /// <summary>
        /// 失败原因
        /// </summary>
        private string RequestFailReson
        {
            get { return HttpContext.Current.Request["FailReson"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["FailReson"].ToString()); }
        }
        /// <summary>
        /// 备注
        /// </summary>
        private string RequestRemark
        {
            get { return HttpContext.Current.Request["Remark"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["Remark"].ToString()); }
        }
        /// <summary>
        /// 类型
        /// </summary>
        private string Action
        {
            get { return HttpContext.Current.Request["Action"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["Action"].ToString()); }
        }
        /// <summary>
        /// guid串
        /// </summary>
        private string RequestGuid
        {
            get
            {
                return HttpContext.Current.Request["GuidStr"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["GuidStr"].ToString());
            }
        }
        /// <summary>
        /// 经销商编号
        /// </summary>
        private string RequestMemberCode
        {
            get
            {
                return HttpContext.Current.Request["MemberCode"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["MemberCode"].ToString());
            }
        }
        /// <summary>
        /// 用户名称
        /// </summary>
        private string RequestUserName
        {
            get
            {
                return HttpContext.Current.Request["UserName"] == null ? "" :
                     HttpUtility.UrlDecode(HttpUtility.UrlDecode(HttpContext.Current.Request["UserName"].ToString()));
            }
        }
        /// <summary>
        /// 手机
        /// </summary>
        private string RequestMobilePhone
        {
            get
            {
                return HttpContext.Current.Request["MobilePhone"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["MobilePhone"].ToString());
            }
        }
        /// <summary>
        /// 需匹配车款ID
        /// </summary>
        private string RequestDCarID
        {
            get
            {
                return HttpContext.Current.Request["DCarID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["DCarID"].ToString());
            }
        }
        /// <summary>
        /// 需匹配车款名称
        /// </summary>
        private string RequestDCarName
        {
            get
            {
                return HttpContext.Current.Request["DCarName"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["DCarName"].ToString());
            }
        }
        /// <summary>
        /// 城市
        /// </summary>
        private string RequestCityID
        {
            get
            {
                return HttpContext.Current.Request["CityID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["CityID"].ToString());
            }
        }
        /// <summary>
        /// 需求单号
        /// </summary>
        private string RequestDemandID
        {
            get
            {
                return HttpContext.Current.Request["DemandID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["DemandID"].ToString());
            }
        }
        /// <summary>
        /// CallID
        /// </summary>
        private string RequestCallID
        {
            get
            {
                return HttpContext.Current.Request["CallID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["CallID"].ToString());
            }

        }
        /// <summary>
        /// BGID
        /// </summary>
        private string RequestBGID
        {
            get
            {
                return HttpContext.Current.Request["BGID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["BGID"].ToString());
            }

        }
        /// <summary>
        /// SCID
        /// </summary>
        private string RequestSCID
        {
            get
            {
                return HttpContext.Current.Request["SCID"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["SCID"].ToString());
            }

        }
        /// <summary>
        /// SEX
        /// </summary>
        private string RequestSEX
        {
            get
            {
                return HttpContext.Current.Request["SEX"] == null ? "" : HttpUtility.UrlDecode(HttpContext.Current.Request["SEX"].ToString());
            }

        }


        private string recordID;
        /// <summary>
        /// 通话流水号
        /// </summary>
        public string RecordID
        {
            get
            {
                if (recordID == null)
                {
                    recordID = HttpUtility.UrlDecode((HttpContext.Current.Request["RecordID"] + "").Trim());
                }
                return recordID;
            }
        }

        private string calledNum;
        /// <summary>
        /// 当前被叫号码
        /// </summary>
        public string CalledNum
        {
            get
            {
                if (calledNum == null)
                {
                    calledNum = HttpUtility.UrlDecode((HttpContext.Current.Request["CalledNum"] + "").Trim());
                }
                return calledNum;
            }
        }

        private string callerNum;
        /// <summary>
        /// 当前主叫号码
        /// </summary>
        public string CallerNum
        {
            get
            {
                if (callerNum == null)
                {
                    callerNum = HttpUtility.UrlDecode((HttpContext.Current.Request["CallerNum"] + "").Trim());
                }
                return callerNum;
            }
        }


        /// <summary>
        /// 接通开始时间
        /// </summary>
        public string RequestEstablishBeginTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishBeginTime").ToString().Trim();
            }
        }

        private string recordIDURL;
        /// <summary>
        /// 通话URL地址
        /// </summary>
        public string RecordIDURL
        {
            get
            {
                if (recordIDURL == null)
                {
                    recordIDURL = HttpUtility.UrlDecode((HttpContext.Current.Request["RecordIDURL"] + "").Trim());
                }
                return recordIDURL;
            }
        }

        //电话播出到坐席接起的时间
        private string networkrtimespan;
        public string NetworkRTimeSpan
        {
            get
            {
                if (networkrtimespan == null)
                {
                    networkrtimespan = HttpUtility.UrlDecode((HttpContext.Current.Request["NetworkRTimeSpan"] + "").Trim());
                }
                return networkrtimespan;
            }
        }

        //客户响铃时长
        private string establishtimespan;
        public string EstablishTimeSpan
        {
            get
            {
                if (establishtimespan == null)
                {
                    establishtimespan = HttpUtility.UrlDecode((HttpContext.Current.Request["EstablishTimeSpan"] + "").Trim());
                }
                return establishtimespan;
            }
        }
        /// <summary>
        /// 接通结束时间
        /// </summary>
        public string RequestEstablishEndTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishEndTime").ToString().Trim();
            }
        }

        public string RequestCustName
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CustName").ToString().Trim();
            }
        }

        ///// <summary>
        ///// 促销单版本号
        ///// </summary>
        //public string RequestDemandVersion
        //{
        //    get
        //    {
        //        return BLL.Util.GetCurrentRequestStr("DemandVersion").ToString().Trim();
        //    }
        //}
        #endregion

        private int userId;
        private string RealName;
        public void ProcessRequest(HttpContext context)
        {
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();
            context.Response.ContentType = "text/plain";
            string msg = "";
            CheckData(out msg);
            if (msg == "")
            {
                userId = BLL.Util.GetLoginUserID();
                RealName = BLL.Util.GetLoginRealName();
                switch (Action.ToLower())
                {
                    case "saveinfo":
                        saveinfo(out msg);
                        break;
                    case "subinfo":
                        subinfo(out msg);
                        break;
                    case "insertcustdata":
                        InsertCustData(out msg);
                        break;
                    case "insertcallrecordorigbusiness":
                        InsertCallRecord_ORIG_Business(out msg);
                        break;
                    case "established"://呼出接通                        
                        Established(out msg);
                        break;
                    case "released"://挂断
                        Released(out msg);
                        break;

                }
            }
            if (msg == "")
            {
                msg = "{\"Result\":true}";
            }
            context.Response.Write(msg);
        }

        /// <summary>
        /// 电话呼出挂断
        /// </summary>
        /// <param name="msg"></param>
        private void Released(out string msg)
        {
            msg = string.Empty;
            //录音表主键格式正确
            long _callid;
            if (!string.IsNullOrEmpty(RequestCallID) && long.TryParse(RequestCallID, out _callid))
            {
                Entities.CallRecordInfo model = BLL.CallRecordInfo.Instance.GetCallRecordInfoByCallID(_callid);
                //取本地录音记录
                //Entities.CallRecordInfo model = BLL.CallRecordInfo.Instance.GetCallRecordInfoBySessionID(RecordID);
                if (model != null && model.RecID > 0)
                {
                    DateTime endTime = DateTime.Now;
                    model.TallTime = 0;
                    if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
                    {
                        if (model.BeginTime != null && model.BeginTime != BitAuto.ISDC.CC2012.Entities.Constants.Constant.DATE_INVALID_VALUE)
                        {
                            TimeSpan tsSpan = (TimeSpan)(endTime - model.BeginTime);
                            model.TallTime = (int)tsSpan.TotalSeconds;
                        }
                    }
                    model.EndTime = endTime;
                    //add by qizq 2014-6-11更新录音sessionId和录音地址
                    model.SessionID = RecordID;
                    model.AudioURL = RecordIDURL;
                    int result = 0;
                    result = BLL.CallRecordInfo.Instance.Update(model);

                }
                //返回处理记录主键
                msg = "{'success':'yes'}";
            }
            else
            {
                //返回处理记录主键
                msg = "{'success':'no','msg':'没找到录音'}";
            }

        }

        /// <summary>
        /// 电话呼出接通
        /// </summary>
        /// <param name="msg"></param>
        private void Established(out string msg)
        {
            msg = string.Empty;
            Entities.CallRecordInfo model = new Entities.CallRecordInfo();
            //通话流水号
            model.SessionID = RecordID;
            //坐席分机号
            model.ExtensionNum = RequestUserName;

            //对方号码
            model.PhoneNum = CallerNum;
            //呼出号码
            model.ANI = CalledNum;

            //呼出
            model.CallStatus = 2;
            //录音开始时间
            model.BeginTime = System.DateTime.Now;

            DateTime beginTime = DateTime.Now;
            if (DateTime.TryParse(RequestEstablishBeginTime, out beginTime))
            {

            }
            model.BeginTime = beginTime;

            //录音地址
            model.AudioURL = RecordIDURL;
            ////CRM客户ID
            //model.CustID = CustID;
            ////客户名称
            model.CustName = RequestCustName;
            model.CreateTime = System.DateTime.Now;
            model.CreateUserID = BLL.Util.GetLoginUserID();
            //联系人
            //model.Contact = Contact;
            //任务ID
            model.TaskID = RequestTaskID;

            model.TallTime = 0;

            //任务分类id,数据清洗
            model.TaskTypeID = (int)Entities.TaskTypeID.OtherTask;
            //坐席振铃时长
            int AgentRingTime = 0;
            if (int.TryParse(NetworkRTimeSpan, out AgentRingTime))
            {
                model.AgentRingTime = AgentRingTime;
            }
            //客户振铃时长
            int CustomRingTime = 0;
            if (int.TryParse(EstablishTimeSpan, out CustomRingTime))
            {
                model.CustomRingTime = CustomRingTime;
            }
            //int _newcustid;
            //if (int.TryParse(NewCustID, out _newcustid))
            //{
            //    model.CCCustID = _newcustid.ToString();
            //}
            //其他任务加业务组，分组
            int _bgid = 0;
            int _scid = 0;

            if (int.TryParse(RequestBGID, out _bgid))
            {
                model.BGID = _bgid;
            }
            if (int.TryParse(RequestSCID, out _scid))
            {
                model.SCID = _scid;
            }


            //西门子callid
            Int64 _callID = 0;
            if (Int64.TryParse(RequestCallID, out _callID))
            {
            }
            model.CallID = _callID;

            int RecID = BLL.CallRecordInfo.Instance.Insert(model);

            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID开始");

            //调用webservice,保存callid,业务id，业务组，分类对应关系
            //int Result = CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID(model.CallID, model.TaskID, model.BGID, model.SCID, Convert.ToInt32(model.CreateUserID), ref msg);
            int Result = BLL.CallRecord_ORIG_Business.Instance.UpdateBusinessDataByCallID(model.CallID, model.TaskID, model.BGID, model.SCID, Convert.ToInt32(model.CreateUserID), ref msg);
            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID结束返回值Result=" + Result);

            msg = "{'success':'yes','recordid':'" + RecID + "'}";
        }

        //插入话务总表跟业务分组中间表记录
        public void InsertCallRecord_ORIG_Business(out string msg)
        {
            BLL.Loger.Log4Net.Info("[LeadsTaskDeal]InsertCallRecord_ORIG_Business: CallID:" + RequestCallID + ",CreateUserID:" + userId);
            msg = string.Empty;
            Entities.CallRecord_ORIG_Business callrecordorgbusiness = new Entities.CallRecord_ORIG_Business();

            callrecordorgbusiness.CreateUserID = userId;

            //线索清洗业务组，分组
            int _bgid = 0;
            int _scid = 0;
            if (int.TryParse(RequestBGID, out _bgid))
            {
                callrecordorgbusiness.BGID = _bgid;
            }
            if (int.TryParse(RequestSCID, out _scid))
            {
                callrecordorgbusiness.SCID = _scid;
            }

            //西门子callid
            Int64 _callID = 0;
            if (Int64.TryParse(RequestCallID, out _callID))
            {
            }
            callrecordorgbusiness.CallID = _callID;
            callrecordorgbusiness.CreateTime = DateTime.Now;
            callrecordorgbusiness.BusinessID = RequestTaskID;


            int RecID;
            //查询现在表
            if (!BLL.CallRecord_ORIG_Business.Instance.IsExistsByCallID(_callID))
            {
                BLL.Loger.Log4Net.Info("[LeadsTaskDeal]InsertCallRecord_ORIG_Business ...中间表数据不存在...CallID:" + RequestCallID);
                RecID = BLL.CallRecord_ORIG_Business.Instance.Insert(callrecordorgbusiness);
            }
            else
            {
                RecID = BLL.CallRecord_ORIG_Business.Instance.Update(callrecordorgbusiness);
            }
            msg = "{'success':'yes','recordid':'" + RecID + "'}";
        }

        protected void InsertCustData(out string msg)
        {
            msg = "";
            StringBuilder jsonstr = new StringBuilder();
            jsonstr.Append("{");
            jsonstr.Append("CustName:'" + RequestUserName + "',");
            jsonstr.Append("Sex:'" + RequestSEX + "',");
            jsonstr.Append("Tels:[" + RequestMobilePhone + "],");
            jsonstr.Append("CallID:'" + RequestCallID + "',");
            jsonstr.Append("BusinessID:'" + RequestTaskID + "',");
            jsonstr.Append("BGID:'" + RequestBGID + "',");
            jsonstr.Append("SCID:'" + RequestSCID + "',");
            jsonstr.Append("MemberCode:''");
            jsonstr.Append("}");
            Entities.LeadsTaskOperationLog model = new Entities.LeadsTaskOperationLog();
            model.CreateTime = System.DateTime.Now;
            model.CreateUserID = userId;
            model.TaskID = RequestTaskID;
            model.Remark = "调用插入客户池接口开始，Jsonstr:" + jsonstr.ToString();
            string Result = CallRecordServiceHelper.Instance.InsertCustData(jsonstr.ToString());
            model.Remark = "调用插入客户池接口结束，结果为:" + Result;
            BLL.LeadsTaskOperationLog.Instance.Insert(model);
        }
        /// <summary>
        /// 后台验证
        /// </summary>
        /// <param name="msg"></param>
        protected void CheckData(out string msg)
        {
            msg = "";
            if (string.IsNullOrEmpty(RequestTaskID))
            {
                msg = "{\"Result\":false,\"Msg\":\"任务不能为空\"}";
            }
            else
            {
                if (string.IsNullOrEmpty(Action))
                {
                    msg = "{\"Result\":false,\"Msg\":\"请求参数错误！\"}";
                }
                else
                {
                    if (!string.IsNullOrEmpty(RequestRemark))
                    {
                        if (RequestRemark.Length > 200)
                        {
                            msg = "{\"Result\":false,\"Msg\":\"备注超长！\"}";
                            return;
                        }
                    }
                    if (Action == "subinfo" && RequestIsSuccess == "1" && (string.IsNullOrEmpty(RequestDCarID) || RequestDCarID == "-2"))
                    {
                        msg = "{\"Result\":false,\"Msg\":\"需匹配车款必填！\"}";
                        return;
                    }
                    if (Action == "subinfo" && string.IsNullOrEmpty(RequestIsSuccess))
                    {
                        msg = "{\"Result\":false,\"Msg\":\"是否成功必须选择！\"}";
                        return;
                    }
                    if (!string.IsNullOrEmpty(RequestIsSuccess))
                    {
                        if (Action == "subinfo" && RequestIsSuccess == "0" && (string.IsNullOrEmpty(RequestFailReson) || RequestFailReson == "-2"))
                        {
                            msg = "{\"Result\":false,\"Msg\":\"当选择失败时失败原因必填！\"}";
                            return;
                        }
                    }
                }
            }
        }
        /// <summary>
        /// 取新增Leads xml字符串
        /// </summary>
        /// <returns></returns>
        protected string GetLeadsXmlStr(string DemandVersion)
        {
            StringBuilder xmlstr = new StringBuilder();
            xmlstr.Append("<?xml version='1.0' encoding='utf-8' ?>");
            xmlstr.Append("<Leads>");
            xmlstr.Append("<RelationID>" + RequestGuid + "</RelationID>");
            xmlstr.Append("<MemberCode>" + RequestMemberCode + "</MemberCode>");
            xmlstr.Append("<Name>" + RequestUserName + "</Name>");
            xmlstr.Append("<MobilePhone>" + RequestMobilePhone + "</MobilePhone>");
            xmlstr.Append("<CarID>" + RequestDCarID + "</CarID>");
            xmlstr.Append("<CityID>" + RequestCityID + "</CityID>");
            //涞源为CC
            xmlstr.Append("<Source>2</Source >");
            xmlstr.Append("<Version>" + DemandVersion + "</Version>");
            xmlstr.Append("</Leads>");
            return xmlstr.ToString();
        }
        /// <summary>
        /// 保存信息
        /// </summary>
        /// <param name="msg"></param>
        protected void saveinfo(out string msg)
        {
            msg = "";
            //处理Lead是，修改任务状态，插入任务操作日志
            DealTask(1, out msg);
        }
        /// <summary>
        /// ordertype 1是保存，2是提交
        /// </summary>
        /// <param name="ordertype"></param>
        protected void DealTask(int ordertype, out string msg)
        {
            msg = "";
            if (!string.IsNullOrEmpty(RequestTaskID))
            {
                Entities.LeadsTask model = BLL.LeadsTask.Instance.GetLeadsTask(RequestTaskID);
                if (model != null)
                {
                    if (model.Status != (int)Entities.LeadsTaskStatus.Processing && model.Status != (int)Entities.LeadsTaskStatus.NoProcess)
                    {
                        #region 如果任务被撤销任然保存任务,魏淑珍要求的
                        if (model.Status == (int)Entities.LeadsTaskStatus.ReBack)
                        {
                            model.LastUpdateTime = System.DateTime.Now;
                            model.LastUpdateUserID = userId;
                            model.Remark = RequestRemark;
                            int _IsSuccess = -2;
                            if (int.TryParse(RequestIsSuccess, out _IsSuccess))
                            {
                                model.IsSuccess = _IsSuccess;
                            }
                            //失败原因
                            int FailReson = -2;
                            if (int.TryParse(RequestFailReson, out FailReson))
                            {
                                model.FailReason = FailReson;
                            }
                            //需匹配车款ID
                            int _DCarID = -2;
                            if (int.TryParse(RequestDCarID, out _DCarID))
                            {
                                model.DCarID = _DCarID;
                            }
                            //需匹配车款名称
                            model.DCarName = RequestDCarName;
                            //更新线索任务信息
                            BLL.LeadsTask.Instance.Update(model);
                        }
                        msg = "{\"Result\":false,\"Msg\":\"任务不处于处理状态！\"}";
                        #endregion
                    }
                    else
                    {
                        #region 保存或提交订单信息，修改任务状态，插入任务操作状态
                        model.LastUpdateTime = System.DateTime.Now;
                        model.LastUpdateUserID = userId;
                        model.Remark = RequestRemark;
                        //保存
                        if (ordertype == 1)
                        {
                            model.Status = (int)Entities.GroupTaskStatus.Processing;
                        }
                        //提交
                        else if (ordertype == 2)
                        {
                            model.Status = (int)Entities.GroupTaskStatus.Processed;
                        }
                        //是否成功
                        int _IsSuccess = -2;
                        if (int.TryParse(RequestIsSuccess, out _IsSuccess))
                        {
                            model.IsSuccess = _IsSuccess;
                        }
                        //失败原因
                        int FailReson = -2;
                        if (int.TryParse(RequestFailReson, out FailReson))
                        {
                            model.FailReason = FailReson;
                        }
                        //需匹配车款ID
                        int _DCarID = -2;
                        if (int.TryParse(RequestDCarID, out _DCarID))
                        {
                            model.DCarID = _DCarID;
                        }
                        //需匹配车款名称
                        model.DCarName = RequestDCarName;
                        //如果是提交，并且选择成功则取当前最新促销信息版本号
                        if (ordertype == 2 && model.IsSuccess == 1)
                        {
                            //根据需求单号获取促销信息版本号
                            int DemandVersion = 0;
                            DemandVersion = BitAuto.YanFa.Crm2009.BLL.YJKDemandBLL.Instance.GetYJKDemandMaxVersion(model.DemandID);
                            model.DemandVersion = DemandVersion;
                        }
                        //更新线索任务信息
                        BLL.LeadsTask.Instance.Update(model);
                        //插入任务操作日志
                        DealLog(ordertype);
                        #endregion

                        #region 提交处理
                        if (ordertype == 2)
                        {
                            #region 如果选择成功则调用接口,插入调用日志，发送短信
                            Entities.LeadsTaskOperationLog logmodel = new Entities.LeadsTaskOperationLog();
                            if (model.IsSuccess == 1)
                            {
                                #region 调用新增Leads接口
                                logmodel.TaskID = RequestTaskID;
                                logmodel.CreateTime = System.DateTime.Now;
                                logmodel.CreateUserID = userId;
                                //取xml
                                string addleadsstr = GetLeadsXmlStr(model.DemandVersion.ToString());

                                //记录调用开始
                                logmodel.Remark = "为需求单" + RequestDemandID + "调用新增Leads接口开始,xml字符串数据：" + addleadsstr;
                                BLL.LeadsTaskOperationLog.Instance.Insert(logmodel);
                                //

                                bool flag = false;
                                logmodel.CreateTime = System.DateTime.Now;
                                try
                                {
                                    flag = WebService.CRM.CRMYJKServiceHelper.Instance.AddLeadsInfo(addleadsstr);
                                    //调用成功
                                    if (flag)
                                    {
                                        logmodel.Remark = "为需求单" + RequestDemandID + "调用新增Leads接口结束，调用结果是成功！";
                                    }
                                    //调用失败
                                    else
                                    {
                                        logmodel.Remark = "为需求单" + RequestDemandID + "调用新增Leads接口结束，调用结果是失败！";
                                    }
                                }
                                catch (Exception ex)
                                {
                                    //msg = ex.Message;
                                    BLL.Loger.Log4Net.Debug("调用新增Leads接口失败:", ex);
                                    logmodel.Remark = "为需求单" + RequestDemandID + "调用新增Leads接口结束，调用结果是出现异常，异常信息为：" + ex.Message;
                                    UnhandledExceptionFunction(null, new UnhandledExceptionEventArgs(ex, false));
                                }
                                //记录调用结束
                                BLL.LeadsTaskOperationLog.Instance.Insert(logmodel);

                                //
                                #endregion

                                //#region 插入调用日志
                                //Entities.UpdateOrderData updateDateMode = new Entities.UpdateOrderData();
                                //updateDateMode.TaskID = model.TaskID.ToString();
                                //updateDateMode.UpdateType = 1;
                                //updateDateMode.IsUpdate = 1; // 1 成功了，不用处理，-1 需要重新处理
                                //updateDateMode.UpdateErrorMsg = logmodel.Remark;
                                //updateDateMode.CreateTime = DateTime.Now;
                                //updateDateMode.CreateUserID = userId;
                                //updateDateMode.APIType = 9;//9为新增Leads接口
                                //BLL.UpdateOrderData.Instance.Insert(updateDateMode);
                                //#endregion

                                #region 发送短信
                                //发送号码
                                string str = RequestMobilePhone;
                                try
                                {
                                    BitAuto.YanFa.Crm2009.Entities.DMSMember DMSModel = BitAuto.YanFa.Crm2009.BLL.DMSMember.Instance.GetDMSMemberByMemberCode(RequestMemberCode);
                                    if (DMSModel != null)
                                    {
                                        string DmsTel = GetDMSTel(RequestMemberCode, DMSModel.Phone);
                                        if (string.IsNullOrEmpty(DmsTel))
                                        {
                                            logmodel.Remark = "给手机（" + str + "）发送短信失败【错误信息：没有找到经销商联系电话】";
                                        }
                                        else if (string.IsNullOrEmpty(DMSModel.ContactAddress))
                                        {
                                            logmodel.Remark = "给手机（" + str + "）发送短信失败【错误信息：没有找到经销商联系地址】";
                                        }
                                        else if (string.IsNullOrEmpty(DMSModel.Abbr))
                                        {
                                            logmodel.Remark = "给手机（" + str + "）发送短信失败【错误信息：没有找到经销商简称】";
                                        }
                                        else
                                        {
                                            //发送内容
                                            //您已成功报名易车网{品牌}{车型}优惠活动，请尽快到{经销商简称}参加活动，地址：{经销商地址}，咨询电话：{经销商400电话}。
                                            string SendContent = string.Format("您已成功报名易车网{0}{1}特卖活动，请尽快到{2}参加活动，地址：{3}，咨询电话：{4}。", model.DCarMaster, model.DCarSerial, DMSModel.Abbr, DMSModel.ContactAddress, DmsTel);
                                            string md5 = SMSServiceHelper.Instance.MixMd5(str, SendContent);
                                            int msgid = SMSServiceHelper.Instance.SendMsgImmediately(str, SendContent, DateTime.Now.AddHours(1), md5);
                                            logmodel.CreateTime = System.DateTime.Now;
                                            if (msgid > 0)
                                            {
                                                logmodel.Remark = "给手机（" + str + "）发送短信成功,发送内容：" + SendContent;
                                            }
                                            else
                                            {
                                                msg = BLL.Util.GetEnumOptText(typeof(Entities.SendSMSInfo), msgid);
                                                logmodel.Remark = "给手机（" + str + "）发送短信失败【错误信息：" + msg + "】";
                                            }
                                        }
                                    }
                                    else
                                    {
                                        logmodel.Remark = "给手机（" + str + "）发送短信失败【错误信息：没有找到经销商信息】";
                                    }
                                }
                                catch (Exception ex)
                                {
                                    logmodel.Remark = "给手机（" + str + "）发送短信失败【错误信息：程序出现异常，异常信息：" + ex.Message + "】";
                                }
                                BLL.LeadsTaskOperationLog.Instance.Insert(logmodel);
                                #endregion
                            }
                            #endregion

                            #region 判断是否补满
                            BitAuto.YanFa.Crm2009.Entities.YJKDemand.YJKDemandQuery query = new YanFa.Crm2009.Entities.YJKDemand.YJKDemandQuery();
                            query.DemandId = RequestDemandID;
                            DataTable DemandTable = BitAuto.YanFa.Crm2009.BLL.YJKDemandBLL.Instance.GetYJKDemandInfo(query, string.Empty);
                            if (DemandTable != null && DemandTable.Rows.Count > 0)
                            {
                                //实际集客人数
                                int _PracticalNum = 0;
                                if (DemandTable.Rows[0]["PracticalNum"] != DBNull.Value)
                                {
                                    int.TryParse(DemandTable.Rows[0]["PracticalNum"].ToString(), out _PracticalNum);
                                }
                                //目标集客人数
                                int _ExpectedNum = 0;
                                if (DemandTable.Rows[0]["ExpectedNum"] != DBNull.Value)
                                {
                                    int.TryParse(DemandTable.Rows[0]["ExpectedNum"].ToString(), out _ExpectedNum);
                                }
                                //如果实际集客人数大于等于目标集客人数
                                if (_PracticalNum >= _ExpectedNum)
                                {
                                    #region 如果补满调用项目结束方法
                                    long _projectid;
                                    if (long.TryParse(RequestProjectID, out _projectid))
                                    {
                                        logmodel.Remark = "需求单" + RequestDemandID + "已经补满Leads,调用项目结束方法开始";
                                        logmodel.CreateTime = System.DateTime.Now;
                                        BLL.LeadsTaskOperationLog.Instance.Insert(logmodel);
                                        string ErroMsg = string.Empty;
                                        BLL.ProjectInfo.Instance.EndCCProject(_projectid, 5, out ErroMsg);
                                        logmodel.Remark = "需求单" + RequestDemandID + "已经补满Leads,调用项目结束方法结束，调用返回信息是" + ErroMsg;
                                        logmodel.CreateTime = System.DateTime.Now;
                                        BLL.LeadsTaskOperationLog.Instance.Insert(logmodel);
                                    }
                                    else
                                    {
                                        logmodel.Remark = "需求单" + RequestDemandID + "已经补满Leads,但是项目编号转换成长整型出错";
                                        logmodel.CreateTime = System.DateTime.Now;
                                        BLL.LeadsTaskOperationLog.Instance.Insert(logmodel);
                                    }
                                    #endregion
                                }
                            }
                            #endregion
                        }
                        #endregion
                    }
                }
                else
                {
                    msg = "{\"Result\":false,\"Msg\":\"任务不存在！\"}";
                }
            }
        }
        /// <summary>
        /// 取经销商电话
        /// </summary>
        /// <param name="DMSCode"></param>
        /// <param name="tel"></param>
        /// <returns></returns>
        protected string GetDMSTel(string DMSCode, string tel)
        {
            string DMSTEL = string.Empty;
            int memberCode = 0;
            try
            {
                if (int.TryParse(DMSCode, out memberCode))
                {
                    //通过易湃接口取400电话
                    DataSet ds = WebService.DealerInfoServiceHelper.Instance.GetDealer400(memberCode);
                    if (ds != null && ds.Tables[0].Rows.Count > 0)
                    {
                        DMSTEL = ds.Tables[0].Rows[0][2].ToString();
                    }
                    else
                    {
                        DMSTEL = tel;
                    }
                }
                else
                {
                    DMSTEL = tel;
                }
            }
            catch (Exception ex)
            {
                DMSTEL = tel;
            }
            return DMSTEL;
        }
        /// <summary>
        /// ordertype 1是保存，2是提交
        /// </summary>
        /// <param name="ordertype"></param>
        protected void DealLog(int ordertype)
        {
            Entities.LeadsTaskOperationLog logmodel = new Entities.LeadsTaskOperationLog();
            logmodel.Remark = RequestRemark;
            logmodel.TaskID = RequestTaskID;
            logmodel.CreateTime = System.DateTime.Now;
            logmodel.CreateUserID = userId;
            if (ordertype == 1)
            {
                logmodel.OperationStatus = (int)Entities.Leads_OperationStatus.Save;
                logmodel.TaskStatus = (int)Entities.LeadsTaskStatus.Processing;
                logmodel.Remark = "保存";
            }
            else if (ordertype == 2)
            {
                logmodel.OperationStatus = (int)Entities.Leads_OperationStatus.Submit;
                logmodel.TaskStatus = (int)Entities.LeadsTaskStatus.Processed;
                logmodel.Remark = "提交";
            }
            //if (!string.IsNullOrEmpty(RequestRemark))
            //{
            //    logmodel.Remark += "，备注信息：" + RequestRemark;
            //}
            BLL.LeadsTaskOperationLog.Instance.Insert(logmodel);
        }

        /// <summary>
        /// 提交信息
        /// </summary>
        /// <param name="msg"></param>
        protected void subinfo(out string msg)
        {
            msg = "";
            //1.处理Leads任务，2.修改任务状态，3.插入任务操作日志，4.调用新增leads接口，插入调用日志 5.查询是否补满leads，如果补满，结束项目撤销其他未处理任务，发送短信
            DealTask(2, out msg);

        }
        #region 异常处理
        private void UnhandledExceptionFunction(Object sender, UnhandledExceptionEventArgs args)
        {
            Exception e = (Exception)args.ExceptionObject;
            BLL.Loger.Log4Net.Debug("调用小春新增Leads接口出错", e);

            string errorMsg = e.Message;
            string stackTrace = e.StackTrace;
            string source = e.Source;

            string mailBody = string.Format("错位信息：{0}<br/>错误Source：{1}<br/>错误StackTrace：{2}<br/>IsTerminating:{3}<br/>",
                errorMsg, source, stackTrace, args.IsTerminating);
            string subject = "客户呼叫中心系统——调用小春新增Leads接口出错";
            string[] userEmail = ConfigurationManager.AppSettings["ReceiveErrorEmail"].Split(';');
            if (userEmail != null && userEmail.Length > 0)
            {
                BLL.EmailHelper.Instance.SendErrorMail(mailBody, subject, userEmail);
            }
        }
        #endregion
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}