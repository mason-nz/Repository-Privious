﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.SessionState;
using BitAuto.ISDC.CC2012.BLL;
using BitAuto.Utils.Config;
using System.Configuration;

namespace BitAuto.ISDC.CC2012.Web.AjaxServers
{
    /// <summary>
    /// Summary description for UCDemoHandler
    /// </summary>
    public class UCDemoHandler : IHttpHandler, IRequiresSessionState
    {

        #region 属性定义
        /// <summary>
        /// 请求方法标识
        /// </summary>
        public string RequestAction
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("Action").ToString();
            }
        }

        /// <summary>
        /// 青牛会话ID
        /// </summary>
        public string RequestSessionID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("SessionID").ToString().Trim();
            }
        }

        /// <summary>
        /// 话务总表登录分机号
        /// </summary>
        public string RequestExtensionNum
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("ExtensionNum").ToString().Trim();
            }
        }

        /// <summary>
        /// 话务总表主叫号码
        /// 西门子话务表中 外呼时 分机号=主叫号
        /// </summary>
        public string RequestPhoneNum
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("PhoneNum").ToString().Trim();
            }
        }

        /// <summary>
        /// 话务总表被叫号码
        /// </summary>
        public string RequestANI
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("ANI").ToString().Trim();
            }
        }

        /// <summary>
        /// 呼入电话接入号
        /// </summary>
        public string RequestSwitchINNum
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("SwitchINNum").ToString().Trim();
            }
        }

        /// <summary>
        /// 状态，1呼入，2呼出。
        /// </summary>
        public string RequestCallStatus
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CallStatus").ToString().Trim();
            }
        }

        /// <summary>
        /// 已接，去电记录表的任务类型，1工单，2团购订单，3客户核实，4其它任务,5惠买车。
        /// </summary>
        public string RequestTaskTypeID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("TaskTypeID").ToString().Trim();
            }
        }

        /// <summary>
        /// 任务ID
        /// </summary>
        public string RequestTaskID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("TaskID").ToString().Trim();
            }
        }

        /// <summary>
        /// CustID
        /// </summary>
        public string RequestCustID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CustID").ToString().Trim();
            }
        }

        /// <summary>
        /// 话务表的录音URL地址。
        /// </summary>
        public string RequestAudioURL
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("AudioURL").ToString().Trim();
            }
        }

        /// <summary>
        /// 已接，去电记录表的 坐席振铃时长
        /// </summary>
        public string RequestAgentRingTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("AgentRingTime").ToString().Trim();
            }

        }

        /// <summary>
        /// 已接，去电记录表的 客户振铃时长
        /// </summary>
        public string RequestCustomerRingTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CustomerRingTime").ToString().Trim();
            }
        }
        /// <summary>
        /// 已接，去电记录表的 开始时间
        /// </summary>
        public string RequestEstablishBeginTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishBeginTime").ToString().Trim();
            }
        }

        /// <summary>
        /// 已接，去电记录表的 结束时间
        /// </summary>
        public string RequestEstablishEndTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("EstablishEndTime").ToString().Trim();
            }
        }

        /// <summary>
        /// 已接，去电记录表的 客户名称
        /// </summary>
        public string RequestCustName
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CustName").ToString().Trim();
            }
        }

        /// <summary>
        /// 业务组ID
        /// </summary>
        public string RequestBGID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("BGID").ToString().Trim();
            }
        }

        /// <summary>
        /// 业务组分类ID
        /// </summary>
        public string RequestSCID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("SCID").ToString().Trim();
            }
        }

        /// <summary>
        /// 自己生成的新话务ID
        /// </summary>
        public string CallID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CallID").ToString().Trim();
            }
        }

        /// <summary>
        /// 自己生成的新话务ID
        /// </summary>
        public string CreateUserID
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("CreateUserID").ToString().Trim();
            }
        }


        /// <summary>
        ///外拨初始化时间戳 
        /// </summary>
        public string InitiatedTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("InitiatedTime").ToString().Trim();
            }
        }
        /// <summary>
        ///外拨振铃时间,呼入振铃时间
        /// </summary>
        public string RingingTime
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("RingingTime").ToString().Trim();
            }
        }
        /// <summary>
        /// 呼入坐席技能组
        /// </summary>
        public string RequestSkillGroup
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("SkillGroup").ToString().Trim();
            }
        }
        /// <summary>
        /// 客户回访联系人CallRecordInfo字段：Contact
        /// </summary>
        public string RequestContact
        {
            get
            {
                return BLL.Util.GetCurrentRequestStr("Contact").ToString().Trim();
            }
        }
        
        /// <summary>
        ///当前时间
        /// </summary>
        public DateTime CurrentTime;

        #endregion

        #region 异步发送邮件
        private delegate void EVTHandler_SendErrorEmail(string errorMsg, string source, string stackTrace);
        private event EVTHandler_SendErrorEmail EVTSendErrorEmail;
        #endregion
        public void ProcessRequest(HttpContext context)
        {
            BitAuto.YanFa.SysRightManager.Common.UserInfo.Check();
            CurrentTime = DateTime.Now;
            bool success = false;
            string result = "";
            string msg = "";
            context.Response.ContentType = "text/plain";

            try
            {

                switch (RequestAction)
                {
                    case "AgentStatus_Connecting"://初始化+对方振铃
                        AgentStatus_Connecting(out success, out result, out msg);
                        break;
                    case "AgentStatus_Connected_Normal"://接通电话
                        AgentStatus_Connected_Normal(out success, out result, out msg);
                        break;
                    case "AgentStatus_Disconnected"://挂断电话
                        AgentStatus_Disconnected(out success, out result, out msg);
                        break;
                    case "AgentStatus_Disconnected_Inbound"://呼入挂断电话
                        AgentStatus_Disconnected_Inbound(out success, out result, out msg);
                        break;
                    default:
                        success = false;
                        msg = "请求参数错误";
                        break;
                }
                AJAXHelper.WrapJsonResponse(success, result, msg);
            }
            catch (Exception ex)
            {
                AJAXHelper.WrapJsonResponse(false, "", ex.Message);
            }
        }

        void AgentStatus_Connecting(out bool success, out string result, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]***********************************************");
            Loger.Log4Net.Info("[UCDemoHandler]事件操作对方振铃CallID：还未生成" + CallID + ",主叫：" + RequestPhoneNum + ",被叫：" + RequestANI + ",分机:" + RequestExtensionNum);
            success = false;
            result = "";
            msg = "";
            string scallid = "";

            //插入话务总表
            try
            {
                if (InsertCallRecord_ORIG(out result, out msg))
                {
                    success = true;
                    scallid = result;
                }
                else
                {
                    success = false;
                    Loger.Log4Net.Info("[UCDemoHandler]插入话务总表记录CallID失败，CallID:" + scallid + "!,error:" + msg);
                    return;
                }
            }
            catch (Exception ex)
            {
                success = false;
                Loger.Log4Net.Error("[UCDemoHandler]插入话务总表记录CallID失败，CallID:" + scallid + "!，ErrorMsg:" + ex.Message + ",ErrorStackTrace:" + ex.StackTrace);
                return;
            }

            //插入话务业务中间表
            try
            {
                InsertCallRecord_ORIG_Business(Convert.ToInt64(scallid), out msg);
                success = true;
            }
            catch (Exception ex)
            {
                success = false;
                Loger.Log4Net.Error("[UCDemoHandler]插入话务-业务中间表失败，CallID:" + scallid + "!，ErrorMsg:" + ex.Message + ",ErrorStackTrace:" + ex.StackTrace);
            }

        }

        void AgentStatus_Connected_Normal(out bool success, out string result, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]事件操作电话接通CallID：" + CallID + ",主叫：" + RequestANI + ",被叫：" + RequestPhoneNum + ",分机:" + RequestExtensionNum);
            success = false;
            result = "";
            msg = "";

            //插入去电记录表            
            try
            {
                InsertCallRecordInfo(out result);
                success = true;
            }
            catch (Exception ex)
            {
                success = false;
                Loger.Log4Net.Error("[UCDemoHandler]插入已接、去电记录表失败，CallID:" + CallID + "!，ErrorMsg:" + ex.Message + ",ErrorStackTrace:" + ex.StackTrace);
            }


            try
            {
                //更新话务总表接通时间
                Entities.CallRecord_ORIG model = BLL.CallRecord_ORIG.Instance.GetCallRecord_ORIGByCallID(Convert.ToInt64(CallID));

                if (model != null)
                {
                    model.EstablishedTime = CurrentTime;
                    if (!string.IsNullOrEmpty(RequestAudioURL))
                    {
                        model.AudioURL = RequestAudioURL;
                    }
                    BitAuto.ISDC.CC2012.BLL.CallRecord_ORIG.Instance.Update(model);
                }

                success = true;
            }
            catch (Exception ex)
            {
                success = false;
                Loger.Log4Net.Error("[UCDemoHandler]更新话务总表接通时间失败，CallID:" + CallID + "!，ErrorMsg:" + ex.Message + ",ErrorStackTrace:" + ex.StackTrace);
            }
        }

        void AgentStatus_Disconnected(out bool success, out string result, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]事件操作电话挂断CallID：" + CallID + ",主叫：" + RequestANI + ",被叫：" + RequestPhoneNum + ",分机:" + RequestExtensionNum);
            success = false;
            result = "";
            msg = "";

            try
            {
                //更新去电记录表的挂断时间，通话时长,录音url。通话时长=挂断时间-通话时间。
                Entities.CallRecordInfo model1 = BLL.CallRecordInfo.Instance.GetCallRecordInfoByCallID(Convert.ToInt64(CallID));
                int italltime = 0;
                if (model1 != null)
                {
                    model1.EndTime = CurrentTime;
                    TimeSpan tsSpan = (TimeSpan)(CurrentTime - model1.BeginTime);
                    italltime = (int)tsSpan.TotalSeconds;
                    model1.TallTime = italltime;
                    if (!string.IsNullOrEmpty(RequestAudioURL))
                    {
                        model1.AudioURL = RequestAudioURL;
                    }
                    else
                    {
                        Loger.Log4Net.Info("[UCDemoHandler]挂断事件下未取到录音URL，CallID：" + model1.CallID);
                    }
                    BLL.CallRecordInfo.Instance.Update(model1);
                }

                //更新话务总表，挂断时间，录音URL
                Entities.CallRecord_ORIG model2 = BLL.CallRecord_ORIG.Instance.GetCallRecord_ORIGByCallID(Convert.ToInt64(CallID));
                if (model2 != null)
                {
                    model2.AgentReleaseTime = CurrentTime;
                    model2.CustomerReleaseTime = CurrentTime;
                    model2.TallTime = italltime;
                    if (!string.IsNullOrEmpty(RequestAudioURL))
                    {
                        model2.AudioURL = RequestAudioURL;
                    }
                    BLL.CallRecord_ORIG.Instance.Update(model2);
                }

                success = true;
            }
            catch (Exception ex)
            {
                success = false;
                Loger.Log4Net.Info("[UCDemoHandler]挂断事件操作失败，CallID:" + CallID + "!，ErrorMsg:" + ex.Message + ",ErrorStackTrace:" + ex.StackTrace);
            }

        }

        #region 生成CallID，及UNIX时间戳转换方法
        /// <summary>
        /// 根据时间戳分机号生成CallID
        /// </summary>
        /// <param name="timestamp"></param>
        /// <param name="ExtensionNum"></param>
        /// <returns></returns>
        private Int64 GetNewCallID()
        {
            string result = "";
            try
            {
                string timestamp = GenerateTimeStamp(DateTime.Now);
                Loger.Log4Net.Info("[UCDemoHandler]GetNewCallID:生成新CallID时间戳：" + timestamp);
                Random r = new Random();

                string extNum = RequestExtensionNum;//分机号码
                if (String.IsNullOrEmpty(extNum))
                {
                    extNum = r.Next(1000, 10000).ToString();
                }
                else if (extNum.Length > 4)
                {
                    extNum = extNum.Substring(0, 4);
                }

                int iextNum = 0;
                if (int.TryParse(extNum, out iextNum))
                {
                    extNum = iextNum.ToString();
                }
                else
                {
                    Loger.Log4Net.Error("[UCDemoHandler]生成新CallID时，分机转换Int类型时出错");
                    extNum = "8888";
                }

                result = extNum + timestamp + r.Next(100, 1000).ToString();
                Loger.Log4Net.Error("[UCDemoHandler]生成新CallID成功，CallID:" + result);
            }
            catch (Exception ex)
            {
                Loger.Log4Net.Error("[UCDemoHandler]生成新CallID时，出错:", ex);
                return -2;
            }

            return Convert.ToInt64(result);
        }

        public string GenerateTimeStamp(DateTime dt)
        {
            // Default implementation of UNIX time of the current UTC time   
            TimeSpan ts = dt.ToUniversalTime() - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }
        /// <summary>
        /// 时间戳转为C#格式时间
        /// </summary>
        /// <param name="timeStamp"></param>
        /// <returns></returns>
        public DateTime GetTime(int timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            long lTime = long.Parse(timeStamp.ToString() + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }
        #endregion

        #region 话务总表插入、更新操作

        public bool InsertCallRecord_ORIG(out string result, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]开始插入话务总表数据,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI);
            result = "";
            msg = "";
            Entities.CallRecord_ORIG model = new Entities.CallRecord_ORIG();
            model.CreateTime = DateTime.Now;
            model.CreateUserID = Convert.ToInt32(CreateUserID);

            Int64 icallid = GetNewCallID();
            if (icallid == -2)
            {
                msg = "生成新CallID时出错!";
                return false;
            }

            result = Convert.ToString(icallid);
            model.CallID = icallid;
            model.ExtensionNum = RequestExtensionNum;
            model.OutBoundType = 1;
            model.SessionID = RequestSessionID;
            model.SwitchINNum = string.Empty;
            model.AfterWorkTime = 0;
            model.TallTime = 0;
            model.CallStatus = 2;
            Loger.Log4Net.Info("[UCDemoHandler]插入话务总表数据,InitiatedTime：" + InitiatedTime);
            model.InitiatedTime = GetTime(Convert.ToInt32(InitiatedTime));
            model.PhoneNum = RequestPhoneNum;//主叫
            model.RingingTime = CurrentTime;//GetTime(Convert.ToInt16(RingingTime));
            model.ANI = RequestANI;//呼出号（被叫）
            model.AudioURL = RequestAudioURL;

            string Verifycode = ConfigurationUtil.GetAppSettingValue("CallRecordAuthorizeCode");//调用话务记录接口授权码
            if (BLL.CallRecord_ORIG_Authorizer.Instance.Verify(Verifycode, 0, ref msg, "存储话务数据，授权失败。"))
            {
                Entities.CallRecord_ORIG model_ORIG = null;
                model_ORIG = (model != null && model.CallID != null ? BLL.CallRecord_ORIG.Instance.GetCallRecord_ORIGByCallID(Int64.Parse(model.CallID.ToString())) : null);

                if ((model == null || (model != null && model.CallID == null))
                    && model_ORIG == null)
                {
                    msg = "参数CallRecord_ORIG的Model为空"; return false;
                }
                /*根据model.CallID，插入记录到表CallIDMapping中，若CallID和CurrentTime内容存在，则不做插入操作*/
                if (model != null && model_ORIG == null)
                {
                    BitAuto.ISDC.CC2012.BLL.CallRecord_ORIG.Instance.Insert(model);
                }
                else if (model != null && model_ORIG != null)
                {
                    Loger.Log4Net.Info("[UCDemoHandler]话务总表数据已存在 开始更新,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI + ",CallID:" + model.CallID);
                    BitAuto.ISDC.CC2012.BLL.CallRecord_ORIG.Instance.Update(model);
                }
                return true;
            }
            else
            {
                Loger.Log4Net.Info("[UCDemoHandler]存储话务数据，授权失败,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI + ",msg:" + msg);
                EVTSendErrorEmail += new EVTHandler_SendErrorEmail(UCDemoHandler_EVTSendErrorEmail);
                string errormsg = "青牛客户端外呼授权失败，主叫：" + RequestPhoneNum + ",被叫：" + RequestANI;
                EVTSendErrorEmail(errormsg, "UCDemoHandler", "" );
            }
            return false;
        }

        void UCDemoHandler_EVTSendErrorEmail(string errorMsg, string source, string stackTrace)
        {
            Loger.Log4Net.Info("[UCDemoHandler]青牛授权失败开始发送报错邮件");
            string mailBody = string.Format("错误信息：{0}<br/>错误Source：{1}<br/>错误StackTrace：{2}<br/>",
                    errorMsg, source, stackTrace);
            string subject = "青牛客户端外呼授权失败";

            string userEmails = ConfigurationManager.AppSettings["ReceiveErrorEmail"];
            string[] userEmail = userEmails.Split(';');
            BitAuto.ISDC.CC2012.BLL.EmailHelper.Instance.SendErrorMail(mailBody, subject, userEmail);   
        }

        #endregion

        #region 插入话务-业务中间表
        //插入话务总表跟业务分组中间表记录
        public void InsertCallRecord_ORIG_Business(long _callID, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]插入话务业务中间表CallID：" + _callID);
            msg = "";

            Entities.CallRecord_ORIG_Business callrecordorgbusiness = new Entities.CallRecord_ORIG_Business();

            callrecordorgbusiness.CreateUserID = Convert.ToInt32(CreateUserID);

            #region 根据UserID获取BGID、SCID
            string bgid = "";
            string scid = "";
            string errormsg = "";
            BLL.Util.GetBIGDSCID_UserID(CreateUserID, RequestBGID, RequestSCID, out bgid, out scid, out errormsg);

            if (string.IsNullOrEmpty(errormsg) && (!string.IsNullOrEmpty(bgid) && !string.IsNullOrEmpty(scid)))
            {
                int _tID = 0;
                if (int.TryParse(bgid, out _tID))
                {
                    callrecordorgbusiness.BGID = _tID;
                }
                else
                {
                    Loger.Log4Net.Info("[UCDemoHandler]插入话务业务中间表BGID转换失败，CallID：" + _callID);
                }

                if (int.TryParse(scid, out _tID))
                {
                    callrecordorgbusiness.SCID = _tID;
                }
                else
                {
                    Loger.Log4Net.Info("[UCDemoHandler]插入话务业务中间表SCID转换失败，CallID：" + _callID);
                }                
            }
            else
            {
                BLL.Loger.Log4Net.Info("[UCDemoHandler]插入话务业务中间表BGID转换失败，CallID：" + _callID + ",ERROR:"+ errormsg);
            }
            #endregion
            

            callrecordorgbusiness.CallID = _callID;
            callrecordorgbusiness.CreateTime = DateTime.Now;
            callrecordorgbusiness.BusinessID = RequestTaskID;
            //查询现在表
            if (!BLL.CallRecord_ORIG_Business.Instance.IsExistsByCallID(_callID))
            {
                msg = BLL.CallRecord_ORIG_Business.Instance.Insert(callrecordorgbusiness).ToString();
            }
            else
            {
                msg = BLL.CallRecord_ORIG_Business.Instance.Update(callrecordorgbusiness).ToString();
                Loger.Log4Net.Info("[UCDemoHandler]话务业务中间表数据已存在 开始更新,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI + ",CallID:" + _callID);
            }
        }
        #endregion

        #region 插入已接、去电记录表
        public void InsertCallRecordInfo(out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]插入去电记录表CallID：" + CallID + ",主叫：" + RequestANI + ",被叫：" + RequestPhoneNum);
            msg = "";
            Entities.CallRecordInfo callRecordInfo = new Entities.CallRecordInfo();
            callRecordInfo.AudioURL = RequestAudioURL;
            callRecordInfo.BeginTime = CurrentTime;
            callRecordInfo.CallStatus = 2;
            callRecordInfo.CreateTime = DateTime.Now;
            callRecordInfo.CreateUserID = Convert.ToInt32(CreateUserID);
            callRecordInfo.ExtensionNum = RequestExtensionNum;
            callRecordInfo.PhoneNum = RequestPhoneNum;
            callRecordInfo.ANI = RequestANI;
            callRecordInfo.SessionID = RequestSessionID;
            callRecordInfo.TallTime = 0;
            callRecordInfo.TaskID = RequestTaskID;
            callRecordInfo.AudioURL = RequestAudioURL;
            callRecordInfo.CustName = RequestCustName;
            callRecordInfo.Contact = RequestContact;
            int taskTypeId = 0;
            if (int.TryParse(RequestTaskTypeID, out taskTypeId))
            {
                callRecordInfo.TaskTypeID = taskTypeId;
            }
            int agentRingTime = 0;
            if (int.TryParse(RequestAgentRingTime, out agentRingTime))
            {
                callRecordInfo.AgentRingTime = agentRingTime;
            }

            if (!string.IsNullOrEmpty(RequestCustID))
            {
                callRecordInfo.CustID = RequestCustID;
            }

            //客户振铃时长
            int CustomRingTime = 0;
            if (int.TryParse(RequestCustomerRingTime, out CustomRingTime))
            {
                callRecordInfo.CustomRingTime = CustomRingTime;
            }

            callRecordInfo.AfterWorkTime = 0;

            int _tID = 0;
            if (int.TryParse(RequestBGID, out _tID))
            {
                callRecordInfo.BGID = _tID;
            }
            else
            {
                Loger.Log4Net.Info("[UCDemoHandler]插入去电记录表BGID转换失败，CallID：" + CallID);
            }

            if (int.TryParse(RequestSCID, out _tID))
            {
                callRecordInfo.SCID = _tID;
            }
            else
            {
                Loger.Log4Net.Info("[UCDemoHandler]插入去电记录表SCID转换失败，CallID：" + CallID);
            }

            Int64 _callID = 0;
            if (Int64.TryParse(CallID, out _callID))
            {
            }
            else
            {
                Loger.Log4Net.Info("[UCDemoHandler]插入去电记录表CallID转换失败，CallID：" + CallID);
            }
            callRecordInfo.CallID = _callID;

            Entities.CallRecordInfo _model = BLL.CallRecordInfo.Instance.GetCallRecordInfoByCallID(_callID);

            if (_model == null)
            {
                msg = BLL.CallRecordInfo.Instance.Insert(callRecordInfo).ToString();
            }
            else
            {
                Loger.Log4Net.Info("[UCDemoHandler]插入去电记录表数据已存在 开始更新，CallID：" + CallID + ",主叫：" + RequestANI + ",被叫：" + RequestPhoneNum);
                msg = _model.RecID.ToString();
                BLL.CallRecordInfo.Instance.Update(callRecordInfo);
            }
        }
        #endregion

        #region 青牛呼入操作
        void AgentStatus_Disconnected_Inbound(out bool success, out string result, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]事件操作电话挂断CallID：" + CallID + ",主叫：" + RequestANI + ",被叫：" + RequestPhoneNum + ",分机:" + RequestExtensionNum);
            success = false;
            result = "";
            msg = "";
            string scallid = "";

            //插入话务总表
            try
            {
                if (InsertCallRecord_ORIG_Inbound(out result, out msg))
                {
                    success = true;
                    scallid = result;
                }
                else
                {
                    success = false;
                    Loger.Log4Net.Info("[UCDemoHandler]插入话务总表记录CallID失败，CallID:" + scallid + "!,error:" + msg);
                    return;
                }
            }
            catch (Exception ex)
            {
                success = false;
                Loger.Log4Net.Error("[UCDemoHandler]插入话务总表记录CallID失败，CallID:" + scallid + "!，ErrorMsg:" + ex.Message + ",ErrorStackTrace:" + ex.StackTrace);
                return;
            }

            //插入去电记录表及话务业务中间表
            try
            {
                InsertCallRecord_Inbound(Convert.ToInt64(scallid),out msg);
                success = true;
            }
            catch (Exception ex)
            {
                success = false;
                Loger.Log4Net.Error("[UCDemoHandler]插入话务-业务中间表失败，CallID:" + scallid + "!，ErrorMsg:" + ex.Message + ",ErrorStackTrace:" + ex.StackTrace);
            }            

        }

        public bool InsertCallRecord_ORIG_Inbound(out string result, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]开始插入话务总表数据,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI);
            result = "";
            msg = "";
            Entities.CallRecord_ORIG model = new Entities.CallRecord_ORIG();
            model.CreateTime = DateTime.Now;
            model.CreateUserID = BLL.Util.GetLoginUserID();

            Int64 icallid = GetNewCallID();
            if (icallid == -2)
            {
                msg = "生成新CallID时出错!";
                return false;
            }

            result = Convert.ToString(icallid);
            model.CallID = icallid;
            model.ExtensionNum = RequestExtensionNum;
            model.OutBoundType = 1;
            model.SessionID = RequestSessionID;
            model.SwitchINNum = RequestSwitchINNum;
            model.AfterWorkTime = 0;
            model.SkillGroup = RequestSkillGroup;
            
            model.CallStatus = 1;
            model.PhoneNum = RequestPhoneNum;//主叫
            model.RingingTime = Convert.ToDateTime(RingingTime);
            model.ANI = RequestANI;//呼出号（被叫）
            model.AudioURL = RequestAudioURL;

            DateTime beginTime = DateTime.Now;
            if (DateTime.TryParse(RequestEstablishBeginTime, out beginTime))
            {
                model.EstablishedTime = beginTime;
            }
            //如果是呼入电话，计算通话时长，并记录结束时间
            DateTime endTime = DateTime.Now;
            if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
            {
                model.AgentReleaseTime = endTime;
                model.CustomerReleaseTime = endTime;

                TimeSpan tsSpan = (TimeSpan)(endTime - beginTime);
                model.TallTime = (int)tsSpan.TotalSeconds;
            }           

            string Verifycode = ConfigurationUtil.GetAppSettingValue("CallRecordAuthorizeCode");//调用话务记录接口授权码
            if (BLL.CallRecord_ORIG_Authorizer.Instance.Verify(Verifycode, 0, ref msg, "存储话务数据，授权失败。"))
            {
                Entities.CallRecord_ORIG model_ORIG = null;
                model_ORIG = (model != null && model.CallID != null ? BLL.CallRecord_ORIG.Instance.GetCallRecord_ORIGByCallID(Int64.Parse(model.CallID.ToString())) : null);

                if ((model == null || (model != null && model.CallID == null))
                    && model_ORIG == null)
                {
                    msg = "参数CallRecord_ORIG的Model为空"; return false;
                }
                /*根据model.CallID，插入记录到表CallIDMapping中，若CallID和CurrentTime内容存在，则不做插入操作*/
                if (model != null && model_ORIG == null)
                {
                    BitAuto.ISDC.CC2012.BLL.CallRecord_ORIG.Instance.Insert(model);
                }
                else if (model != null && model_ORIG != null)
                {
                    Loger.Log4Net.Info("[UCDemoHandler]话务总表数据已存在 开始更新,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI + ",CallID:" + model.CallID);
                    BitAuto.ISDC.CC2012.BLL.CallRecord_ORIG.Instance.Update(model);
                }
                return true;
            }
            else
            {
                Loger.Log4Net.Info("[UCDemoHandler]存储话务数据，授权失败,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI + ",msg:" + msg);
                EVTSendErrorEmail += new EVTHandler_SendErrorEmail(UCDemoHandler_EVTSendErrorEmail);
                string errormsg = "青牛客户端外呼授权失败，主叫：" + RequestPhoneNum + ",被叫：" + RequestANI;
                EVTSendErrorEmail(errormsg, "UCDemoHandler", "");
            }
            return false;
        }

        //在JS端再调用InsertEmptyCustHistoryInfo（传入必要参十）
        public void InsertCallRecord_Inbound(long _callID, out string msg)
        {
            msg = "";
            Entities.CallRecordInfo callRecordInfo = new Entities.CallRecordInfo();
            callRecordInfo.AudioURL = RequestAudioURL;

            callRecordInfo.BeginTime = Convert.ToDateTime(RequestEstablishBeginTime);
            callRecordInfo.EndTime = Convert.ToDateTime(RequestEstablishEndTime);
            callRecordInfo.CallStatus = 1;
            callRecordInfo.CreateTime = DateTime.Now;
            callRecordInfo.CreateUserID = BLL.Util.GetLoginUserID();
            callRecordInfo.ExtensionNum = RequestExtensionNum;
            callRecordInfo.PhoneNum = RequestANI;
            callRecordInfo.ANI = RequestPhoneNum;
            callRecordInfo.SessionID = RequestSessionID;
            callRecordInfo.TallTime = 0;
            int taskTypeId = 0;
            if (int.TryParse(RequestTaskTypeID, out taskTypeId))
            {
                callRecordInfo.TaskTypeID = taskTypeId;
            }
            int agentRingTime = 0;
            if (int.TryParse(RequestAgentRingTime, out agentRingTime))
            {
                callRecordInfo.AgentRingTime = agentRingTime;
            }

            //客户振铃时长
            int CustomRingTime = 0;
            if (int.TryParse(RequestCustomerRingTime, out CustomRingTime))
            {
                callRecordInfo.CustomRingTime = CustomRingTime;
            }

            DateTime beginTime = DateTime.Now;
            if (DateTime.TryParse(RequestEstablishBeginTime, out beginTime))
            {
                callRecordInfo.BeginTime = beginTime;
            }
            //如果是呼入电话，计算通话时长，并记录结束时间
            DateTime endTime = DateTime.Now;
            if (DateTime.TryParse(RequestEstablishEndTime, out endTime))
            {
                TimeSpan tsSpan = (TimeSpan)(endTime - beginTime);
                callRecordInfo.TallTime = (int)tsSpan.TotalSeconds;
            }
            callRecordInfo.EndTime = endTime;

            callRecordInfo.AfterWorkTime = 0;
            callRecordInfo.SkillGroup = RequestSkillGroup;
            if (!string.IsNullOrEmpty(RequestCustID))
            {
                Entities.CustBasicInfo custInfo = BLL.CustBasicInfo.Instance.GetCustBasicInfo(RequestCustID);
                if (custInfo != null)
                {
                    callRecordInfo.CustID = custInfo.CustID;
                    callRecordInfo.CustName = custInfo.CustName;
                    callRecordInfo.Contact = custInfo.CustName;
                }
                BLL.CustBasicInfo.Instance.Update(custInfo);
            }

            callRecordInfo.BGID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfBGIDByUserID(Convert.ToInt32(callRecordInfo.CreateUserID));
            callRecordInfo.SCID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfSCIDByUserID(Convert.ToInt32(callRecordInfo.CreateUserID));

            callRecordInfo.CallID = _callID;

            msg = BLL.CallRecordInfo.Instance.Insert(callRecordInfo).ToString();

            //如果是呼入电话则执行，防止外呼初始化插入后，重复记录。
            string msg2 = "";
            InsertCallRecord_ORIG_Business_Inbound(Convert.ToInt64(_callID), out msg2);
        }
        public void InsertCallRecord_ORIG_Business_Inbound(long _callID, out string msg)
        {
            Loger.Log4Net.Info("[UCDemoHandler]插入话务业务中间表CallID：" + _callID);
            msg = "";

            Entities.CallRecord_ORIG_Business callrecordorgbusiness = new Entities.CallRecord_ORIG_Business();

            callrecordorgbusiness.CreateUserID = BLL.Util.GetLoginUserID();           
            callrecordorgbusiness.BGID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfBGIDByUserID(Convert.ToInt32(callrecordorgbusiness.CreateUserID));
            callrecordorgbusiness.SCID = BitAuto.ISDC.CC2012.BLL.SurveyCategory.Instance.GetSelfSCIDByUserID(Convert.ToInt32(callrecordorgbusiness.CreateUserID));

            callrecordorgbusiness.CallID = _callID;
            callrecordorgbusiness.CreateTime = DateTime.Now;
            callrecordorgbusiness.BusinessID = RequestTaskID;
            //查询现在表
            if (!BLL.CallRecord_ORIG_Business.Instance.IsExistsByCallID(_callID))
            {
                msg = BLL.CallRecord_ORIG_Business.Instance.Insert(callrecordorgbusiness).ToString();
            }
            else
            {
                msg = BLL.CallRecord_ORIG_Business.Instance.Update(callrecordorgbusiness).ToString();
                Loger.Log4Net.Info("[UCDemoHandler]话务业务中间表数据已存在 开始更新,主叫：" + RequestPhoneNum + ",被叫：" + RequestANI + ",CallID:" + _callID);
            }
        }                
        
        #endregion

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}