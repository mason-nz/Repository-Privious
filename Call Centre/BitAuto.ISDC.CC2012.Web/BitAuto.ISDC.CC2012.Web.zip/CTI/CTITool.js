﻿
//检测是否是IE6，是-则关闭页面
$(function () {
    if ($.browser.msie && $.browser.version == 6) {
        alert("请升级IE6版本！");
        try {
            window.external.MethodScript('colsewindow');
        } catch (e) {
            window.opener = null; window.open('', '_self'); window.close();
        }
        return false;
    }

    $(document).bind("contextmenu", function (e) {
        return false;
    });
});

///需引用jquery.js
var callRecordID = "";
var callType = 1;
var taskTypeID = "";
var isDisconnected = 0;
//延迟时间，以毫秒为单位
var delayTime = 3000;
var telIsAvailable = false; //标记拨打电话是否能通话，true-能；false-不能 add lxw 11.22
var callidtonodisturb = "";
document.onkeydown = function () {
    if ($.browser.msie) {
        if (event.keyCode == 116) { event.keyCode = 0; event.cancelBubble = true; return false; }
    }
}

var ADTTool = window.ADTTool = (function () {
    //add by qizq 2013-1-9本地录音表主键呼出，呼入号码
    var businessNature = '', relationID = '', cRMCustID = '', params_url = '',

    newPage = function (url) {
        try {
            var flag = window.external.MethodScript('/browsercontrol/newpage?url=' + url);
            if (flag == 'failed')
            { return -1; }
        }
        catch (e) {
            return -1;
        }
    },

    callOut = function (TargetDN, ShowANI, clickObj, outnum) {//外呼
        if (typeof $("#hidCallPhone").val() != "undefined") {
            $("#hidCallPhone").val(TargetDN);
        }
        if (TargetDN) {
            if (typeof (clickObj) == 'string')
                clickObj = $('#' + clickObj);
            if (ADTTool.beforeCallOut) {
                //外呼之前事件
                ADTTool.beforeCallOut(clickObj.attr('MemberCode'), clickObj.attr('ContactInfoUserID'), clickObj.attr('cTel'), clickObj.attr('cName'), clickObj.attr('cSex'));
            }
            TargetDN = fullChar2halfChar(TargetDN);
            ShowANI = ShowANI || '';
            try {
                var ErrorMes = "";

                ErrorMes = window.external.MethodScript('/CallControl/MakeCall?targetdn=' + TargetDN + '&OutShowTag=' + outnum);
                if (ErrorMes != "") {

                    alert(ErrorMes);
                }
                isTelAvailable = true;
            }
            catch (e) {
                alert('通话功能不可用！');
            }
        }
        else { alert('未初始化参数'); }
    },

    openCallOutPopup = function (clickObj, phoneNumText, ShowANI, outNum) {//若有多个呼出号码，则弹出层         
        if (window.ADTToolPopupContent) {
            window.ADTToolPopupContent.remove();
            $(document).unbind('mousemove', f);
            window.ADTToolPopupContent = null;
        }

        phoneNumText = $.trim(phoneNumText.replace(/\-/g, ""));
        if (phoneNumText.length == 0) { alert('电话号码为空'); return; }

        phoneNumText = $.trim(phoneNumText.replace(/\$/g, ',')); //把$符号替换为逗号

        if (phoneNumText.indexOf(',') < 0) {
            callOut(phoneNumText, ShowANI, $(clickObj), outNum);
        }
        else {
            var co = $(clickObj); if (co.length == 0) { return; }
            var content = $('<div class="open_tell" stype="position:absolute;"></div>');
            var ul = $('<ul class="list"></ul>');
            var array = phoneNumText.split(',');
            var i;
            for (i = 0; i < array.length; i++) {
                var v = array[i];
                var ulObj = $('<li>').append($('<span>').html(v));
                var aObj = $('<a>').addClass('tell').attr('id', 'calltell' + getRandomStr(20) + v)
                .attr('ctel', v);
                aObj.attr('href', 'javascript:ADTTool.callOut("' + v + '", "","' + aObj.attr('id') + '","' + outNum + '");');

                if ($(clickObj).attr('ContactInfoUserID') != undefined)
                    aObj.attr('ContactInfoUserID', $(clickObj).attr('ContactInfoUserID'));
                else if ($(clickObj).attr('MemberCode') != undefined)
                    aObj.attr('MemberCode', $(clickObj).attr('MemberCode'));
                ul.append(ulObj.append(aObj));
            }
            content.append(ul).append('<em></em>').appendTo($('body'));
            height = 25 * (i + 1) + 29;
            top = (co.offset().top - height) + 100;
            left = co.offset().left - 21;
            content.css({ left: left, top: top });
            window.ADTToolPopupContent = content;
            $(document).bind('mousemove', f);
        }
    },

    top = 0, left = 0, height = 0,
    f = function (e) {
        if (e.pageX < left - 20 || e.pageX > left + 180 || e.pageY < top - 20 || e.pageY > top + height + 20) {
            $(document).unbind('mousemove', f);
            window.ADTToolPopupContent.remove();
        }
    },

    unserialise = function (Data) {
        params_url = "";
        Data = Data.substr(Data.indexOf('?') + 1);
        Data = Data.split("&");
        var Serialised = new Array();
        $.each(Data, function () {
            var Properties = this.split("=");
            Serialised[Properties[0]] = Properties[1];
            params_url += "'" + Properties[0] + "':'" + Properties[1] + "',";
        });
        if (params_url.length > 1)
            params_url = params_url.substr(0, params_url.length - 1);
        params_url = "{" + params_url + "}";
        return Serialised;
    };

    var handlerURL = '/CTI/CTIHelper.ashx?callback=?',

    adtHandler = function (data) {
        callidtonodisturb = data.CallID;
        //处理
        var logMsg = "data.Action:" + data.UserEvent;
        logMsg += ",data.UserName:" + data.UserName;
        logMsg += ",data.CalledNum:" + data.CalledNum;
        logMsg += ",data.CallerNum:" + data.CallerNum;
        logMsg += ",data.CallID:" + data.CallID;
        logMsg += ",data.UserChoice:" + data.UserChoice;
        logMsg += ",data.RecordID:" + data.RecordID;
        logMsg += ",data.RecordIDURL:" + data.RecordIDURL;
        logMsg += ",data.AgentState:" + data.AgentState;
        logMsg += ",data.AgentAuxState:" + data.AgentAuxState;
        logMsg += ",data.MediaType:" + data.MediaType;
        logMsg += ",data.CallType:" + data.CallType;
        InsertCallRecordEventLog(data.UserEvent, data.RecordID, logMsg);
        if (data.UserEvent == 'Established') {
            ADTTool.connectOPRequesting = true;
            $.getJSON(handlerURL, {
                Action: 'Established',
                UserEvent: data.UserEvent,
                UserName: data.UserName,
                CalledNum: data.CalledNum, //对方
                CallerNum: data.CallerNum,  //本机
                CallID: data.CallID,
                UserChoice: data.UserChoice,
                RecordID: data.RecordID,
                RecordIDURL: data.RecordIDURL,
                AgentState: data.AgentState,
                AgentAuxState: data.AgentAuxState,
                MediaType: data.MediaType,
                CallType: data.CallType
            }, function (jd, textStatus, xhr) {
                //如果是呼入
                if (data.CallType == "34" || data.CallType == "33") {
                    if (ADTTool.EstablishedForCallComing) {
                        ADTTool.EstablishedForCallComing(data);
                    }
                    //所以，当页面来源于CTI时，直接触发ADTTool.ButtonState事件
                }
                //如果是呼出
                else {
                    var pos = data.CallerNum.indexOf("0");
                    var len = data.CallerNum.length;
                    //alert("phone: " + data.CallerNum + "len: " + len + "pos: " + pos);

                    //手机号判断规则：大于等于11位，倒数第11位是1，倒数第10位不是0
                    if (len >= 11 && data.CallerNum.charAt(len - 11) == '1' && data.CallerNum.charAt(len - 11 + 1) != '0') {
                        data.CallerNum = data.CallerNum.substr(len - 11, 11);
                        //alert("手机号：" + data.CallerNum);
                    }
                    //区号座机判断规则：存在0，且第一个0之后（含0）的长度大于等于10
                    else if (pos >= 0 && len - pos >= 10) {
                        data.CallerNum = data.CallerNum.substr(pos);
                        //alert("区号座机：" + data.CallerNum);
                    }
                    //非区号座机：不是手机号，不带区号的情况下，大于8位
                    else if (len > 8) {
                        data.CallerNum = data.CallerNum.substr(len - 8, 8);
                        //alert("座机：" + data.CallerNum);
                    }
                    else {
                        //alert("无处理：" + data.CallerNum);
                    }

                    if (data.CallerNum.substr(0, 2) == "00") {
                        //00开头 去掉一个0
                        data.CallerNum = data.CallerNum.substr(1);
                    }

                    if (ADTTool.Established) {
                        ADTTool.Established(data);
                    }
                }
                ADTTool.connectOPRequesting = false;
            });
        }
        else if (data.UserEvent == 'Released' ||
                 data.UserEvent == 'CA_CALL_EVENT_OP_DISCONNECT' ||
                 data.UserEvent == 'CA_CALL_EVENT_THIRD_PARTY_DISCONNECT' ||
                 data.UserEvent == 'CA_CALL_EVENT_FOURTH_PARTY_DISCONNECT') {
            ADTTool.disconnectRequesting = true;
            if (ADTTool.onDisconnectRequesting) {
                ADTTool.onDisconnectRequesting();
            }
            $.getJSON(handlerURL, {
                Action: 'Released',
                UserEvent: data.UserEvent,
                UserName: data.UserName,
                CalledNum: data.CalledNum, //对方
                CallerNum: data.CallerNum,  //本机
                CallID: data.CallID,
                UserChoice: data.UserChoice,
                RecordID: data.RecordID,
                RecordIDURL: data.RecordIDURL,
                AgentState: data.AgentState,
                AgentAuxState: data.AgentAuxState,
                MediaType: data.MediaType,
                CallType: data.CallType
            }, function (jd, textStatus, xhr) {
                if (ADTTool.onDisconnected) {
                    ADTTool.onDisconnected(data);
                }
                if (ADTTool.onDisconnectedForUpdateRecordLastTime) {
                    ADTTool.onDisconnectedForUpdateRecordLastTime(data);
                }
                ADTTool.disconnectRequesting = false;
            });
        }
        else if (data.UserEvent == 'Ringing') {//响铃
            if (ADTTool.onAlerting) { ADTTool.onAlerting(data); } //显示遮盖层，不能操作页面数据
        }
        else if (data.UserEvent == 'Transferred') {//响铃
            if (ADTTool.onTransferred) { ADTTool.onTransferred(data); }
        }
        else if (data.UserEvent == 'Initiated') {
            if (ADTTool.onInitiated) { ADTTool.onInitiated(data); }
        }
        else if (data.UserEvent == 'NetworkReached') {
            if (ADTTool.onNetworkReached) { ADTTool.onNetworkReached(data); }
        }
        else if (data.UserEvent == "AgentAfterCallWork") {
            if (ADTTool.AfterCallWork) { ADTTool.AfterCallWork(data); }
        }
        else if (data.UserEvent == "AgentReady") {
            if (ADTTool.AgentReady) {
                ADTTool.AgentReady(data);
            }
        }
        else if (data.UserEvent == "AutoCall") {
            //自动外呼
            var url = "";
            switch (data.TaskType) {
                case "1":
                    url = "/OtherTask/OtherTaskDeal.aspx?OtherTaskID=" + data.TaskID;
                    break;
            }
            if (url != "") {
                url += "&isautocall=true&r=" + Math.random() + "&autocalldata=" + escape(params_url);
                window.external.MethodScript('/browsercontrol/newpageinbound?url=' + escape(url));
            }
        }
    }

    var getDate = function () {
        var s, d = new Date();
        s += d.getYear() + "-";
        s += (d.getMonth() + 1) + "-";
        s += d.getDate() + " ";
        s += d.getHours() + ':';
        s += d.getMinutes() + ':';
        s += d.getSeconds();
        return s;
    };

    return {
        callOut: callOut,
        openCallOutPopup: openCallOutPopup,
        unserialise: unserialise,
        adtHandler: adtHandler,
        f: f,
        newPage: newPage
    }
})();

//呼入接通
ADTTool.EstablishedForCallComing = function (data) {
    isDisconnected = 0;
    var endtime = new Date();
    var beginTime = new Date();
    if ($("#hdnBeginRingTimePop").val() != undefined) {
        beginTime = $("#hdnBeginRingTimePop").val();
    }
    else if ($("#hdnBeginRingTime").val() != undefined) {
        beginTime = $("#hdnBeginRingTime").val();
    }
    var timespan = parseInt((endtime - beginTime) / 1000);
    callType = 1;
    taskTypeID = 3;
    calledNum = data.CalledNum;
    setTimeout(function () {
        if ($("#hrefAddCust").attr("href") != undefined) {
            $("#hrefAddCust").css("display", "");
            var addCustBaseInfoUrl = "AddCustBaseInfo.aspx?From=CTI&IsClientOpen=1";
            addCustBaseInfoUrl += "&CallType=1";
            addCustBaseInfoUrl += "&TaskTypeID=3";
            $("#hrefAddCust").attr("href", addCustBaseInfoUrl + $("#hrefAddCust").attr("href"));
        }
    }, delayTime);
}
ADTTool.AfterCallWork = function (data) {

}
ADTTool.AgentReady = function (data) {

}
//插入录音
function InsertCallRecord(data, callerNum, sessionId, url, timespan, establishBeginTime, establishEndTime) {
    var pody = { Action: "InsertCallRecord",
        AudioURL: url,
        CallStatus: '1',
        TaskTypeID: '3',
        ExtensionNum: data.UserName,
        PhoneNum: data.CalledNum,
        ANI: callerNum,
        SessionID: sessionId,
        AgentRingTime: timespan,
        CustomerRingTime: "0",
        CallID: data.CallID,
        EstablishBeginTime: establishBeginTime,
        EstablishEndTime: establishEndTime,
        SkillGroup: data.UserChoice
    };
    //插入电话记录
    AjaxPostAsync("/AjaxServers/CTIHandler.ashx", pody, null, function (data) {
        callRecordID = data;
    });
}
ADTTool.onDisconnectedForUpdateRecordLastTime = function (data) {

}
//响应事件
function MethodScript(message) {
    if (ADTTool) {
        ADTTool.adtHandler(ADTTool.unserialise(message));
    }
}
//响应客户消息
function Response2CC(message) {
    if (message == "CMDTransfer") {
        //保存客户信息
        if ($("#hdAddCustBaseInfo").val() != undefined) {
            if (SubmitData(false)) {
                $.jAlert("保存成功！");
            }
        }
    }
}
//记录响铃开始时间
var beginRingTime = '';
//振铃开始
ADTTool.onAlerting = function (data) {
    beginRingTime = (new Date()).getTime();
}
//计时
ADTTool.LogonTime = function (type, msg) {
    window.external.MethodScript('/time/' + type + "?msg=" + encodeURIComponent(msg));
}
function fullChar2halfChar(str) {
    var result = '';
    for (i = 0; i < str.length; i++) {
        code = str.charCodeAt(i);             //获取当前字符的unicode编码
        if (code >= 65281 && code <= 65373)   //unicode编码范围是所有的英文字母以及各种字符
        {
            result += String.fromCharCode(str.charCodeAt(i) - 65248);    //把全角字符的unicode编码转换为对应半角字符的unicode码
        }
        else if (code == 12288)                                      //空格
        {
            result += String.fromCharCode(str.charCodeAt(i) - 12288 + 32); //半角空格
        } else {
            result += str.charAt(i);                                     //原字符返回
        }
    }
    return result;
}
function SendEmailForRecordError(message, url, line) {
    var errorMsg = errorMsg += "执行" + url + "文件中的第" + line + "行代码出错，错误信息：" + message;
    window.onerror = null;
    $.post("/AjaxServers/ErrorHandler.ashx", { Action: "SendEmailForRecordError", ErrorMsg: errorMsg }, function () {

    });
    return true;
}
function InsertCallRecordEventLog(eventName, sessionId, logMsg) {
}
//关闭页面
function closePage() {
    try {
        window.external.MethodScript('/browsercontrol/closepage');
    } catch (e) {
        window.opener = null; window.open('', '_self'); window.close();
    }
}
//关闭页面，并刷新上一个页面
function closePageReloadOpener() {
    try {
        window.external.MethodScript('/browsercontrol/closepagereloadppage');
    }
    catch (e) {
        try {
            window.opener.document.location.reload();
            window.close();
        }
        catch (ex) {
            window.opener = null; window.open('', '_self'); window.close();
        }
    }
}
//关闭页面，并刷新上一个页面
function closePageExecOpenerSearch(controlid) {
    var id = "btnSearch";
    if (controlid != undefined) {
        id = controlid;
    }
    try {
        window.external.MethodScript('/browsercontrol/closepagecallparentpagefun?parentpagecontrolid=' + id);
    }
    catch (e) {
        try {
            window.opener.document.getElementById(id).click();
            window.opener = null; window.open('', '_self'); window.close();
        }
        catch (ex) {
            window.opener = null; window.open('', '_self'); window.close();
        }
    }
}
function getRandomStr(len) {
    var x = "123456789poiuytrewqasdfghjklmnbvcxzQWERTYUIPLKJHGFDSAZXCVBNM";
    var str = "";
    for (var i = 0; i < len; i++) {
        str += x.charAt(Math.ceil(Math.random() * 100000000) % x.length);
    }
    return str;
}
//播放录音（弹出层）
ADTTool.PlayRecord = function (playurl) {
    if (playurl) {
        $.openPopupLayer({
            name: 'PlayRecordLayer',
            url: "/CTI/PlayRecord.aspx",
            parameters: { 'RecordURL': playurl },
            popupMethod: 'Post'
        });
    }
}

//自动外呼初始话，自动触发3个事件
ADTTool.AutoCallInit = function (data) {
    if (typeof $("#hidCallPhone").val() != "undefined") {
        $("#hidCallPhone").val(data.CallerNum);
    }

    ADTTool.onInitiated(data);
    ADTTool.onNetworkReached(data);
    ADTTool.Established(data);
}


////呼入振铃
//ADTTool.onTransferred = function (data) {
//    var callNum = data.CallerNum;
//    //如果电话号码为8位，表示北京本地号码，加010区号
//    if (callNum.length == 8) {
//        callNum = "010" + callNum.toString();
//    }
//    var dataSource = TelNumManag.GetDataSource(data.SYS_DNIS);
//    //没有取到值
//    if (dataSource == "") {
//        if (data.SYS_DNIS == 2446) {
//            dataSource = 2;
//        }
//        else if (data.SYS_DNIS == 2448) {
//            dataSource = 7;
//        }
//        else if (data.SYS_DNIS == 2454) {
//            dataSource = 6;
//        }
//        else {
//            dataSource = 2;
//        }
//    }
//    //计时开始
//    ADTTool.LogonTime("start");
//    var date1 = new Date();  //开始时间
//    $.post("/AjaxServers/CTIHandler.ashx", { Action: "GetCustID", Tel: callNum }, function (data) {
//        var date2 = new Date();    //结束时间
//        var cz = (date2.getTime() - date1.getTime()) / 1000;  //时间差的秒数
//        if (Len(data) == 0) {
//            ADTTool.LogonTime("time", "根据号码查询客户完成-新增客户：" + cz + "s");
//            window.external.MethodScript('/browsercontrol/newpageinbound?url=' + escape('/CustBaseInfo/AddCustBaseInfo.aspx?From=CTI&IsClientOpen=1&BeginRingTime=' + beginRingTime + '&CalledNum=' + callNum + '&DataSource=' + dataSource + '&CallType=' + callType));
//        }
//        else {
//            var jsonData = $.evalJSON(data);
//            if (jsonData.TotalCount == 1) {
//                ADTTool.LogonTime("time", "根据号码查询客户完成-修改客户：" + cz + "s");
//                window.external.MethodScript('/browsercontrol/newpageinbound?url=' + escape('/CustBaseInfo/EditCustBaseInfo.aspx?From=CTI&IsClientOpen=1&CustID=' + jsonData.CustID + "&BeginRingTime=" + beginRingTime + "&CalledNum=" + callNum + '&DataSource=' + dataSource + '&CallType=' + callType));
//            }
//            else {
//                ADTTool.LogonTime("time", "根据号码查询客户完成-选择客户：" + cz + "s");
//                window.external.MethodScript('/browsercontrol/newpageinbound?url=' + escape('/CustBaseInfo/EditCustBaseInfo.aspx?From=CTI&IsClientOpen=1&IsShow=true&CustType=' + jsonData.CustType + '&BeginRingTime=' + beginRingTime + "&CalledNum=" + callNum + '&DataSource=' + dataSource + '&CallType=' + callType));
//            }
//        }
//    });
//}

/********************************  免打扰插件  **************************************/
;
var NoDisturbTool = {
    top: 0,
    left: 0,
    height: 0,
    //top = 0,left = 0, height = 0;
    //打开增加/修改免打扰信息的层（层逻辑中会进行判断：如果已经是免打扰号码，则显示修改；如果不是免打扰号码，则显示新增）
    openNoDisturbInfoLayer: function (clickObj, phoneNum, callID) {
        AjaxPostAsync("/BlackWhite/BlackWhiteHandler.ashx", { Action: "checkphoneNumisnodisturb", PhoneNum: phoneNum }, null, function (returnValue) {
            /// 判断此号码是否为免打扰号码：-1：是已删除的免打扰号码；0：是免打扰号码；1：是已过期的免打扰号码；2：不是免打扰号码
            switch (returnValue) {
                case "0":
                    $.jAlert("当前号码已被设置为免打扰，请勿重复添加！");
                    break;
                case "1":
                    // $.jAlert("当前号码已被设置为免打扰，且有效期已失效,点击“确定”按钮，更新号码信息");
                    $.jConfirm("当前号码已被设置为免打扰，且有效期已失效,点击“确定”按钮，更新号码信息？", function (r) {
                        if (r) {
                            $.openPopupLayer({
                                name: "UpdateBlackDataAjaxPopup",
                                parameters: { CallId: callID, PhoneNumber: phoneNum, ResponseFrom: "plugin", r: Math.random() },
                                url: "/BlackWhite/NoDisturbLayer.aspx",
                                beforeClose: function (e, data) {
                                    if (e) {
                                        $(clickObj).attr("disabled", true);
                                    }
                                }
                            });
                        }
                    });
                    break;
                default:
                    $.openPopupLayer({
                        name: "UpdateBlackDataAjaxPopup",
                        parameters: { CallId: callID, PhoneNumber: phoneNum, ResponseFrom: "plugin", r: Math.random() },
                        url: "/BlackWhite/NoDisturbLayer.aspx",
                        beforeClose: function (e, data) {
                            if (e) {
                                $(clickObj).attr("disabled", true);
                            }
                        }
                    });
                    break;
            }
        });
    },
    //打开免打扰电话选择层（若有多个号码，则弹出层  ）
    openNoDisturbPopup: function (clickObj, phoneNumsText, callID) {
        if ($(clickObj).attr("src").indexOf("nodisturbgray.png") > 0) {
            alert("此状态不允许添加免打扰信息");
            return false;
        }
        callID = callidtonodisturb;

        //判断层是否存在，存在则移除
        if (window.NoDisturbPopupContent) {
            window.NoDisturbPopupContent.remove();
            $(document).unbind('mousemove', this.f);
            window.NoDisturbPopupContent = null;
        }
        //去掉电话号码中的短线
        phoneNumsText = $.trim(phoneNumsText.replace(/\-/g, ""));
        if (phoneNumsText.length == 0) {
            alert('电话号码为空'); return;
        }
        //把$符号替换为逗号
        phoneNumsText = $.trim(phoneNumsText.replace(/\$/g, ','));
        //如果只有一个电话号码，则直接打开免打扰信息的层
        if (phoneNumsText.indexOf(',') < 0) {
            this.openNoDisturbInfoLayer(clickObj, phoneNumsText, callID);
        }
        else {
            var co = $(clickObj);
            if (co.length == 0) {
                return;
            }
            var content = $('<div class="open_nodisturbtell" stype="position:absolute;"></div>');
            var ul = $('<ul class="list"></ul>');
            var array = phoneNumsText.split(',');
            var i;
            for (i = 0; i < array.length; i++) {
                var v = array[i];
                var ulObj = $('<li>').append($('<span>').html(v));
                var aObj = $('<a>').addClass('tell').attr('id', 'nodisturbtell' + getRandomStr(20) + v).attr('ctel', v);
                aObj.attr('href', 'javascript:NoDisturbTool.openNoDisturbInfoLayer($(".open_nodisturbtell"),"' + v + '","' + callID + '");');
                ul.append(ulObj.append(aObj));
            }
            content = content.append(ul).append('<em></em>');
            content.appendTo($('body'));
            this.height = 25 * (i + 1) + 29;
            this.top = (co.offset().top - this.height) + 100;
            this.left = co.offset().left - 21;
            $(".open_nodisturbtell").css({ left: this.left, top: this.top });
            window.NoDisturbPopupContent = content;
            $(".open_nodisturbtell").bind('mouseleave', this.f);
        }
    },
    f: function (e) {
        window.NoDisturbPopupContent.remove();
    }
};

 