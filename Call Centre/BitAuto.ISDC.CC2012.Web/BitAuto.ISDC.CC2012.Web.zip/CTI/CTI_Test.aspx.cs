﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BitAuto.ISDC.CC2012.WebService;
using BitAuto.ISDC.CC2012.Web.Base;

namespace BitAuto.ISDC.CC2012.Web.CTI
{
    public partial class CTI_Test : PageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string msg = string.Empty;
            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID开始");
            int Result = CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID(17154512, "TK2637", 9, 89, 11447, ref msg);
            BLL.Loger.Log4Net.Info("准备调用接口CallRecordServiceHelper.Instance.UpdateBusinessDataByCallID结束返回值Result=" + Result);
            Response.Write(Result.ToString());
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["duluren"] = "qizq";
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            if (Session["duluren"] != null)
            {
                Response.Write(Session["duluren"]);
            }
            else
            {
                Response.Write("没有session");
            }

        }
    }
}